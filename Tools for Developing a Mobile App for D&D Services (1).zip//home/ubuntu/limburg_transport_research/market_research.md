# Limburg, Belgium Transportation Market Research

## Overview of the Transportation Market

### Public Transportation

- **De Lijn**: The primary public transport provider in Flanders (including Limburg province)
  - State-owned enterprise run by the Flemish government
  - Operates approximately 2,240 buses and 399 trams throughout Flanders
  - Recent developments:
    - Service cuts announced for July 2025, with Limburg particularly affected
    - Shifting toward flexible, demand-driven transport in areas with lower demand
    - Introducing a reservation system for passengers in less densely populated areas
    - Investing in electric buses (awarded framework agreement for up to 100 electric vehicles)

- **Public Transportation Market in Belgium**:
  - Expected to generate revenue of US$2.02 billion by 2025
  - Projected CAGR of 0.60% for the coming years
  - 61% of Belgians live within 200 meters of a public transport stop
  - Strong public transport infrastructure in cities, but more limited in rural areas

### Taxi Services

- **Taxi Market in Belgium**:
  - Projected to reach revenue of US$344.03 million in 2025
  - Expected to show a negative annual growth rate (CAGR 2025-2029) of -2.24%
  - Market volume expected to decrease to US$314.21 million by 2029
  - User penetration projected at 12.0% in 2025, declining to 11.0% by 2029
  - Average revenue per user (ARPU) expected to be US$244.41

- **Taxi Companies**:
  - Total of 7,432 taxi companies in Belgium
  - Brussels has the largest concentration (35% market share with 2,647 companies)
  - Antwerp is second largest
  - Limburg has a smaller but significant presence of taxi providers
  - Notable Limburg taxi company: Hasseltse Taxi Maatschappij Groep (based in Hasselt)

- **Market Trends**:
  - Traditional taxi market gradually shifting toward ride-hailing platforms like Uber
  - Increasing competition from digital platforms offering more convenience and competitive pricing
  - Need for traditional taxi operators to adapt by incorporating mobile apps and digital payment options

### Shared Mobility

- **Shared Mobility in Belgium**:
  - Almost 50,000 shared vehicles in operation
  - Breakdown:
    - 21,721 shared bicycles
    - 18,764 shared scooters
    - 8,976 shared cars
  - Growing importance as an essential component of the transportation ecosystem
  - Municipalities increasingly requiring guarantees from providers operating in their territories

- **Car Sharing**:
  - Number of people sharing cars on a cost-sharing basis more than doubled in recent years
  - Ride-sharing tendency varies by age (younger people more likely to participate)

## Limburg-Specific Transportation Landscape

- **Geographic and Demographic Context**:
  - One of the five provinces of Flanders
  - Less densely populated compared to Brussels or Antwerp
  - More rural character with smaller cities and towns

- **Public Transport Challenges**:
  - De Lijn cutting back bus services in Limburg as of July 2025
  - Rural areas face limited public transport options
  - Increasing focus on demand-driven, flexible transport solutions

- **Opportunities for Transportation Apps**:
  - Gap in the market for connecting rural residents with transportation options
  - Potential to integrate traditional taxi services with modern booking platforms
  - Opportunity to create a marketplace connecting local transportation providers with users
  - Growing interest in shared mobility solutions

## Market Potential for a Transportation Marketplace App

- **Target Providers**:
  - Local taxi companies in Limburg
  - Private car owners willing to provide ride-sharing services
  - Specialized transport services (airport shuttles, business transportation)
  - Potential integration with De Lijn's services in areas with service reductions

- **Target Users**:
  - Residents in areas with limited public transport options
  - Tourists visiting Limburg
  - Business travelers
  - Elderly or mobility-impaired individuals requiring door-to-door service

- **Competitive Landscape**:
  - Major ride-hailing platforms (Uber) present in larger Belgian cities but less penetration in Limburg
  - Traditional taxi companies with varying levels of digital presence
  - De Lijn's own booking system for flexible transport in low-demand areas

- **Market Trends Favoring a New Platform**:
  - Declining traditional taxi market creating pressure for innovation
  - Service cuts in public transportation creating gaps to be filled
  - Growing acceptance of shared mobility concepts
  - Increasing smartphone penetration and comfort with transportation apps

## Conclusion

The transportation market in Limburg, Belgium presents a significant opportunity for a marketplace application connecting local transportation providers with users. With public transport service cuts, a declining traditional taxi market, and growing interest in shared mobility, there is a clear gap for a platform that can aggregate various transportation options and make them easily accessible to users.

The success of such a platform would depend on effectively onboarding local taxi companies and other transportation providers, creating a user-friendly booking experience, and navigating the regulatory requirements for transportation services in Belgium.
