# Limburg, Belgium Transportation Providers Analysis

## Taxi Companies in Limburg

### Major Taxi Providers

1. **Hasseltse Taxi Maatschappij Groep**
   - Location: Walenstraat 2, 3500 Hasselt, Belgium
   - Contact: +32 11 30 10 20
   - Services: Road transport services, small parcel delivery, taxi services
   - One of the largest taxi operators in Limburg province
   - Operates throughout Hasselt and surrounding areas

2. **Taxi Hasselt BVBA**
   - Location: Kempischesteenweg 474, 3500 Hasselt
   - Contact: +32 11 946 947, +32 491 956 756
   - Email: info@taxi-hasselt.com, info@th-ht.be
   - Website: taxi-hasselt.com
   - Services: General taxi services throughout Hasselt and Limburg

3. **MyTaxiHasselt**
   - Contact: +32 493 343 445
   - Website: mytaxihasselt.be
   - Services: 24/7 taxi service in Hasselt and Limburg
   - Booking methods: Phone call or WhatsApp
   - Pricing: Fixed rate of €8.50 within 3km
   
4. **Taxi Ags**
   - Location: Hasselt, Limburg
   - Highly rated on review platforms
   - Services: General taxi services

5. **Hasseltse Gele Taxi Gwen**
   - Location: Hasselt, Limburg
   - Services: General taxi services
   - Well-reviewed local operator

6. **Trajetto Taxi Services**
   - Location: Hasselt, Limburg
   - Services: Taxi and transportation services
   - Regional coverage throughout Limburg

7. **Taxi v - cab**
   - Location: Molenweg 5, 3520 Zonhoven, Belgium
   - Services: Taxi services in Zonhoven and surrounding areas

8. **Axi Taxi**
   - Contact: +32 471 500 500
   - Services: Taxi services in Hasselt region

### Other Notable Transportation Providers

1. **Tom's Airportservice & Taxi**
   - Location: Pelt, Limburg
   - Services: Airport transfers and general taxi services
   - Specializes in airport transportation

2. **Taxi Maxi**
   - Location: Pelt, Limburg
   - Services: Larger vehicle taxi services

3. **Taxi Big Daddy Sam**
   - Location: Pelt, Limburg
   - Services: General taxi services

4. **Taxi Hermsen**
   - Location: Pelt, Limburg
   - Services: Local taxi services

5. **Jagam**
   - Location: Pelt, Limburg
   - Services: Transportation services

6. **Dewit/Jozef**
   - Location: Hasselt, Limburg
   - Services: Taxi services

## Public Transportation Providers

### De Lijn (Primary Public Transport Operator)

- **Overview**: State-owned enterprise run by the Flemish government
- **Coverage**: Operates throughout Flanders, including Limburg province
- **Fleet**: Approximately 2,240 buses and 399 trams across Flanders
- **Services in Limburg**:
  - Regular bus routes connecting major cities and towns
  - Scheduled service to smaller communities
  - Recent service cuts announced for July 2025 affecting Limburg routes
  - Shifting toward flexible, demand-driven transport in areas with lower demand
  - Reservation system being implemented for less densely populated areas

- **Contact Information**:
  - Website: delijn.be
  - Customer service available through their website and mobile app
  - Ticket purchasing available online, through mobile app, and at physical locations

- **Digital Presence**:
  - Mobile app for route planning and ticket purchasing
  - Real-time updates on bus locations and arrivals
  - Online route planner

### Belgian Railways (NMBS/SNCB)

- While primarily focused on inter-city rail transport, NMBS/SNCB serves several stations in Limburg:
  - Hasselt (main railway station in Limburg)
  - Genk
  - Sint-Truiden
  - Tongeren
  - Bilzen
  - Other smaller stations

- **Services**: Connects Limburg to other Belgian cities and international destinations
- **Website**: belgianrail.be

## Shared Mobility Providers

Limited information is available on specific shared mobility providers operating in Limburg, but Belgium as a whole has:

- Nearly 50,000 shared vehicles nationwide
- 21,721 shared bicycles
- 18,764 shared scooters
- 8,976 shared cars

Major shared mobility companies that may have presence in Limburg include:

1. **Cambio** - Car sharing service
2. **Poppy** - Free-floating car and scooter sharing
3. **Bolt** - Scooter sharing and ride-hailing
4. **Dott** - E-scooter and e-bike sharing
5. **Bird** - E-scooter sharing

## Market Analysis for Transportation Marketplace

### Potential Partners for a Transportation Marketplace

1. **Primary Taxi Partners**:
   - Hasseltse Taxi Maatschappij Groep - Largest local operator with established presence
   - Taxi Hasselt BVBA - Well-established with online presence
   - MyTaxiHasselt - Already offers digital booking via WhatsApp
   - Smaller local operators who would benefit from increased digital presence

2. **Public Transport Integration**:
   - De Lijn - Potential for API integration for route information and ticketing
   - Opportunity to fill gaps in service areas affected by De Lijn's service cuts

3. **Shared Mobility Integration**:
   - Potential to integrate with existing shared mobility providers
   - Opportunity to bring new shared mobility options to underserved areas

### Competitive Landscape

1. **Existing Booking Platforms**:
   - monTransport.com - Offers taxi booking in Limburg region with price comparison
   - taxi.eu - European taxi booking platform with some Belgian coverage
   - Uber - Limited presence in Limburg but strong in major Belgian cities

2. **Market Gaps**:
   - Limited digital presence for many local taxi operators
   - Fragmented booking experience across different transportation modes
   - Lack of comprehensive transportation marketplace specific to Limburg
   - Opportunity to connect rural areas with appropriate transportation options

### Recommendations for Provider Onboarding

1. **Priority Providers**:
   - Begin with largest operators like Hasseltse Taxi Maatschappij Groep
   - Target providers with existing digital capabilities for easier integration
   - Focus on providers serving areas with recent public transport service cuts

2. **Value Proposition for Providers**:
   - Increased visibility and booking opportunities
   - Reduced idle time and improved vehicle utilization
   - Digital presence without significant technology investment
   - Analytics and business intelligence
   - Competitive positioning against larger platforms like Uber

3. **Onboarding Strategy**:
   - Direct outreach to identified providers
   - Simple onboarding process with minimal technical requirements
   - Flexible commission structure to attract initial participants
   - Training and support for providers with limited digital experience

## Conclusion

Limburg, Belgium has a diverse range of transportation providers, from established taxi companies to public transport and emerging shared mobility options. The fragmented nature of the market, combined with recent public transport service cuts, creates an opportunity for a unified transportation marketplace that connects users with the most appropriate local providers.

The success of such a marketplace will depend on effectively onboarding key local providers, particularly established taxi companies like Hasseltse Taxi Maatschappij Groep and Taxi Hasselt, while also exploring integration opportunities with De Lijn and shared mobility services. The platform should address the specific needs of Limburg's geography, with particular attention to connecting rural areas that may have limited public transport options.
