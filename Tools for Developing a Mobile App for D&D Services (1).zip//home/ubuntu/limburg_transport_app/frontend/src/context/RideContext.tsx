import { createContext, useContext, useState, ReactNode } from 'react';
import axios from 'axios';
import { useAuth } from './AuthContext';

// Define types
type Ride = {
  _id: string;
  status: string;
  rideType: string;
  serviceType: string;
  pickup: {
    address: string;
    coordinates: {
      latitude: number;
      longitude: number;
    };
    notes?: string;
  };
  destination: {
    address: string;
    coordinates: {
      latitude: number;
      longitude: number;
    };
    notes?: string;
  };
  requestTime: string;
  scheduledTime?: string;
  estimatedPrice?: number;
  currency: string;
  providerId: string | {
    _id: string;
    companyName: string;
  };
  driverId?: string | {
    _id: string;
    firstName: string;
    lastName: string;
    phone?: string;
    profilePicture?: string;
  };
  vehicleId?: string | {
    _id: string;
    make: string;
    model: string;
    color: string;
    licensePlate?: string;
  };
  currentLocation?: {
    latitude: number;
    longitude: number;
    updatedAt: string;
  };
};

type RideRequest = {
  providerId: string;
  rideType: 'immediate' | 'scheduled';
  serviceType: string;
  pickup: {
    address: string;
    coordinates: {
      latitude: number;
      longitude: number;
    };
    notes?: string;
  };
  destination: {
    address: string;
    coordinates: {
      latitude: number;
      longitude: number;
    };
    notes?: string;
  };
  intermediateStops?: Array<{
    address: string;
    coordinates: {
      latitude: number;
      longitude: number;
    };
    notes?: string;
  }>;
  scheduledTime?: string;
  paymentMethod: string;
  specialRequirements?: string[];
  passengerCount: number;
};

type RideContextType = {
  rides: Ride[];
  currentRide: Ride | null;
  loading: boolean;
  error: string | null;
  requestRide: (rideData: RideRequest) => Promise<Ride | null>;
  getRides: () => Promise<void>;
  getRideById: (id: string) => Promise<Ride | null>;
  cancelRide: (id: string, reason: string) => Promise<boolean>;
  rateRide: (id: string, score: number, comment: string) => Promise<boolean>;
  setCurrentRide: (ride: Ride | null) => void;
};

// Create context
const RideContext = createContext<RideContextType | undefined>(undefined);

// API base URL
const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api';

// Provider component
export const RideProvider = ({ children }: { children: ReactNode }) => {
  const [rides, setRides] = useState<Ride[]>([]);
  const [currentRide, setCurrentRide] = useState<Ride | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { isAuthenticated } = useAuth();

  // Get auth header
  const getConfig = () => {
    const token = localStorage.getItem('token');
    
    return {
      headers: {
        Authorization: `Bearer ${token}`
      }
    };
  };

  // Request a new ride
  const requestRide = async (rideData: RideRequest): Promise<Ride | null> => {
    if (!isAuthenticated) {
      setError('You must be logged in to request a ride');
      return null;
    }

    try {
      setLoading(true);
      setError(null);
      
      const response = await axios.post(
        `${API_URL}/rides`, 
        rideData,
        getConfig()
      );
      
      if (response.data.success) {
        const newRide = response.data.data;
        setRides(prevRides => [newRide, ...prevRides]);
        setCurrentRide(newRide);
        return newRide;
      }
      return null;
    } catch (error: any) {
      setError(
        error.response?.data?.error || 
        'An error occurred while requesting the ride. Please try again.'
      );
      console.error('Ride request error:', error);
      return null;
    } finally {
      setLoading(false);
    }
  };

  // Get user's rides
  const getRides = async (): Promise<void> => {
    if (!isAuthenticated) {
      setError('You must be logged in to view your rides');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      
      const response = await axios.get(
        `${API_URL}/rides/me`,
        getConfig()
      );
      
      if (response.data.success) {
        setRides(response.data.data);
      }
    } catch (error: any) {
      setError(
        error.response?.data?.error || 
        'An error occurred while fetching your rides. Please try again.'
      );
      console.error('Get rides error:', error);
    } finally {
      setLoading(false);
    }
  };

  // Get ride by ID
  const getRideById = async (id: string): Promise<Ride | null> => {
    if (!isAuthenticated) {
      setError('You must be logged in to view ride details');
      return null;
    }

    try {
      setLoading(true);
      setError(null);
      
      const response = await axios.get(
        `${API_URL}/rides/${id}`,
        getConfig()
      );
      
      if (response.data.success) {
        const ride = response.data.data;
        setCurrentRide(ride);
        return ride;
      }
      return null;
    } catch (error: any) {
      setError(
        error.response?.data?.error || 
        'An error occurred while fetching ride details. Please try again.'
      );
      console.error('Get ride error:', error);
      return null;
    } finally {
      setLoading(false);
    }
  };

  // Cancel ride
  const cancelRide = async (id: string, reason: string): Promise<boolean> => {
    if (!isAuthenticated) {
      setError('You must be logged in to cancel a ride');
      return false;
    }

    try {
      setLoading(true);
      setError(null);
      
      const response = await axios.put(
        `${API_URL}/rides/${id}/cancel`,
        { reason },
        getConfig()
      );
      
      if (response.data.success) {
        // Update rides list
        setRides(prevRides => 
          prevRides.map(ride => 
            ride._id === id 
              ? { ...ride, status: 'cancelled' } 
              : ride
          )
        );
        
        // Update current ride if it's the one being cancelled
        if (currentRide && currentRide._id === id) {
          setCurrentRide({ ...currentRide, status: 'cancelled' });
        }
        
        return true;
      }
      return false;
    } catch (error: any) {
      setError(
        error.response?.data?.error || 
        'An error occurred while cancelling the ride. Please try again.'
      );
      console.error('Cancel ride error:', error);
      return false;
    } finally {
      setLoading(false);
    }
  };

  // Rate ride
  const rateRide = async (id: string, score: number, comment: string): Promise<boolean> => {
    if (!isAuthenticated) {
      setError('You must be logged in to rate a ride');
      return false;
    }

    try {
      setLoading(true);
      setError(null);
      
      const response = await axios.post(
        `${API_URL}/rides/${id}/rate`,
        { score, comment },
        getConfig()
      );
      
      if (response.data.success) {
        // Update rides list
        setRides(prevRides => 
          prevRides.map(ride => 
            ride._id === id 
              ? { 
                  ...ride, 
                  rating: { 
                    driver: { 
                      score, 
                      comment, 
                      createdAt: new Date().toISOString() 
                    } 
                  } 
                } 
              : ride
          )
        );
        
        // Update current ride if it's the one being rated
        if (currentRide && currentRide._id === id) {
          setCurrentRide({ 
            ...currentRide, 
            rating: { 
              driver: { 
                score, 
                comment, 
                createdAt: new Date().toISOString() 
              } 
            } 
          });
        }
        
        return true;
      }
      return false;
    } catch (error: any) {
      setError(
        error.response?.data?.error || 
        'An error occurred while rating the ride. Please try again.'
      );
      console.error('Rate ride error:', error);
      return false;
    } finally {
      setLoading(false);
    }
  };

  return (
    <RideContext.Provider
      value={{
        rides,
        currentRide,
        loading,
        error,
        requestRide,
        getRides,
        getRideById,
        cancelRide,
        rateRide,
        setCurrentRide
      }}
    >
      {children}
    </RideContext.Provider>
  );
};

// Custom hook to use ride context
export const useRide = () => {
  const context = useContext(RideContext);
  
  if (context === undefined) {
    throw new Error('useRide must be used within a RideProvider');
  }
  
  return context;
};
