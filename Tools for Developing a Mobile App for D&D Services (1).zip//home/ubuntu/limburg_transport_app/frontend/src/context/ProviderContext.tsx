import { createContext, useContext, useState, ReactNode } from 'react';
import axios from 'axios';
import { useAuth } from './AuthContext';

// Define types
type Provider = {
  _id: string;
  companyName: string;
  email: string;
  phone: string;
  address: {
    street: string;
    city: string;
    state: string;
    postalCode: string;
    country: string;
  };
  serviceTypes: string[];
  operatingAreas: string[];
  description?: string;
  logo?: string;
  website?: string;
  status: string;
  verificationStatus: string;
  ratingAverage?: number;
  ratingCount?: number;
};

type ProviderContextType = {
  providers: Provider[];
  currentProvider: Provider | null;
  loading: boolean;
  error: string | null;
  getProviders: (serviceType?: string, location?: string) => Promise<void>;
  getProviderById: (id: string) => Promise<Provider | null>;
  addFavoriteProvider: (providerId: string) => Promise<boolean>;
  removeFavoriteProvider: (providerId: string) => Promise<boolean>;
  setCurrentProvider: (provider: Provider | null) => void;
};

// Create context
const ProviderContext = createContext<ProviderContextType | undefined>(undefined);

// API base URL
const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api';

// Provider component
export const ProviderContextProvider = ({ children }: { children: ReactNode }) => {
  const [providers, setProviders] = useState<Provider[]>([]);
  const [currentProvider, setCurrentProvider] = useState<Provider | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { isAuthenticated } = useAuth();

  // Get auth header
  const getConfig = () => {
    const token = localStorage.getItem('token');
    
    return {
      headers: {
        Authorization: `Bearer ${token}`
      }
    };
  };

  // Get providers with optional filters
  const getProviders = async (serviceType?: string, location?: string): Promise<void> => {
    try {
      setLoading(true);
      setError(null);
      
      // Build query parameters
      let url = `${API_URL}/providers`;
      const params = new URLSearchParams();
      
      if (serviceType) {
        params.append('serviceType', serviceType);
      }
      
      if (location) {
        params.append('location', location);
      }
      
      if (params.toString()) {
        url += `?${params.toString()}`;
      }
      
      const response = await axios.get(url);
      
      if (response.data.success) {
        setProviders(response.data.data);
      }
    } catch (error: any) {
      setError(
        error.response?.data?.error || 
        'An error occurred while fetching providers. Please try again.'
      );
      console.error('Get providers error:', error);
    } finally {
      setLoading(false);
    }
  };

  // Get provider by ID
  const getProviderById = async (id: string): Promise<Provider | null> => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await axios.get(`${API_URL}/providers/${id}`);
      
      if (response.data.success) {
        const provider = response.data.data;
        setCurrentProvider(provider);
        return provider;
      }
      return null;
    } catch (error: any) {
      setError(
        error.response?.data?.error || 
        'An error occurred while fetching provider details. Please try again.'
      );
      console.error('Get provider error:', error);
      return null;
    } finally {
      setLoading(false);
    }
  };

  // Add favorite provider
  const addFavoriteProvider = async (providerId: string): Promise<boolean> => {
    if (!isAuthenticated) {
      setError('You must be logged in to add a favorite provider');
      return false;
    }

    try {
      setLoading(true);
      setError(null);
      
      const response = await axios.post(
        `${API_URL}/users/favorite-providers`,
        { providerId },
        getConfig()
      );
      
      return response.data.success;
    } catch (error: any) {
      setError(
        error.response?.data?.error || 
        'An error occurred while adding the provider to favorites. Please try again.'
      );
      console.error('Add favorite provider error:', error);
      return false;
    } finally {
      setLoading(false);
    }
  };

  // Remove favorite provider
  const removeFavoriteProvider = async (providerId: string): Promise<boolean> => {
    if (!isAuthenticated) {
      setError('You must be logged in to remove a favorite provider');
      return false;
    }

    try {
      setLoading(true);
      setError(null);
      
      const response = await axios.delete(
        `${API_URL}/users/favorite-providers/${providerId}`,
        getConfig()
      );
      
      return response.data.success;
    } catch (error: any) {
      setError(
        error.response?.data?.error || 
        'An error occurred while removing the provider from favorites. Please try again.'
      );
      console.error('Remove favorite provider error:', error);
      return false;
    } finally {
      setLoading(false);
    }
  };

  return (
    <ProviderContext.Provider
      value={{
        providers,
        currentProvider,
        loading,
        error,
        getProviders,
        getProviderById,
        addFavoriteProvider,
        removeFavoriteProvider,
        setCurrentProvider
      }}
    >
      {children}
    </ProviderContext.Provider>
  );
};

// Custom hook to use provider context
export const useProvider = () => {
  const context = useContext(ProviderContext);
  
  if (context === undefined) {
    throw new Error('useProvider must be used within a ProviderContextProvider');
  }
  
  return context;
};
