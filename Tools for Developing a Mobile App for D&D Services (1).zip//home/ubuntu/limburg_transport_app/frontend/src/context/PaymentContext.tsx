import { createContext, useContext, useState, ReactNode } from 'react';
import axios from 'axios';
import { useAuth } from './AuthContext';

// Define types
type Payment = {
  _id: string;
  rideId: string | {
    _id: string;
    status: string;
    serviceType: string;
    pickup: {
      address: string;
    };
    destination: {
      address: string;
    };
  };
  providerId: string | {
    _id: string;
    companyName: string;
  };
  amount: number;
  currency: string;
  status: string;
  paymentMethod: string;
  paymentIntentId?: string;
  platformFee?: number;
  providerAmount?: number;
  refundAmount?: number;
  refundReason?: string;
  receiptUrl?: string;
  createdAt: string;
  updatedAt: string;
};

type Receipt = {
  receiptNumber: string;
  date: string;
  customer: {
    name: string;
    email: string;
  };
  provider: {
    name: string;
    address: any;
  };
  ride: {
    from: string;
    to: string;
    date: string;
    completedAt?: string;
    distance?: number;
    serviceType: string;
  };
  payment: {
    amount: number;
    currency: string;
    method: string;
    status: string;
    platformFee?: number;
    refundAmount?: number;
  };
};

type PaymentContextType = {
  payments: Payment[];
  currentPayment: Payment | null;
  currentReceipt: Receipt | null;
  loading: boolean;
  error: string | null;
  processPayment: (rideId: string, paymentMethod: string, paymentToken?: string) => Promise<Payment | null>;
  getPayments: () => Promise<void>;
  getPaymentById: (id: string) => Promise<Payment | null>;
  requestRefund: (paymentId: string, reason: string) => Promise<boolean>;
  generateReceipt: (paymentId: string) => Promise<Receipt | null>;
  setCurrentPayment: (payment: Payment | null) => void;
};

// Create context
const PaymentContext = createContext<PaymentContextType | undefined>(undefined);

// API base URL
const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api';

// Provider component
export const PaymentProvider = ({ children }: { children: ReactNode }) => {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [currentPayment, setCurrentPayment] = useState<Payment | null>(null);
  const [currentReceipt, setCurrentReceipt] = useState<Receipt | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { isAuthenticated } = useAuth();

  // Get auth header
  const getConfig = () => {
    const token = localStorage.getItem('token');
    
    return {
      headers: {
        Authorization: `Bearer ${token}`
      }
    };
  };

  // Process payment for a ride
  const processPayment = async (
    rideId: string, 
    paymentMethod: string, 
    paymentToken?: string
  ): Promise<Payment | null> => {
    if (!isAuthenticated) {
      setError('You must be logged in to process a payment');
      return null;
    }

    try {
      setLoading(true);
      setError(null);
      
      const response = await axios.post(
        `${API_URL}/payments/rides/${rideId}`, 
        { paymentMethod, paymentToken },
        getConfig()
      );
      
      if (response.data.success) {
        const newPayment = response.data.data;
        setPayments(prevPayments => [newPayment, ...prevPayments]);
        setCurrentPayment(newPayment);
        return newPayment;
      }
      return null;
    } catch (error: any) {
      setError(
        error.response?.data?.error || 
        'An error occurred while processing the payment. Please try again.'
      );
      console.error('Payment processing error:', error);
      return null;
    } finally {
      setLoading(false);
    }
  };

  // Get user's payments
  const getPayments = async (): Promise<void> => {
    if (!isAuthenticated) {
      setError('You must be logged in to view your payments');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      
      const response = await axios.get(
        `${API_URL}/payments/me`,
        getConfig()
      );
      
      if (response.data.success) {
        setPayments(response.data.data);
      }
    } catch (error: any) {
      setError(
        error.response?.data?.error || 
        'An error occurred while fetching your payments. Please try again.'
      );
      console.error('Get payments error:', error);
    } finally {
      setLoading(false);
    }
  };

  // Get payment by ID
  const getPaymentById = async (id: string): Promise<Payment | null> => {
    if (!isAuthenticated) {
      setError('You must be logged in to view payment details');
      return null;
    }

    try {
      setLoading(true);
      setError(null);
      
      const response = await axios.get(
        `${API_URL}/payments/${id}`,
        getConfig()
      );
      
      if (response.data.success) {
        const payment = response.data.data;
        setCurrentPayment(payment);
        return payment;
      }
      return null;
    } catch (error: any) {
      setError(
        error.response?.data?.error || 
        'An error occurred while fetching payment details. Please try again.'
      );
      console.error('Get payment error:', error);
      return null;
    } finally {
      setLoading(false);
    }
  };

  // Request refund
  const requestRefund = async (paymentId: string, reason: string): Promise<boolean> => {
    if (!isAuthenticated) {
      setError('You must be logged in to request a refund');
      return false;
    }

    try {
      setLoading(true);
      setError(null);
      
      const response = await axios.post(
        `${API_URL}/payments/${paymentId}/refund`,
        { reason },
        getConfig()
      );
      
      if (response.data.success) {
        // Update payments list
        setPayments(prevPayments => 
          prevPayments.map(payment => 
            payment._id === paymentId 
              ? { ...payment, status: 'refunded', refundReason: reason } 
              : payment
          )
        );
        
        // Update current payment if it's the one being refunded
        if (currentPayment && currentPayment._id === paymentId) {
          setCurrentPayment({ 
            ...currentPayment, 
            status: 'refunded', 
            refundReason: reason 
          });
        }
        
        return true;
      }
      return false;
    } catch (error: any) {
      setError(
        error.response?.data?.error || 
        'An error occurred while requesting the refund. Please try again.'
      );
      console.error('Refund request error:', error);
      return false;
    } finally {
      setLoading(false);
    }
  };

  // Generate receipt
  const generateReceipt = async (paymentId: string): Promise<Receipt | null> => {
    if (!isAuthenticated) {
      setError('You must be logged in to generate a receipt');
      return null;
    }

    try {
      setLoading(true);
      setError(null);
      
      const response = await axios.get(
        `${API_URL}/payments/${paymentId}/receipt`,
        getConfig()
      );
      
      if (response.data.success) {
        const receipt = response.data.data;
        setCurrentReceipt(receipt);
        return receipt;
      }
      return null;
    } catch (error: any) {
      setError(
        error.response?.data?.error || 
        'An error occurred while generating the receipt. Please try again.'
      );
      console.error('Generate receipt error:', error);
      return null;
    } finally {
      setLoading(false);
    }
  };

  return (
    <PaymentContext.Provider
      value={{
        payments,
        currentPayment,
        currentReceipt,
        loading,
        error,
        processPayment,
        getPayments,
        getPaymentById,
        requestRefund,
        generateReceipt,
        setCurrentPayment
      }}
    >
      {children}
    </PaymentContext.Provider>
  );
};

// Custom hook to use payment context
export const usePayment = () => {
  const context = useContext(PaymentContext);
  
  if (context === undefined) {
    throw new Error('usePayment must be used within a PaymentProvider');
  }
  
  return context;
};
