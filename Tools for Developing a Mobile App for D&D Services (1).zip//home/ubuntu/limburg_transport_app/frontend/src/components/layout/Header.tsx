import React from 'react';
import Link from 'next/link';
import { useAuth } from '@/context/AuthContext';

const Header = () => {
  const { user, logout, isAuthenticated } = useAuth();

  return (
    <header className="bg-primary shadow-md">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <Link href="/" className="text-white text-2xl font-bold">
              Limburg Transport
            </Link>
          </div>
          
          <nav className="hidden md:flex space-x-6">
            <Link href="/" className="text-white hover:text-gray-200">
              Home
            </Link>
            <Link href="/providers" className="text-white hover:text-gray-200">
              Providers
            </Link>
            {isAuthenticated ? (
              <>
                <Link href="/dashboard" className="text-white hover:text-gray-200">
                  Dashboard
                </Link>
                <Link href="/rides" className="text-white hover:text-gray-200">
                  My Rides
                </Link>
                <Link href="/payments" className="text-white hover:text-gray-200">
                  Payments
                </Link>
              </>
            ) : (
              <>
                <Link href="/about" className="text-white hover:text-gray-200">
                  About
                </Link>
                <Link href="/contact" className="text-white hover:text-gray-200">
                  Contact
                </Link>
              </>
            )}
          </nav>
          
          <div className="flex items-center space-x-4">
            {isAuthenticated ? (
              <div className="flex items-center space-x-4">
                <div className="hidden md:block text-white">
                  Welcome, {user?.firstName}
                </div>
                <div className="relative group">
                  <button className="bg-white text-primary px-4 py-2 rounded-md font-medium hover:bg-gray-100">
                    Account
                  </button>
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10 hidden group-hover:block">
                    <Link href="/profile" className="block px-4 py-2 text-gray-800 hover:bg-gray-100">
                      Profile
                    </Link>
                    <Link href="/settings" className="block px-4 py-2 text-gray-800 hover:bg-gray-100">
                      Settings
                    </Link>
                    <button 
                      onClick={logout}
                      className="block w-full text-left px-4 py-2 text-gray-800 hover:bg-gray-100"
                    >
                      Logout
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex space-x-2">
                <Link href="/login" className="bg-white text-primary px-4 py-2 rounded-md font-medium hover:bg-gray-100">
                  Login
                </Link>
                <Link href="/register" className="bg-secondary text-white px-4 py-2 rounded-md font-medium hover:bg-secondary-dark">
                  Register
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
