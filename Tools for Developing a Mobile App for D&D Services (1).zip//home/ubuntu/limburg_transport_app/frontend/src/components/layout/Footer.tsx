import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">Limburg Transport</h3>
            <p className="text-gray-300">
              Connecting passengers with transportation providers across Limburg, Belgium.
            </p>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><a href="/" className="text-gray-300 hover:text-white">Home</a></li>
              <li><a href="/providers" className="text-gray-300 hover:text-white">Providers</a></li>
              <li><a href="/about" className="text-gray-300 hover:text-white">About Us</a></li>
              <li><a href="/contact" className="text-gray-300 hover:text-white">Contact</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">For Providers</h4>
            <ul className="space-y-2">
              <li><a href="/provider/register" className="text-gray-300 hover:text-white">Join as Provider</a></li>
              <li><a href="/provider/login" className="text-gray-300 hover:text-white">Provider Login</a></li>
              <li><a href="/provider/requirements" className="text-gray-300 hover:text-white">Requirements</a></li>
              <li><a href="/provider/faq" className="text-gray-300 hover:text-white">Provider FAQ</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact Us</h4>
            <address className="not-italic text-gray-300">
              <p>Koning Albertstraat 15</p>
              <p>3500 Hasselt, Limburg</p>
              <p>Belgium</p>
              <p className="mt-2">Email: info@limburgtransport.be</p>
              <p>Phone: +32 123 456 789</p>
            </address>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-8 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400">
            &copy; {new Date().getFullYear()} Limburg Transport Marketplace. All rights reserved.
          </p>
          <div className="flex space-x-4 mt-4 md:mt-0">
            <a href="/terms" className="text-gray-400 hover:text-white">Terms of Service</a>
            <a href="/privacy" className="text-gray-400 hover:text-white">Privacy Policy</a>
            <a href="/cookies" className="text-gray-400 hover:text-white">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
