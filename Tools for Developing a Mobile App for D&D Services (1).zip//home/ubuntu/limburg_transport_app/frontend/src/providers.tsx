"use client";

import { ReactNode } from 'react';
import { AuthProvider } from './context/AuthContext';
import { RideProvider } from './context/RideContext';
import { PaymentProvider } from './context/PaymentContext';
import { ProviderContextProvider } from './context/ProviderContext';

export function Providers({ children }: { children: ReactNode }) {
  return (
    <AuthProvider>
      <RideProvider>
        <PaymentProvider>
          <ProviderContextProvider>
            {children}
          </ProviderContextProvider>
        </PaymentProvider>
      </RideProvider>
    </AuthProvider>
  );
}