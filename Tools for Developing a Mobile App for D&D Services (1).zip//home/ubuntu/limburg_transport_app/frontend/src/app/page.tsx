import MainLayout from '@/components/layout/MainLayout';
import { useAuth } from '@/context/AuthContext';
import Link from 'next/link';
import Image from 'next/image';

export default function Home() {
  const { isAuthenticated } = useAuth();

  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="bg-primary text-white py-16">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-8 md:mb-0">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                Your Transportation Solution in Limburg
              </h1>
              <p className="text-xl mb-8">
                Connect with local transportation providers for taxis, buses, healthcare transport, and more. All in one platform.
              </p>
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                {isAuthenticated ? (
                  <Link href="/dashboard" className="bg-white text-primary px-6 py-3 rounded-md font-medium text-center hover:bg-gray-100">
                    Go to Dashboard
                  </Link>
                ) : (
                  <>
                    <Link href="/register" className="bg-secondary text-white px-6 py-3 rounded-md font-medium text-center hover:bg-secondary-dark">
                      Sign Up Now
                    </Link>
                    <Link href="/login" className="bg-white text-primary px-6 py-3 rounded-md font-medium text-center hover:bg-gray-100">
                      Login
                    </Link>
                  </>
                )}
              </div>
            </div>
            <div className="md:w-1/2">
              <div className="relative h-64 md:h-96 w-full">
                {/* Placeholder for hero image */}
                <div className="absolute inset-0 bg-gray-300 rounded-lg flex items-center justify-center">
                  <span className="text-gray-600">Transportation Hero Image</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">How It Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold">1</span>
              </div>
              <h3 className="text-xl font-semibold mb-3">Choose Your Provider</h3>
              <p className="text-gray-600">
                Browse and select from our network of verified transportation providers in Limburg.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold">2</span>
              </div>
              <h3 className="text-xl font-semibold mb-3">Book Your Ride</h3>
              <p className="text-gray-600">
                Schedule an immediate or future ride with your preferred transportation service.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold">3</span>
              </div>
              <h3 className="text-xl font-semibold mb-3">Track & Pay</h3>
              <p className="text-gray-600">
                Track your ride in real-time and pay securely through our platform.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Our Services</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
              <div className="h-12 w-12 bg-primary-light rounded-lg flex items-center justify-center mb-4">
                <span className="text-primary text-xl">🚕</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Taxi Services</h3>
              <p className="text-gray-600">
                Connect with local taxi companies for immediate or scheduled rides.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
              <div className="h-12 w-12 bg-primary-light rounded-lg flex items-center justify-center mb-4">
                <span className="text-primary text-xl">🚌</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Public Transport</h3>
              <p className="text-gray-600">
                Access information and tickets for public transportation options.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
              <div className="h-12 w-12 bg-primary-light rounded-lg flex items-center justify-center mb-4">
                <span className="text-primary text-xl">🚑</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Healthcare Transport</h3>
              <p className="text-gray-600">
                Book non-urgent healthcare transportation services.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
              <div className="h-12 w-12 bg-primary-light rounded-lg flex items-center justify-center mb-4">
                <span className="text-primary text-xl">🚐</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Shuttle Services</h3>
              <p className="text-gray-600">
                Group transportation for events, airport transfers, and more.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Providers Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Featured Providers</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="h-40 bg-gray-200 rounded-md mb-4 flex items-center justify-center">
                <span className="text-gray-500">Provider Logo</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Hasseltse Taxi Maatschappij</h3>
              <div className="flex items-center mb-2">
                <div className="flex text-yellow-400">
                  <span>★</span><span>★</span><span>★</span><span>★</span><span>★</span>
                </div>
                <span className="ml-2 text-gray-600">5.0 (120 reviews)</span>
              </div>
              <p className="text-gray-600 mb-4">
                Premium taxi services throughout Hasselt and surrounding areas.
              </p>
              <Link href="/providers/1" className="text-primary font-medium hover:underline">
                View Details
              </Link>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="h-40 bg-gray-200 rounded-md mb-4 flex items-center justify-center">
                <span className="text-gray-500">Provider Logo</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Limburg Healthcare Transport</h3>
              <div className="flex items-center mb-2">
                <div className="flex text-yellow-400">
                  <span>★</span><span>★</span><span>★</span><span>★</span><span>★</span>
                </div>
                <span className="ml-2 text-gray-600">4.8 (95 reviews)</span>
              </div>
              <p className="text-gray-600 mb-4">
                Specialized in non-urgent medical transportation with trained staff.
              </p>
              <Link href="/providers/2" className="text-primary font-medium hover:underline">
                View Details
              </Link>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="h-40 bg-gray-200 rounded-md mb-4 flex items-center justify-center">
                <span className="text-gray-500">Provider Logo</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Genk City Shuttle</h3>
              <div className="flex items-center mb-2">
                <div className="flex text-yellow-400">
                  <span>★</span><span>★</span><span>★</span><span>★</span><span>☆</span>
                </div>
                <span className="ml-2 text-gray-600">4.5 (78 reviews)</span>
              </div>
              <p className="text-gray-600 mb-4">
                Affordable shuttle services for groups and regular city routes.
              </p>
              <Link href="/providers/3" className="text-primary font-medium hover:underline">
                View Details
              </Link>
            </div>
          </div>
          <div className="text-center mt-8">
            <Link href="/providers" className="inline-block bg-primary text-white px-6 py-3 rounded-md font-medium hover:bg-primary-dark">
              View All Providers
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">What Our Users Say</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
              <div className="flex items-center mb-4">
                <div className="h-12 w-12 bg-gray-200 rounded-full mr-4"></div>
                <div>
                  <h4 className="font-semibold">Marie Dubois</h4>
                  <div className="flex text-yellow-400">
                    <span>★</span><span>★</span><span>★</span><span>★</span><span>★</span>
                  </div>
                </div>
              </div>
              <p className="text-gray-600">
                "This platform has made it so much easier to find reliable transportation in Limburg. I use it weekly for my hospital appointments."
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
              <div className="flex items-center mb-4">
                <div className="h-12 w-12 bg-gray-200 rounded-full mr-4"></div>
                <div>
                  <h4 className="font-semibold">Jan Peeters</h4>
                  <div className="flex text-yellow-400">
                    <span>★</span><span>★</span><span>★</span><span>★</span><span>★</span>
                  </div>
                </div>
              </div>
              <p className="text-gray-600">
                "As someone who doesn't drive, having all transportation options in one app has been a game-changer. Highly recommended!"
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
              <div className="flex items-center mb-4">
                <div className="h-12 w-12 bg-gray-200 rounded-full mr-4"></div>
                <div>
                  <h4 className="font-semibold">Sophie Martens</h4>
                  <div className="flex text-yellow-400">
                    <span>★</span><span>★</span><span>★</span><span>★</span><span>☆</span>
                  </div>
                </div>
              </div>
              <p className="text-gray-600">
                "The real-time tracking feature gives me peace of mind when booking rides for my elderly parents. Great service!"
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Simplify Your Transportation?</h2>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            Join thousands of satisfied users across Limburg who have made their transportation easier, more reliable, and more convenient.
          </p>
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            {isAuthenticated ? (
              <Link href="/dashboard" className="bg-white text-primary px-8 py-3 rounded-md font-medium hover:bg-gray-100">
                Go to Dashboard
              </Link>
            ) : (
              <>
                <Link href="/register" className="bg-secondary text-white px-8 py-3 rounded-md font-medium hover:bg-secondary-dark">
                  Sign Up Now
                </Link>
                <Link href="/providers/register" className="bg-transparent border-2 border-white text-white px-8 py-3 rounded-md font-medium hover:bg-white hover:text-primary">
                  Register as Provider
                </Link>
              </>
            )}
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
