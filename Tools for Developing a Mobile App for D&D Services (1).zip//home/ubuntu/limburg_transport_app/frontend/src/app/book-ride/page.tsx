import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useState, useEffect } from 'react';
import { useRide } from '@/context/RideContext';
import { useProvider } from '@/context/ProviderContext';
import { useAuth } from '@/context/AuthContext';
import MainLayout from '@/components/layout/MainLayout';
import Link from 'next/link';

// Define validation schema
const bookingSchema = z.object({
  providerId: z.string().min(1, 'Please select a provider'),
  serviceType: z.string().min(1, 'Please select a service type'),
  pickupAddress: z.string().min(5, 'Please enter a valid pickup address'),
  destinationAddress: z.string().min(5, 'Please enter a valid destination address'),
  pickupNotes: z.string().optional(),
  destinationNotes: z.string().optional(),
  rideType: z.enum(['immediate', 'scheduled']),
  scheduledTime: z.string().optional(),
  passengerCount: z.number().min(1, 'At least 1 passenger is required').max(10, 'Maximum 10 passengers allowed'),
  paymentMethod: z.string().min(1, 'Please select a payment method'),
  specialRequirements: z.array(z.string()).optional(),
});

type BookingFormData = z.infer<typeof bookingSchema>;

export default function BookRide() {
  const { user, isAuthenticated } = useAuth();
  const { providers, getProviders, loading: providersLoading } = useProvider();
  const { requestRide, loading: rideLoading, error: rideError } = useRide();
  const [isScheduled, setIsScheduled] = useState(false);
  const [success, setSuccess] = useState(false);
  const [bookingId, setBookingId] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors }
  } = useForm<BookingFormData>({
    resolver: zodResolver(bookingSchema),
    defaultValues: {
      rideType: 'immediate',
      passengerCount: 1,
      specialRequirements: []
    }
  });

  const rideType = watch('rideType');
  const selectedProviderId = watch('providerId');

  // Load providers on component mount
  useEffect(() => {
    getProviders();
  }, [getProviders]);

  // Update isScheduled state when rideType changes
  useEffect(() => {
    setIsScheduled(rideType === 'scheduled');
  }, [rideType]);

  // Get selected provider's service types
  const selectedProvider = providers.find(p => p._id === selectedProviderId);
  const serviceTypes = selectedProvider?.serviceTypes || [];

  const onSubmit = async (data: BookingFormData) => {
    if (!isAuthenticated) {
      return;
    }

    try {
      // Format the data for the API
      const rideData = {
        providerId: data.providerId,
        rideType: data.rideType,
        serviceType: data.serviceType,
        pickup: {
          address: data.pickupAddress,
          coordinates: {
            latitude: 0, // Would be set by map integration
            longitude: 0, // Would be set by map integration
          },
          notes: data.pickupNotes
        },
        destination: {
          address: data.destinationAddress,
          coordinates: {
            latitude: 0, // Would be set by map integration
            longitude: 0, // Would be set by map integration
          },
          notes: data.destinationNotes
        },
        scheduledTime: data.scheduledTime,
        paymentMethod: data.paymentMethod,
        specialRequirements: data.specialRequirements,
        passengerCount: data.passengerCount
      };

      const result = await requestRide(rideData);
      
      if (result) {
        setSuccess(true);
        setBookingId(result._id);
      }
    } catch (error) {
      console.error('Error booking ride:', error);
    }
  };

  if (!isAuthenticated) {
    return (
      <MainLayout>
        <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
          <div className="sm:mx-auto sm:w-full sm:max-w-md">
            <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
              Please login to book a ride
            </h2>
            <p className="mt-2 text-center text-sm text-gray-600">
              You need to be logged in to book transportation services.
            </p>
            <div className="mt-8 flex justify-center">
              <Link href="/login" className="bg-primary text-white px-6 py-3 rounded-md font-medium hover:bg-primary-dark">
                Login
              </Link>
              <Link href="/register" className="ml-4 bg-secondary text-white px-6 py-3 rounded-md font-medium hover:bg-secondary-dark">
                Register
              </Link>
            </div>
          </div>
        </div>
      </MainLayout>
    );
  }

  if (success && bookingId) {
    return (
      <MainLayout>
        <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
          <div className="sm:mx-auto sm:w-full sm:max-w-md">
            <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
              <div className="text-center">
                <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100">
                  <svg className="h-6 w-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <h3 className="mt-3 text-lg font-medium text-gray-900">Booking Successful!</h3>
                <p className="mt-2 text-sm text-gray-500">
                  Your ride has been booked successfully. Your booking ID is:
                </p>
                <p className="mt-1 text-lg font-bold text-primary">
                  {bookingId}
                </p>
                <div className="mt-6">
                  <Link href={`/rides/${bookingId}`} className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary">
                    View Ride Details
                  </Link>
                </div>
                <div className="mt-3">
                  <Link href="/dashboard" className="text-sm font-medium text-primary hover:text-primary-dark">
                    Go to Dashboard
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-extrabold text-gray-900 text-center mb-8">
            Book a Ride
          </h1>

          <div className="bg-white shadow overflow-hidden sm:rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              {rideError && (
                <div className="mb-4 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
                  {rideError}
                </div>
              )}

              <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                <div>
                  <label htmlFor="providerId" className="block text-sm font-medium text-gray-700">
                    Transportation Provider
                  </label>
                  <div className="mt-1">
                    <select
                      id="providerId"
                      className={`mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm rounded-md ${
                        errors.providerId ? 'border-red-300' : 'border-gray-300'
                      }`}
                      {...register('providerId')}
                      disabled={providersLoading}
                    >
                      <option value="">Select a provider</option>
                      {providers.map((provider) => (
                        <option key={provider._id} value={provider._id}>
                          {provider.companyName}
                        </option>
                      ))}
                    </select>
                    {errors.providerId && (
                      <p className="mt-2 text-sm text-red-600">{errors.providerId.message}</p>
                    )}
                  </div>
                </div>

                {selectedProviderId && (
                  <div>
                    <label htmlFor="serviceType" className="block text-sm font-medium text-gray-700">
                      Service Type
                    </label>
                    <div className="mt-1">
                      <select
                        id="serviceType"
                        className={`mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm rounded-md ${
                          errors.serviceType ? 'border-red-300' : 'border-gray-300'
                        }`}
                        {...register('serviceType')}
                      >
                        <option value="">Select a service type</option>
                        {serviceTypes.map((type) => (
                          <option key={type} value={type}>
                            {type}
                          </option>
                        ))}
                      </select>
                      {errors.serviceType && (
                        <p className="mt-2 text-sm text-red-600">{errors.serviceType.message}</p>
                      )}
                    </div>
                  </div>
                )}

                <div>
                  <label htmlFor="pickupAddress" className="block text-sm font-medium text-gray-700">
                    Pickup Location
                  </label>
                  <div className="mt-1">
                    <input
                      type="text"
                      id="pickupAddress"
                      className={`shadow-sm focus:ring-primary focus:border-primary block w-full sm:text-sm border-gray-300 rounded-md ${
                        errors.pickupAddress ? 'border-red-300' : 'border-gray-300'
                      }`}
                      placeholder="Enter pickup address"
                      {...register('pickupAddress')}
                    />
                    {errors.pickupAddress && (
                      <p className="mt-2 text-sm text-red-600">{errors.pickupAddress.message}</p>
                    )}
                  </div>
                </div>

                <div>
                  <label htmlFor="pickupNotes" className="block text-sm font-medium text-gray-700">
                    Pickup Notes (Optional)
                  </label>
                  <div className="mt-1">
                    <textarea
                      id="pickupNotes"
                      rows={2}
                      className="shadow-sm focus:ring-primary focus:border-primary block w-full sm:text-sm border-gray-300 rounded-md"
                      placeholder="E.g., Building entrance details, landmarks, etc."
                      {...register('pickupNotes')}
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="destinationAddress" className="block text-sm font-medium text-gray-700">
                    Destination
                  </label>
                  <div className="mt-1">
                    <input
                      type="text"
                      id="destinationAddress"
                      className={`shadow-sm focus:ring-primary focus:border-primary block w-full sm:text-sm border-gray-300 rounded-md ${
                        errors.destinationAddress ? 'border-red-300' : 'border-gray-300'
                      }`}
                      placeholder="Enter destination address"
                      {...register('destinationAddress')}
                    />
                    {errors.destinationAddress && (
                      <p className="mt-2 text-sm text-red-600">{errors.destinationAddress.message}</p>
                    )}
                  </div>
                </div>

                <div>
                  <label htmlFor="destinationNotes" className="block text-sm font-medium text-gray-700">
                    Destination Notes (Optional)
                  </label>
                  <div className="mt-1">
                    <textarea
                      id="destinationNotes"
                      rows={2}
                      className="shadow-sm focus:ring-primary focus:border-primary block w-full sm:text-sm border-gray-300 rounded-md"
                      placeholder="E.g., Building entrance details, landmarks, etc."
                      {...register('destinationNotes')}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Ride Type</label>
                  <div className="mt-2 space-y-4 sm:flex sm:items-center sm:space-y-0 sm:space-x-10">
                    <div className="flex items-center">
                      <input
                        id="immediate"
                        type="radio"
                        value="immediate"
                        className="focus:ring-primary h-4 w-4 text-primary border-gray-300"
                        {...register('rideType')}
                      />
                      <label htmlFor="immediate" className="ml-3 block text-sm font-medium text-gray-700">
                        Immediate
                      </label>
                    </div>
                    <div className="flex items-center">
                      <input
                        id="scheduled"
                        type="radio"
                        value="scheduled"
                        className="focus:ring-primary h-4 w-4 text-primary border-gray-300"
                        {...register('rideType')}
                      />
                      <label htmlFor="scheduled" className="ml-3 block text-sm font-medium text-gray-700">
                        Scheduled
                      </label>
                    </div>
                  </div>
                </div>

                {isScheduled && (
                  <div>
                    <label htmlFor="scheduledTime" className="block text-sm font-medium text-gray-700">
                      Scheduled Time
                    </label>
                    <div className="mt-1">
                      <input
                        type="datetime-local"
                        id="scheduledTime"
                        className={`shadow-sm focus:ring-primary focus:border-primary block w-full sm:text-sm border-gray-300 rounded-md ${
                          errors.scheduledTime ? 'border-red-300' : 'border-gray-300'
                        }`}
                        {...register('scheduledTime')}
                      />
                      {errors.scheduledTime && (
                        <p className="mt-2 text-sm text-red-600">{errors.scheduledTime.message}</p>
                      )}
                    </div>
                  </div>
                )}

                <div>
                  <label htmlFor="passengerCount" className="block text-sm font-medium text-gray-700">
                    Number of Passengers
                  </label>
                  <div className="mt-1">
                    <input
                      type="number"
                      id="passengerCount"
                      min="1"
                      max="10"
                      className={`shadow-sm focus:ring-primary focus:border-primary block w-full sm:text-sm border-gray-300 rounded-md ${
                        errors.passengerCount ? 'border-red-300' : 'border-gray-300'
      
(Content truncated due to size limit. Use line ranges to read in chunks)