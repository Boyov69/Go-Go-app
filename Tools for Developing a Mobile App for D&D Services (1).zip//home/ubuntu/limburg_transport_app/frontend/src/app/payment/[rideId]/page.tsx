"use client";

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useState, useEffect } from 'react';
import { usePayment } from '@/context/PaymentContext';
import { useAuth } from '@/context/AuthContext';
import MainLayout from '@/components/layout/MainLayout';
import { useRouter } from 'next/navigation';

const paymentSchema = z.object({
  cardNumber: z.string().regex(/^\d{16}$/, 'Card number must be 16 digits'),
  cardholderName: z.string().min(3, 'Cardholder name is required'),
  expiryDate: z.string().regex(/^(0[1-9]|1[0-2])\/\d{2}$/, 'Expiry date must be in MM/YY format'),
  cvv: z.string().regex(/^\d{3,4}$/, 'CVV must be 3 or 4 digits'),
});

type PaymentFormData = z.infer<typeof paymentSchema>;

export default function PaymentPage({ params }: { params: { rideId: string } }) {
  const router = useRouter();
  const { rideId } = params;
  const { user, isAuthenticated } = useAuth();
  const { processPayment, getRideDetails, loading, error: paymentError } = usePayment();
  const [rideDetails, setRideDetails] = useState<any>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [success, setSuccess] = useState('');

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<PaymentFormData>({
    resolver: zodResolver(paymentSchema),
  });

  useEffect(() => {
    if (isAuthenticated && rideId) {
      const fetchRideDetails = async () => {
        try {
          const details = await getRideDetails(rideId);
          setRideDetails(details);
        } catch (err) {
          console.error('Failed to fetch ride details:', err);
        }
      };
      
      fetchRideDetails();
    }
  }, [isAuthenticated, rideId, getRideDetails]);

  const onSubmit = async (data: PaymentFormData) => {
    if (!rideDetails) return;
    
    setIsProcessing(true);
    setSuccess('');

    try {
      await processPayment({
        rideId,
        amount: rideDetails.estimatedPrice,
        paymentMethod: {
          type: 'credit_card',
          cardNumber: data.cardNumber,
          cardholderName: data.cardholderName,
          expiryDate: data.expiryDate,
          cvv: data.cvv,
        },
      });
      
      setSuccess('Payment successful! Redirecting to your dashboard...');
      
      // Redirect after successful payment
      setTimeout(() => {
        router.push('/dashboard');
      }, 2000);
    } catch (err) {
      console.error('Payment processing error:', err);
    } finally {
      setIsProcessing(false);
    }
  };

  if (!isAuthenticated) {
    return (
      <MainLayout>
        <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
          <div className="sm:mx-auto sm:w-full sm:max-w-md">
            <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
              Please login to process payment
            </h2>
            <p className="mt-2 text-center text-sm text-gray-600">
              You need to be logged in to access this page.
            </p>
          </div>
        </div>
      </MainLayout>
    );
  }

  if (loading || !rideDetails) {
    return (
      <MainLayout>
        <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
          <div className="sm:mx-auto sm:w-full sm:max-w-md">
            <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
              Loading ride details...
            </h2>
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto">
            <h1 className="text-3xl font-bold text-gray-900 text-center mb-8">
              Complete Your Payment
            </h1>

            <div className="bg-white shadow overflow-hidden sm:rounded-lg mb-8">
              <div className="px-4 py-5 sm:px-6">
                <h3 className="text-lg leading-6 font-medium text-gray-900">
                  Ride Summary
                </h3>
                <p className="mt-1 max-w-2xl text-sm text-gray-500">
                  Review your ride details before payment.
                </p>
              </div>
              <div className="border-t border-gray-200 px-4 py-5 sm:p-0">
                <dl className="sm:divide-y sm:divide-gray-200">
                  <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                    <dt className="text-sm font-medium text-gray-500">
                      Pickup Location
                    </dt>
                    <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                      {rideDetails.pickup?.address || 'Not specified'}
                    </dd>
                  </div>
                  <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                    <dt className="text-sm font-medium text-gray-500">
                      Destination
                    </dt>
                    <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                      {rideDetails.destination?.address || 'Not specified'}
                    </dd>
                  </div>
                  <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                    <dt className="text-sm font-medium text-gray-500">
                      Service Type
                    </dt>
                    <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                      {rideDetails.serviceType || 'Standard'}
                    </dd>
                  </div>
                  <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                    <dt className="text-sm font-medium text-gray-500">
                      Estimated Distance
                    </dt>
                    <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                      {rideDetails.estimatedDistance ? `${rideDetails.estimatedDistance} km` : 'Not calculated'}
                    </dd>
                  </div>
                  <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                    <dt className="text-sm font-medium text-gray-500">
                      Estimated Duration
                    </dt>
                    <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                      {rideDetails.estimatedDuration ? `${Math.round(rideDetails.estimatedDuration / 60)} minutes` : 'Not calculated'}
                    </dd>
                  </div>
                  <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                    <dt className="text-sm font-medium text-gray-500">
                      Provider
                    </dt>
                    <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                      {typeof rideDetails.providerId === 'object' ? rideDetails.providerId.companyName : 'Not assigned yet'}
                    </dd>
                  </div>
                  <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                    <dt className="text-sm font-medium text-gray-500">
                      Total Amount
                    </dt>
                    <dd className="mt-1 text-sm font-bold text-gray-900 sm:mt-0 sm:col-span-2">
                      €{rideDetails.estimatedPrice?.toFixed(2) || '0.00'}
                    </dd>
                  </div>
                </dl>
              </div>
            </div>

            {paymentError && (
              <div className="mb-4 bg-red-50 border-l-4 border-red-400 p-4">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <svg className="h-5 w-5 text-red-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm text-red-700">{paymentError}</p>
                  </div>
                </div>
              </div>
            )}

            {success && (
              <div className="mb-4 bg-green-50 border-l-4 border-green-400 p-4">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <svg className="h-5 w-5 text-green-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm text-green-700">{success}</p>
                  </div>
                </div>
              </div>
            )}

            <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
              <form className="space-y-6" onSubmit={handleSubmit(onSubmit)}>
                <div>
                  <label htmlFor="cardNumber" className="block text-sm font-medium text-gray-700">
                    Card Number
                  </label>
                  <div className="mt-1">
                    <input
                      id="cardNumber"
                      type="text"
                      autoComplete="cc-number"
                      placeholder="1234 5678 9012 3456"
                      className={`appearance-none block w-full px-3 py-2 border ${
                        errors.cardNumber ? 'border-red-300' : 'border-gray-300'
                      } rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm`}
                      {...register('cardNumber')}
                    />
                    {errors.cardNumber && (
                      <p className="mt-2 text-sm text-red-600">{errors.cardNumber.message}</p>
                    )}
                  </div>
                </div>

                <div>
                  <label htmlFor="cardholderName" className="block text-sm font-medium text-gray-700">
                    Cardholder Name
                  </label>
                  <div className="mt-1">
                    <input
                      id="cardholderName"
                      type="text"
                      autoComplete="cc-name"
                      placeholder="John Doe"
                      className={`appearance-none block w-full px-3 py-2 border ${
                        errors.cardholderName ? 'border-red-300' : 'border-gray-300'
                      } rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm`}
                      {...register('cardholderName')}
                    />
                    {errors.cardholderName && (
                      <p className="mt-2 text-sm text-red-600">{errors.cardholderName.message}</p>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="expiryDate" className="block text-sm font-medium text-gray-700">
                      Expiry Date
                    </label>
                    <div className="mt-1">
                      <input
                        id="expiryDate"
                        type="text"
                        autoComplete="cc-exp"
                        placeholder="MM/YY"
                        className={`appearance-none block w-full px-3 py-2 border ${
                          errors.expiryDate ? 'border-red-300' : 'border-gray-300'
                        } rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm`}
                        {...register('expiryDate')}
                      />
                      {errors.expiryDate && (
                        <p className="mt-2 text-sm text-red-600">{errors.expiryDate.message}</p>
                      )}
                    </div>
                  </div>

                  <div>
                    <label htmlFor="cvv" className="block text-sm font-medium text-gray-700">
                      CVV
                    </label>
                    <div className="mt-1">
                      <input
                        id="cvv"
                        type="text"
                        autoComplete="cc-csc"
                        placeholder="123"
                        className={`appearance-none block w-full px-3 py-2 border ${
                          errors.cvv ? 'border-red-300' : 'border-gray-300'
                        } rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm`}
                        {...register('cvv')}
                      />
                      {errors.cvv && (
                        <p className="mt-2 text-sm text-red-600">{errors.cvv.message}</p>
                      )}
                    </div>
                  </div>
                </div>

                <div>
                  <button
                    type="submit"
                    disabled={isProcessing}
                    className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary disabled:opacity-50"
                  >
                    {isProcessing ? 'Processing...' : `Pay €${rideDetails.estimatedPrice?.toFixed(2) || '0.00'}`}
                  </button>
                </div>
              </form>

              <div className="mt-6">
                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-gray-300" />
                  </div>
                  <div className="relative flex justify-center text-sm">
                    <span className="px-2 bg-white text-gray-500">Secure payment</span>
                  </div>
                </div>

                <div className="mt-6 flex justify-center space-x-6">
                  <div className="flex items-center">
                    <svg className="h-10 w-10 text-gray-400" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm-1-8v2h2v-2h-2zm0-8v6h2V6h-2z" />
                    </svg>
                    <span className="ml-2 text-sm text-gray-500">Secure SSL Encryption</span>
                  </div>
                  <div className="flex items-center">
                    <svg className="h-10 w-10 text-gray-400" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm-1-8v2h2v-2h-2zm0-8v6h2V6h-2z" />
                    </svg>
                    <span className="ml-2 text-sm text-gray-500">PCI DSS Compliant</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
