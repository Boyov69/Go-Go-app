import { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import MainLayout from '@/components/layout/MainLayout';
import Link from 'next/link';

// Provider dashboard tabs
const tabs = [
  { name: 'Overview', href: '#overview', current: true },
  { name: 'Vehicles', href: '#vehicles', current: false },
  { name: 'Drivers', href: '#drivers', current: false },
  { name: 'Rides', href: '#rides', current: false },
  { name: 'Earnings', href: '#earnings', current: false },
  { name: 'Settings', href: '#settings', current: false },
];

export default function ProviderDashboard() {
  const { user, isAuthenticated } = useAuth();
  const [currentTab, setCurrentTab] = useState('Overview');
  const [provider, setProvider] = useState(null);
  const [vehicles, setVehicles] = useState([]);
  const [drivers, setDrivers] = useState([]);
  const [rides, setRides] = useState([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalRides: 0,
    completedRides: 0,
    cancelledRides: 0,
    totalEarnings: 0,
    activeDrivers: 0,
    availableVehicles: 0
  });

  // Fetch provider data
  useEffect(() => {
    const fetchProviderData = async () => {
      if (!isAuthenticated) return;
      
      try {
        setLoading(true);
        
        // In a real implementation, these would be API calls
        // For now, we'll use mock data
        
        // Mock provider data
        const mockProvider = {
          _id: 'provider123',
          companyName: 'Hasseltse Taxi Maatschappij',
          email: 'info@htmtaxi.be',
          phone: '+32 11 22 33 44',
          address: {
            street: 'Koning Albertstraat 15',
            city: 'Hasselt',
            state: 'Limburg',
            postalCode: '3500',
            country: 'Belgium'
          },
          serviceTypes: ['Standard Taxi', 'Luxury Taxi', 'Van', 'Wheelchair Accessible'],
          operatingAreas: ['Hasselt', 'Genk', 'Sint-Truiden', 'Tongeren'],
          logo: 'https://example.com/logo.png',
          verificationStatus: 'verified',
          ratingAverage: 4.8,
          ratingCount: 156
        };
        
        // Mock vehicles data
        const mockVehicles = [
          {
            _id: 'vehicle1',
            make: 'Mercedes-Benz',
            model: 'E-Class',
            year: 2023,
            licensePlate: 'HTM-001',
            color: 'Black',
            capacity: 4,
            vehicleType: 'Luxury Taxi',
            status: 'active',
            features: ['Leather Seats', 'WiFi', 'Child Seat Available']
          },
          {
            _id: 'vehicle2',
            make: 'Toyota',
            model: 'Prius',
            year: 2022,
            licensePlate: 'HTM-002',
            color: 'Silver',
            capacity: 4,
            vehicleType: 'Standard Taxi',
            status: 'active',
            features: ['Eco-Friendly', 'WiFi']
          },
          {
            _id: 'vehicle3',
            make: 'Volkswagen',
            model: 'Transporter',
            year: 2021,
            licensePlate: 'HTM-003',
            color: 'White',
            capacity: 8,
            vehicleType: 'Van',
            status: 'maintenance',
            features: ['Wheelchair Accessible', 'Extra Luggage Space']
          }
        ];
        
        // Mock drivers data
        const mockDrivers = [
          {
            _id: 'driver1',
            firstName: 'Jan',
            lastName: 'Peeters',
            email: 'jan.peeters@htmtaxi.be',
            phone: '+32 470 11 22 33',
            licenseNumber: 'B123456',
            licenseExpiry: '2026-05-15',
            status: 'active',
            rating: 4.9,
            assignedVehicle: 'vehicle1'
          },
          {
            _id: 'driver2',
            firstName: 'Marie',
            lastName: 'Janssens',
            email: 'marie.janssens@htmtaxi.be',
            phone: '+32 470 22 33 44',
            licenseNumber: 'B234567',
            licenseExpiry: '2025-08-22',
            status: 'active',
            rating: 4.7,
            assignedVehicle: 'vehicle2'
          },
          {
            _id: 'driver3',
            firstName: 'Thomas',
            lastName: 'Maes',
            email: 'thomas.maes@htmtaxi.be',
            phone: '+32 470 33 44 55',
            licenseNumber: 'B345678',
            licenseExpiry: '2024-11-30',
            status: 'off_duty',
            rating: 4.8,
            assignedVehicle: 'vehicle3'
          }
        ];
        
        // Mock rides data
        const mockRides = [
          {
            _id: 'ride1',
            status: 'completed',
            rideType: 'immediate',
            serviceType: 'Luxury Taxi',
            pickup: {
              address: 'Hasselt Station, Hasselt',
              coordinates: { latitude: 50.9307, longitude: 5.3425 }
            },
            destination: {
              address: 'Corda Campus, Hasselt',
              coordinates: { latitude: 50.9512, longitude: 5.3485 }
            },
            requestTime: '2025-03-30T10:15:00Z',
            completedTime: '2025-03-30T10:45:00Z',
            price: 18.50,
            currency: 'EUR',
            driverId: 'driver1',
            vehicleId: 'vehicle1',
            rating: { score: 5, comment: 'Excellent service!' }
          },
          {
            _id: 'ride2',
            status: 'in_progress',
            rideType: 'immediate',
            serviceType: 'Standard Taxi',
            pickup: {
              address: 'Ethias Arena, Hasselt',
              coordinates: { latitude: 50.9467, longitude: 5.3491 }
            },
            destination: {
              address: 'Grote Markt, Hasselt',
              coordinates: { latitude: 50.9307, longitude: 5.3387 }
            },
            requestTime: '2025-03-30T15:30:00Z',
            price: 12.75,
            currency: 'EUR',
            driverId: 'driver2',
            vehicleId: 'vehicle2'
          },
          {
            _id: 'ride3',
            status: 'pending',
            rideType: 'scheduled',
            serviceType: 'Van',
            pickup: {
              address: 'Jessa Ziekenhuis, Hasselt',
              coordinates: { latitude: 50.9382, longitude: 5.3559 }
            },
            destination: {
              address: 'Brussels Airport, Zaventem',
              coordinates: { latitude: 50.8863, longitude: 4.4841 }
            },
            requestTime: '2025-03-29T18:00:00Z',
            scheduledTime: '2025-03-31T08:00:00Z',
            price: 95.00,
            currency: 'EUR'
          }
        ];
        
        // Calculate stats
        const mockStats = {
          totalRides: mockRides.length,
          completedRides: mockRides.filter(ride => ride.status === 'completed').length,
          cancelledRides: mockRides.filter(ride => ride.status === 'cancelled').length,
          totalEarnings: mockRides.filter(ride => ride.status === 'completed').reduce((sum, ride) => sum + ride.price, 0),
          activeDrivers: mockDrivers.filter(driver => driver.status === 'active').length,
          availableVehicles: mockVehicles.filter(vehicle => vehicle.status === 'active').length
        };
        
        setProvider(mockProvider);
        setVehicles(mockVehicles);
        setDrivers(mockDrivers);
        setRides(mockRides);
        setStats(mockStats);
      } catch (error) {
        console.error('Error fetching provider data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchProviderData();
  }, [isAuthenticated]);

  const handleTabChange = (tabName) => {
    setCurrentTab(tabName);
  };

  if (!isAuthenticated) {
    return (
      <MainLayout>
        <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
          <div className="sm:mx-auto sm:w-full sm:max-w-md">
            <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
              Provider Access Required
            </h2>
            <p className="mt-2 text-center text-sm text-gray-600">
              You need to be logged in as a transportation provider to access this page.
            </p>
            <div className="mt-8 flex justify-center">
              <Link href="/provider/login" className="bg-primary text-white px-6 py-3 rounded-md font-medium hover:bg-primary-dark">
                Provider Login
              </Link>
              <Link href="/provider/register" className="ml-4 bg-secondary text-white px-6 py-3 rounded-md font-medium hover:bg-secondary-dark">
                Register as Provider
              </Link>
            </div>
          </div>
        </div>
      </MainLayout>
    );
  }

  if (loading) {
    return (
      <MainLayout>
        <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
          <div className="sm:mx-auto sm:w-full sm:max-w-md">
            <div className="text-center">
              <p>Loading provider dashboard...</p>
            </div>
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="min-h-screen bg-gray-50">
        {/* Provider Header */}
        <div className="bg-white shadow">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="md:flex md:items-center md:justify-between">
              <div className="flex-1 min-w-0">
                <h1 className="text-3xl font-bold text-gray-900">
                  {provider?.companyName || 'Provider Dashboard'}
                </h1>
                <p className="mt-1 text-sm text-gray-500">
                  Manage your transportation services, vehicles, drivers, and bookings.
                </p>
              </div>
              <div className="mt-4 flex md:mt-0 md:ml-4">
                <span className="inline-flex items-center px-3 py-0.5 rounded-full text-sm font-medium bg-green-100 text-green-800">
                  {provider?.verificationStatus === 'verified' ? 'Verified Provider' : 'Pending Verification'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <nav className="-mb-px flex space-x-8" aria-label="Tabs">
              {tabs.map((tab) => (
                <button
                  key={tab.name}
                  onClick={() => handleTabChange(tab.name)}
                  className={`${
                    currentTab === tab.name
                      ? 'border-primary text-primary'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
                  aria-current={currentTab === tab.name ? 'page' : undefined}
                >
                  {tab.name}
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Content */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Overview Tab */}
          {currentTab === 'Overview' && (
            <div>
              <h2 className="text-lg font-medium text-gray-900 mb-6">Dashboard Overview</h2>
              
              {/* Stats */}
              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
                <div className="bg-white overflow-hidden shadow rounded-lg">
                  <div className="px-4 py-5 sm:p-6">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 bg-primary-light rounded-md p-3">
                        <svg className="h-6 w-6 text-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                        </svg>
                      </div>
                      <div className="ml-5 w-0 flex-1">
                        <dl>
                          <dt className="text-sm font-medium text-gray-500 truncate">
                            Total Rides
                          </dt>
                          <dd>
                            <div className="text-lg font-medium text-gray-900">
                              {stats.totalRides}
                            </div>
                          </dd>
                        </dl>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-white overflow-hidden shadow rounded-lg">
                  <div className="px-4 py-5 sm:p-6">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 bg-green-100 rounded-md p-3">
                        <svg className="h-6 w-6 text-green-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                      </div>
                      <div className="ml-5 w-0 flex-1">
                        <dl>
                          <dt className="text-sm font-medium text-gray-500 truncate">
                            Total Earnings
                          </dt>
                          <dd>
                            <div className="text-lg font-medium text-gray-900">
                              €{stats.totalEarnings.toFixed(2)}
                            </div>
                          </dd>
                        </dl>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-white overflow-hidden shadow rounded-lg">
                  <div className="px-4 py-5 sm:p-6">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 bg-blue-100 rounded-md p-3">
                        <svg className="h-6 w-6 text-blue-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                        </svg>
                      </div>
                      <div className="ml-5 w-0 flex-1">
                        <dl>
                          <dt className="text-sm font-medium text-gray-500 truncate">
                            Active Drivers
                          </dt>
                          <dd>
                            <div className="text-lg font-medium text-gray-900">
                              {stats.activeDrivers} / {drivers.length}
                            </div>
                          </dd>
                        </dl>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Recent Rides */}
              <div className="mt-8">
                <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
                  Recent Rides
                </h3>
                <div className="overflow-hidden shadow ring-1 ring-black ri
(Content truncated due to size limit. Use line ranges to read in chunks)