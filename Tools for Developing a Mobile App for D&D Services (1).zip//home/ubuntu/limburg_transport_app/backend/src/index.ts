import express, { Application } from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import morgan from 'morgan';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';

// Load environment variables
dotenv.config();

// Import routes
import providerRoutes from './routes/provider.routes';
import vehicleRoutes from './routes/vehicle.routes';
import driverRoutes from './routes/driver.routes';

// Import middleware
import { errorHandler, notFound, requestLogger, corsErrorHandler, fileSizeLimiter } from './middleware/error.middleware';

// Import config
import config from './config/config';
import logger from './utils/logger';

// Create Express application
const app: Application = express();

// Create logs directory if it doesn't exist
const logsDir = path.join(__dirname, '../logs');
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir, { recursive: true });
}

// Middleware
app.use(cors({
  origin: config.corsOrigin,
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(morgan('dev'));
app.use(requestLogger);

// API Routes
app.use('/api/providers', providerRoutes);
app.use('/api/vehicles', vehicleRoutes);
app.use('/api/drivers', driverRoutes);

// Health check route
app.get('/health', (req, res) => {
  res.status(200).json({
    status: 'success',
    message: 'Server is running',
    environment: config.env,
    timestamp: new Date()
  });
});

// Error handling middleware
app.use(notFound);
app.use(corsErrorHandler);
app.use(fileSizeLimiter);
app.use(errorHandler);

// Connect to MongoDB
const connectDB = async () => {
  try {
    const conn = await mongoose.connect(config.mongoUri);
    logger.info(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    logger.error('Error connecting to MongoDB', { error });
    process.exit(1);
  }
};

// Start server
const PORT = config.port;
const startServer = async () => {
  await connectDB();
  
  const server = app.listen(PORT, () => {
    logger.info(`Server running in ${config.env} mode on port ${PORT}`);
  });
  
  // Handle unhandled promise rejections
  process.on('unhandledRejection', (err: Error) => {
    logger.error('Unhandled Rejection', { error: err });
    // Close server & exit process
    server.close(() => process.exit(1));
  });
};

// Export for testing
export { app, startServer };

// Start server if file is run directly
if (require.main === module) {
  startServer();
}
