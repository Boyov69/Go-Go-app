import mongoose, { Document, Schema } from 'mongoose';

// Define interface for Payment document
export interface IPayment extends Document {
  rideId: mongoose.Types.ObjectId;
  userId: mongoose.Types.ObjectId;
  providerId: mongoose.Types.ObjectId;
  amount: number;
  currency: string;
  status: string;
  paymentMethod: string;
  paymentIntentId?: string;
  paymentProviderFee?: number;
  platformFee?: number;
  providerAmount?: number;
  refundAmount?: number;
  refundReason?: string;
  receiptUrl?: string;
  metadata?: Record<string, any>;
  errorMessage?: string;
}

// Create Payment schema
const PaymentSchema: Schema = new Schema(
  {
    rideId: {
      type: Schema.Types.ObjectId,
      ref: 'Ride',
      required: [true, 'Ride ID is required'],
    },
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'User ID is required'],
    },
    providerId: {
      type: Schema.Types.ObjectId,
      ref: 'Provider',
      required: [true, 'Provider ID is required'],
    },
    amount: {
      type: Number,
      required: [true, 'Payment amount is required'],
      min: [0, 'Payment amount cannot be negative'],
    },
    currency: {
      type: String,
      required: [true, 'Currency is required'],
      default: 'EUR',
    },
    status: {
      type: String,
      required: true,
      enum: ['pending', 'processing', 'completed', 'failed', 'refunded', 'partially_refunded'],
      default: 'pending',
    },
    paymentMethod: {
      type: String,
      required: true,
      enum: ['credit_card', 'debit_card', 'paypal', 'apple_pay', 'google_pay', 'cash'],
    },
    paymentIntentId: {
      type: String,
    },
    paymentProviderFee: {
      type: Number,
      min: [0, 'Payment provider fee cannot be negative'],
    },
    platformFee: {
      type: Number,
      min: [0, 'Platform fee cannot be negative'],
    },
    providerAmount: {
      type: Number,
      min: [0, 'Provider amount cannot be negative'],
    },
    refundAmount: {
      type: Number,
      min: [0, 'Refund amount cannot be negative'],
    },
    refundReason: {
      type: String,
    },
    receiptUrl: {
      type: String,
    },
    metadata: {
      type: Schema.Types.Mixed,
    },
    errorMessage: {
      type: String,
    },
  },
  {
    timestamps: true,
  }
);

// Create and export Payment model
const Payment = mongoose.model<IPayment>('Payment', PaymentSchema);

export default Payment;
