import mongoose, { Document, Schema } from 'mongoose';
import bcrypt from 'bcryptjs';

// Define interface for Driver document
export interface IDriver extends Document {
  providerId: mongoose.Types.ObjectId;
  userId?: mongoose.Types.ObjectId;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  profilePicture?: string;
  address: {
    street: string;
    city: string;
    state: string;
    postalCode: string;
    country: string;
  };
  dateOfBirth: Date;
  licenseNumber: string;
  licenseExpiryDate: Date;
  documents?: {
    type: string;
    url: string;
    verificationStatus: string;
    expiryDate?: Date;
  }[];
  status: string;
  verificationStatus: string;
  currentLocation?: {
    latitude: number;
    longitude: number;
    updatedAt: Date;
  };
  currentVehicleId?: mongoose.Types.ObjectId;
  isAvailable: boolean;
  ratingAverage?: number;
  ratingCount?: number;
}

// Create Driver schema
const DriverSchema: Schema = new Schema(
  {
    providerId: {
      type: Schema.Types.ObjectId,
      ref: 'Provider',
      required: [true, 'Provider ID is required'],
    },
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
    },
    firstName: {
      type: String,
      required: [true, 'First name is required'],
      trim: true,
    },
    lastName: {
      type: String,
      required: [true, 'Last name is required'],
      trim: true,
    },
    email: {
      type: String,
      required: [true, 'Email is required'],
      unique: true,
      trim: true,
      lowercase: true,
      match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, 'Please provide a valid email'],
    },
    phone: {
      type: String,
      required: [true, 'Phone number is required'],
      trim: true,
    },
    profilePicture: {
      type: String,
    },
    address: {
      street: {
        type: String,
        required: [true, 'Street address is required'],
        trim: true,
      },
      city: {
        type: String,
        required: [true, 'City is required'],
        trim: true,
      },
      state: {
        type: String,
        required: [true, 'State/Province is required'],
        trim: true,
      },
      postalCode: {
        type: String,
        required: [true, 'Postal code is required'],
        trim: true,
      },
      country: {
        type: String,
        required: [true, 'Country is required'],
        trim: true,
        default: 'Belgium',
      },
    },
    dateOfBirth: {
      type: Date,
      required: [true, 'Date of birth is required'],
      validate: {
        validator: function(value: Date) {
          // Driver must be at least 21 years old
          const today = new Date();
          const birthDate = new Date(value);
          let age = today.getFullYear() - birthDate.getFullYear();
          const monthDiff = today.getMonth() - birthDate.getMonth();
          if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
            age--;
          }
          return age >= 21;
        },
        message: 'Driver must be at least 21 years old',
      },
    },
    licenseNumber: {
      type: String,
      required: [true, 'License number is required'],
      trim: true,
    },
    licenseExpiryDate: {
      type: Date,
      required: [true, 'License expiry date is required'],
      validate: {
        validator: function(value: Date) {
          // License must not be expired
          return value > new Date();
        },
        message: 'License must not be expired',
      },
    },
    documents: [
      {
        type: {
          type: String,
          required: true,
          enum: ['driver_license', 'identity_card', 'medical_certificate', 'background_check', 'other'],
        },
        url: {
          type: String,
          required: true,
        },
        verificationStatus: {
          type: String,
          required: true,
          enum: ['unverified', 'pending', 'verified', 'rejected'],
          default: 'unverified',
        },
        expiryDate: {
          type: Date,
        },
      },
    ],
    status: {
      type: String,
      required: true,
      enum: ['active', 'inactive', 'suspended', 'pending'],
      default: 'pending',
    },
    verificationStatus: {
      type: String,
      required: true,
      enum: ['unverified', 'pending', 'verified', 'rejected'],
      default: 'unverified',
    },
    currentLocation: {
      latitude: {
        type: Number,
      },
      longitude: {
        type: Number,
      },
      updatedAt: {
        type: Date,
        default: Date.now,
      },
    },
    currentVehicleId: {
      type: Schema.Types.ObjectId,
      ref: 'Vehicle',
    },
    isAvailable: {
      type: Boolean,
      default: false,
    },
    ratingAverage: {
      type: Number,
      min: [1, 'Rating must be at least 1'],
      max: [5, 'Rating cannot exceed 5'],
      default: 0,
    },
    ratingCount: {
      type: Number,
      default: 0,
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// Virtual for driver's full name
DriverSchema.virtual('fullName').get(function (this: IDriver) {
  return `${this.firstName} ${this.lastName}`;
});

// Index for geospatial queries
DriverSchema.index({ 'currentLocation.coordinates': '2dsphere' });

// Create and export Driver model
const Driver = mongoose.model<IDriver>('Driver', DriverSchema);

export default Driver;
