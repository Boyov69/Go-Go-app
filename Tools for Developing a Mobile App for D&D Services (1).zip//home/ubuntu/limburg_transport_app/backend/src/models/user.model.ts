import mongoose, { Document, Schema } from 'mongoose';
import bcrypt from 'bcryptjs';

// Define interface for User document
export interface IUser extends Document {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  phone: string;
  profilePicture?: string;
  address?: {
    street: string;
    city: string;
    state: string;
    postalCode: string;
    country: string;
  };
  role: string;
  status: string;
  preferredPaymentMethod?: string;
  paymentMethods?: {
    type: string;
    cardNumber?: string;
    expiryDate?: string;
    cardholderName?: string;
    isDefault: boolean;
  }[];
  favoriteLocations?: {
    name: string;
    address: string;
    coordinates: {
      latitude: number;
      longitude: number;
    };
    type: string;
  }[];
  favoriteProviders?: mongoose.Types.ObjectId[];
  ratingAverage?: number;
  ratingCount?: number;
  comparePassword(candidatePassword: string): Promise<boolean>;
}

// Create User schema
const UserSchema: Schema = new Schema(
  {
    firstName: {
      type: String,
      required: [true, 'First name is required'],
      trim: true,
    },
    lastName: {
      type: String,
      required: [true, 'Last name is required'],
      trim: true,
    },
    email: {
      type: String,
      required: [true, 'Email is required'],
      unique: true,
      trim: true,
      lowercase: true,
      match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, 'Please provide a valid email'],
    },
    password: {
      type: String,
      required: [true, 'Password is required'],
      minlength: [8, 'Password must be at least 8 characters'],
      select: false,
    },
    phone: {
      type: String,
      required: [true, 'Phone number is required'],
      trim: true,
    },
    profilePicture: {
      type: String,
    },
    address: {
      street: {
        type: String,
        trim: true,
      },
      city: {
        type: String,
        trim: true,
      },
      state: {
        type: String,
        trim: true,
      },
      postalCode: {
        type: String,
        trim: true,
      },
      country: {
        type: String,
        trim: true,
        default: 'Belgium',
      },
    },
    role: {
      type: String,
      enum: ['user', 'admin'],
      default: 'user',
    },
    status: {
      type: String,
      enum: ['active', 'inactive', 'suspended'],
      default: 'active',
    },
    preferredPaymentMethod: {
      type: String,
      enum: ['credit_card', 'debit_card', 'paypal', 'apple_pay', 'google_pay', 'cash'],
    },
    paymentMethods: [
      {
        type: {
          type: String,
          required: true,
          enum: ['credit_card', 'debit_card', 'paypal', 'apple_pay', 'google_pay'],
        },
        cardNumber: {
          type: String,
          // Store only last 4 digits for security
          match: [/^\d{4}$/, 'Card number must be last 4 digits only'],
        },
        expiryDate: {
          type: String,
        },
        cardholderName: {
          type: String,
        },
        isDefault: {
          type: Boolean,
          default: false,
        },
      },
    ],
    favoriteLocations: [
      {
        name: {
          type: String,
          required: true,
        },
        address: {
          type: String,
          required: true,
        },
        coordinates: {
          latitude: {
            type: Number,
            required: true,
          },
          longitude: {
            type: Number,
            required: true,
          },
        },
        type: {
          type: String,
          enum: ['home', 'work', 'other'],
          default: 'other',
        },
      },
    ],
    favoriteProviders: [
      {
        type: Schema.Types.ObjectId,
        ref: 'Provider',
      },
    ],
    ratingAverage: {
      type: Number,
      min: [1, 'Rating must be at least 1'],
      max: [5, 'Rating cannot exceed 5'],
      default: 0,
    },
    ratingCount: {
      type: Number,
      default: 0,
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// Virtual for user's full name
UserSchema.virtual('fullName').get(function (this: IUser) {
  return `${this.firstName} ${this.lastName}`;
});

// Hash password before saving
UserSchema.pre<IUser>('save', async function (next) {
  // Only hash the password if it has been modified (or is new)
  if (!this.isModified('password')) return next();

  try {
    // Generate salt
    const salt = await bcrypt.genSalt(10);
    // Hash password
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error: any) {
    next(error);
  }
});

// Method to compare password
UserSchema.methods.comparePassword = async function (
  candidatePassword: string
): Promise<boolean> {
  return bcrypt.compare(candidatePassword, this.password);
};

// Create and export User model
const User = mongoose.model<IUser>('User', UserSchema);

export default User;
