import mongoose, { Document, Schema } from 'mongoose';
import bcrypt from 'bcryptjs';

// Define interface for Provider document
export interface IProvider extends Document {
  companyName: string;
  businessType: string;
  email: string;
  password: string;
  phone: string;
  address: {
    street: string;
    city: string;
    state: string;
    postalCode: string;
    country: string;
  };
  coordinates?: {
    latitude: number;
    longitude: number;
  };
  contactPerson: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
  };
  logo?: string;
  description?: string;
  website?: string;
  licenseNumber: string;
  taxIdentifier: string;
  serviceTypes: string[];
  serviceAreas?: {
    name: string;
    coordinates: {
      latitude: number;
      longitude: number;
    }[];
  }[];
  commissionRate: number;
  status: string;
  verificationStatus: string;
  documents?: {
    type: string;
    url: string;
    verificationStatus: string;
    expiryDate?: Date;
  }[];
  bankInformation?: {
    accountHolder: string;
    accountNumber: string;
    bankName: string;
    iban: string;
    swiftCode: string;
  };
  ratingAverage?: number;
  ratingCount?: number;
  comparePassword(candidatePassword: string): Promise<boolean>;
}

// Create Provider schema
const ProviderSchema: Schema = new Schema(
  {
    companyName: {
      type: String,
      required: [true, 'Company name is required'],
      trim: true,
    },
    businessType: {
      type: String,
      required: [true, 'Business type is required'],
      enum: ['taxi', 'bus', 'public_transport', 'healthcare', 'independent_driver'],
    },
    email: {
      type: String,
      required: [true, 'Email is required'],
      unique: true,
      trim: true,
      lowercase: true,
      match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, 'Please provide a valid email'],
    },
    password: {
      type: String,
      required: [true, 'Password is required'],
      minlength: [8, 'Password must be at least 8 characters'],
      select: false,
    },
    phone: {
      type: String,
      required: [true, 'Phone number is required'],
      trim: true,
    },
    address: {
      street: {
        type: String,
        required: [true, 'Street address is required'],
        trim: true,
      },
      city: {
        type: String,
        required: [true, 'City is required'],
        trim: true,
      },
      state: {
        type: String,
        required: [true, 'State/Province is required'],
        trim: true,
      },
      postalCode: {
        type: String,
        required: [true, 'Postal code is required'],
        trim: true,
      },
      country: {
        type: String,
        required: [true, 'Country is required'],
        trim: true,
        default: 'Belgium',
      },
    },
    coordinates: {
      latitude: {
        type: Number,
      },
      longitude: {
        type: Number,
      },
    },
    contactPerson: {
      firstName: {
        type: String,
        required: [true, 'Contact person first name is required'],
        trim: true,
      },
      lastName: {
        type: String,
        required: [true, 'Contact person last name is required'],
        trim: true,
      },
      email: {
        type: String,
        required: [true, 'Contact person email is required'],
        trim: true,
        lowercase: true,
        match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, 'Please provide a valid email'],
      },
      phone: {
        type: String,
        required: [true, 'Contact person phone is required'],
        trim: true,
      },
    },
    logo: {
      type: String,
    },
    description: {
      type: String,
      trim: true,
    },
    website: {
      type: String,
      trim: true,
    },
    licenseNumber: {
      type: String,
      required: [true, 'License number is required'],
      trim: true,
    },
    taxIdentifier: {
      type: String,
      required: [true, 'Tax identifier is required'],
      trim: true,
    },
    serviceTypes: {
      type: [String],
      required: [true, 'At least one service type is required'],
      enum: ['standard', 'economy', 'premium', 'accessible', 'electric', 'healthcare', 'bus', 'shuttle'],
    },
    serviceAreas: [
      {
        name: {
          type: String,
          required: true,
        },
        coordinates: [
          {
            latitude: {
              type: Number,
              required: true,
            },
            longitude: {
              type: Number,
              required: true,
            },
          },
        ],
      },
    ],
    commissionRate: {
      type: Number,
      required: [true, 'Commission rate is required'],
      min: [0, 'Commission rate cannot be negative'],
      max: [100, 'Commission rate cannot exceed 100%'],
      default: 15,
    },
    status: {
      type: String,
      required: true,
      enum: ['active', 'inactive', 'suspended', 'pending'],
      default: 'pending',
    },
    verificationStatus: {
      type: String,
      required: true,
      enum: ['unverified', 'pending', 'verified', 'rejected'],
      default: 'unverified',
    },
    documents: [
      {
        type: {
          type: String,
          required: true,
          enum: ['business_license', 'insurance', 'tax_certificate', 'identity_proof', 'other'],
        },
        url: {
          type: String,
          required: true,
        },
        verificationStatus: {
          type: String,
          required: true,
          enum: ['unverified', 'pending', 'verified', 'rejected'],
          default: 'unverified',
        },
        expiryDate: {
          type: Date,
        },
      },
    ],
    bankInformation: {
      accountHolder: {
        type: String,
      },
      accountNumber: {
        type: String,
      },
      bankName: {
        type: String,
      },
      iban: {
        type: String,
      },
      swiftCode: {
        type: String,
      },
    },
    ratingAverage: {
      type: Number,
      min: [1, 'Rating must be at least 1'],
      max: [5, 'Rating cannot exceed 5'],
      default: 0,
    },
    ratingCount: {
      type: Number,
      default: 0,
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// Virtual for provider's full name
ProviderSchema.virtual('contactPersonFullName').get(function (this: IProvider) {
  return `${this.contactPerson.firstName} ${this.contactPerson.lastName}`;
});

// Index for geospatial queries
ProviderSchema.index({ coordinates: '2dsphere' });

// Hash password before saving
ProviderSchema.pre<IProvider>('save', async function (next) {
  // Only hash the password if it has been modified (or is new)
  if (!this.isModified('password')) return next();

  try {
    // Generate salt
    const salt = await bcrypt.genSalt(10);
    // Hash password
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error: any) {
    next(error);
  }
});

// Method to compare password
ProviderSchema.methods.comparePassword = async function (
  candidatePassword: string
): Promise<boolean> {
  return bcrypt.compare(candidatePassword, this.password);
};

// Create and export Provider model
const Provider = mongoose.model<IProvider>('Provider', ProviderSchema);

export default Provider;
