import mongoose, { Document, Schema } from 'mongoose';

// Define interface for Ride document
export interface IRide extends Document {
  userId: mongoose.Types.ObjectId;
  providerId: mongoose.Types.ObjectId;
  driverId?: mongoose.Types.ObjectId;
  vehicleId?: mongoose.Types.ObjectId;
  status: string;
  rideType: string;
  serviceType: string;
  pickup: {
    address: string;
    coordinates: {
      latitude: number;
      longitude: number;
    };
    notes?: string;
  };
  destination: {
    address: string;
    coordinates: {
      latitude: number;
      longitude: number;
    };
    notes?: string;
  };
  intermediateStops?: {
    address: string;
    coordinates: {
      latitude: number;
      longitude: number;
    };
    notes?: string;
  }[];
  scheduledTime?: Date;
  requestTime: Date;
  acceptTime?: Date;
  pickupTime?: Date;
  dropoffTime?: Date;
  cancelTime?: Date;
  cancelReason?: string;
  cancelledBy?: string;
  estimatedDistance?: number;
  estimatedDuration?: number;
  actualDistance?: number;
  actualDuration?: number;
  estimatedPrice?: number;
  finalPrice?: number;
  currency: string;
  paymentMethod: string;
  paymentStatus: string;
  paymentId?: string;
  specialRequirements?: string[];
  passengerCount: number;
  rating?: {
    driver?: {
      score: number;
      comment?: string;
      createdAt: Date;
    };
    user?: {
      score: number;
      comment?: string;
      createdAt: Date;
    };
  };
  route?: {
    type: string;
    coordinates: number[][];
  };
  currentLocation?: {
    latitude: number;
    longitude: number;
    updatedAt: Date;
  };
}

// Create Ride schema
const RideSchema: Schema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'User ID is required'],
    },
    providerId: {
      type: Schema.Types.ObjectId,
      ref: 'Provider',
      required: [true, 'Provider ID is required'],
    },
    driverId: {
      type: Schema.Types.ObjectId,
      ref: 'Driver',
    },
    vehicleId: {
      type: Schema.Types.ObjectId,
      ref: 'Vehicle',
    },
    status: {
      type: String,
      required: true,
      enum: [
        'requested',
        'searching',
        'accepted',
        'arrived',
        'in_progress',
        'completed',
        'cancelled',
        'scheduled',
      ],
      default: 'requested',
    },
    rideType: {
      type: String,
      required: true,
      enum: ['immediate', 'scheduled'],
      default: 'immediate',
    },
    serviceType: {
      type: String,
      required: true,
      enum: ['standard', 'economy', 'premium', 'accessible', 'electric', 'healthcare', 'bus', 'shuttle'],
    },
    pickup: {
      address: {
        type: String,
        required: [true, 'Pickup address is required'],
      },
      coordinates: {
        latitude: {
          type: Number,
          required: [true, 'Pickup latitude is required'],
        },
        longitude: {
          type: Number,
          required: [true, 'Pickup longitude is required'],
        },
      },
      notes: {
        type: String,
      },
    },
    destination: {
      address: {
        type: String,
        required: [true, 'Destination address is required'],
      },
      coordinates: {
        latitude: {
          type: Number,
          required: [true, 'Destination latitude is required'],
        },
        longitude: {
          type: Number,
          required: [true, 'Destination longitude is required'],
        },
      },
      notes: {
        type: String,
      },
    },
    intermediateStops: [
      {
        address: {
          type: String,
          required: true,
        },
        coordinates: {
          latitude: {
            type: Number,
            required: true,
          },
          longitude: {
            type: Number,
            required: true,
          },
        },
        notes: {
          type: String,
        },
      },
    ],
    scheduledTime: {
      type: Date,
    },
    requestTime: {
      type: Date,
      required: true,
      default: Date.now,
    },
    acceptTime: {
      type: Date,
    },
    pickupTime: {
      type: Date,
    },
    dropoffTime: {
      type: Date,
    },
    cancelTime: {
      type: Date,
    },
    cancelReason: {
      type: String,
    },
    cancelledBy: {
      type: String,
      enum: ['user', 'driver', 'provider', 'system'],
    },
    estimatedDistance: {
      type: Number, // in kilometers
    },
    estimatedDuration: {
      type: Number, // in minutes
    },
    actualDistance: {
      type: Number, // in kilometers
    },
    actualDuration: {
      type: Number, // in minutes
    },
    estimatedPrice: {
      type: Number,
    },
    finalPrice: {
      type: Number,
    },
    currency: {
      type: String,
      default: 'EUR',
    },
    paymentMethod: {
      type: String,
      required: true,
      enum: ['credit_card', 'debit_card', 'paypal', 'apple_pay', 'google_pay', 'cash'],
    },
    paymentStatus: {
      type: String,
      required: true,
      enum: ['pending', 'processing', 'completed', 'failed', 'refunded'],
      default: 'pending',
    },
    paymentId: {
      type: String,
    },
    specialRequirements: {
      type: [String],
      enum: [
        'wheelchair_accessible',
        'child_seat',
        'pet_friendly',
        'extra_luggage',
        'assistance_required',
        'medical_equipment',
      ],
    },
    passengerCount: {
      type: Number,
      required: true,
      min: [1, 'Passenger count must be at least 1'],
      default: 1,
    },
    rating: {
      driver: {
        score: {
          type: Number,
          min: 1,
          max: 5,
        },
        comment: {
          type: String,
        },
        createdAt: {
          type: Date,
        },
      },
      user: {
        score: {
          type: Number,
          min: 1,
          max: 5,
        },
        comment: {
          type: String,
        },
        createdAt: {
          type: Date,
        },
      },
    },
    route: {
      type: {
        type: String,
        enum: ['LineString'],
        default: 'LineString',
      },
      coordinates: {
        type: [[Number]],
        validate: {
          validator: function(v: number[][]) {
            return v.length >= 2 && v.every(coord => coord.length === 2);
          },
          message: 'Route must have at least 2 coordinates, each with longitude and latitude',
        },
      },
    },
    currentLocation: {
      latitude: {
        type: Number,
      },
      longitude: {
        type: Number,
      },
      updatedAt: {
        type: Date,
        default: Date.now,
      },
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// Index for geospatial queries
RideSchema.index({ 'pickup.coordinates': '2dsphere' });
RideSchema.index({ 'destination.coordinates': '2dsphere' });
RideSchema.index({ 'currentLocation': '2dsphere' });

// Create and export Ride model
const Ride = mongoose.model<IRide>('Ride', RideSchema);

export default Ride;
