import mongoose, { Document, Schema } from 'mongoose';

// Define interface for Vehicle document
export interface IVehicle extends Document {
  providerId: mongoose.Types.ObjectId;
  make: string;
  model: string;
  year: number;
  color: string;
  licensePlate: string;
  registrationNumber: string;
  vehicleType: string;
  capacity: number;
  features?: string[];
  photos?: string[];
  documents?: {
    type: string;
    url: string;
    verificationStatus: string;
    expiryDate?: Date;
  }[];
  status: string;
  verificationStatus: string;
  isAccessible: boolean;
  isElectric: boolean;
  currentDriverId?: mongoose.Types.ObjectId;
}

// Create Vehicle schema
const VehicleSchema: Schema = new Schema(
  {
    providerId: {
      type: Schema.Types.ObjectId,
      ref: 'Provider',
      required: [true, 'Provider ID is required'],
    },
    make: {
      type: String,
      required: [true, 'Vehicle make is required'],
      trim: true,
    },
    model: {
      type: String,
      required: [true, 'Vehicle model is required'],
      trim: true,
    },
    year: {
      type: Number,
      required: [true, 'Vehicle year is required'],
      min: [1990, 'Vehicle must be from 1990 or newer'],
      max: [new Date().getFullYear() + 1, 'Vehicle year cannot be in the future'],
    },
    color: {
      type: String,
      required: [true, 'Vehicle color is required'],
      trim: true,
    },
    licensePlate: {
      type: String,
      required: [true, 'License plate is required'],
      trim: true,
      unique: true,
    },
    registrationNumber: {
      type: String,
      required: [true, 'Registration number is required'],
      trim: true,
    },
    vehicleType: {
      type: String,
      required: [true, 'Vehicle type is required'],
      enum: ['sedan', 'suv', 'van', 'minibus', 'bus', 'ambulance', 'specialized'],
    },
    capacity: {
      type: Number,
      required: [true, 'Passenger capacity is required'],
      min: [1, 'Capacity must be at least 1'],
    },
    features: {
      type: [String],
      enum: [
        'air_conditioning',
        'wifi',
        'child_seat',
        'wheelchair_accessible',
        'pet_friendly',
        'luggage_space',
        'entertainment_system',
      ],
    },
    photos: [
      {
        type: String,
      },
    ],
    documents: [
      {
        type: {
          type: String,
          required: true,
          enum: ['registration', 'insurance', 'inspection', 'permit', 'other'],
        },
        url: {
          type: String,
          required: true,
        },
        verificationStatus: {
          type: String,
          required: true,
          enum: ['unverified', 'pending', 'verified', 'rejected'],
          default: 'unverified',
        },
        expiryDate: {
          type: Date,
        },
      },
    ],
    status: {
      type: String,
      required: true,
      enum: ['active', 'inactive', 'maintenance', 'pending'],
      default: 'pending',
    },
    verificationStatus: {
      type: String,
      required: true,
      enum: ['unverified', 'pending', 'verified', 'rejected'],
      default: 'unverified',
    },
    isAccessible: {
      type: Boolean,
      default: false,
    },
    isElectric: {
      type: Boolean,
      default: false,
    },
    currentDriverId: {
      type: Schema.Types.ObjectId,
      ref: 'Driver',
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// Virtual for vehicle's full name
VehicleSchema.virtual('fullName').get(function (this: IVehicle) {
  return `${this.year} ${this.make} ${this.model}`;
});

// Create and export Vehicle model
const Vehicle = mongoose.model<IVehicle>('Vehicle', VehicleSchema);

export default Vehicle;
