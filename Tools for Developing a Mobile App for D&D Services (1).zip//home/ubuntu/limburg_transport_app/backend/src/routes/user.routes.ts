import express from 'express';
import {
  registerUser,
  loginUser,
  getCurrentUser,
  updateUserProfile,
  changePassword,
  addPaymentMethod,
  removePaymentMethod,
  setDefaultPaymentMethod,
  addFavoriteLocation,
  removeFavoriteLocation,
  addFavoriteProvider,
  removeFavoriteProvider
} from '../controllers/user.controller';
import { protect } from '../middleware/auth.middleware';

const router = express.Router();

// Public routes
router.post('/register', registerUser);
router.post('/login', loginUser);

// Protected routes
router.use(protect);

// User profile routes
router.get('/me', getCurrentUser);
router.put('/me', updateUserProfile);
router.put('/change-password', changePassword);

// Payment method routes
router.post('/payment-methods', addPaymentMethod);
router.delete('/payment-methods/:paymentMethodId', removePaymentMethod);
router.put('/payment-methods/:paymentMethodId/default', setDefaultPaymentMethod);

// Favorite location routes
router.post('/favorite-locations', addFavoriteLocation);
router.delete('/favorite-locations/:locationId', removeFavoriteLocation);

// Favorite provider routes
router.post('/favorite-providers', addFavoriteProvider);
router.delete('/favorite-providers/:providerId', removeFavoriteProvider);

export default router;
