import express from 'express';
import {
  processPayment,
  getPaymentById,
  getUserPayments,
  requestRefund,
  generateReceipt
} from '../controllers/payment.controller';
import { protect } from '../middleware/auth.middleware';

const router = express.Router();

// All payment routes are protected
router.use(protect);

// Payment routes
router.post('/rides/:rideId', processPayment);
router.get('/me', getUserPayments);
router.get('/:id', getPaymentById);
router.post('/:paymentId/refund', requestRefund);
router.get('/:paymentId/receipt', generateReceipt);

export default router;
