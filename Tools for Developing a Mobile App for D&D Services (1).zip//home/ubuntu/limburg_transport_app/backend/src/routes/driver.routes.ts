import express from 'express';
import {
  getProviderDrivers,
  getDriverById,
  createDriver,
  updateDriver,
  deleteDriver,
  updateDriverVerificationStatus,
  addDriverDocument,
  updateDriverDocumentStatus,
  updateDriverAvailability,
  updateDriverLocation,
  getAvailableDriversNearLocation
} from '../controllers/driver.controller';

const router = express.Router();

// Driver routes for a specific provider
router.route('/provider/:providerId')
  .get(getProviderDrivers)
  .post(createDriver);

// Driver routes by ID
router.route('/:id')
  .get(getDriverById)
  .put(updateDriver)
  .delete(deleteDriver);

// Driver verification routes
router.route('/:id/verification')
  .put(updateDriverVerificationStatus);

// Driver document routes
router.route('/:id/documents')
  .post(addDriverDocument);

router.route('/:id/documents/verification')
  .put(updateDriverDocumentStatus);

// Driver availability routes
router.route('/:id/availability')
  .put(updateDriverAvailability);

// Driver location routes
router.route('/:id/location')
  .put(updateDriverLocation);

// Get available drivers near location
router.route('/available/nearby')
  .get(getAvailableDriversNearLocation);

export default router;
