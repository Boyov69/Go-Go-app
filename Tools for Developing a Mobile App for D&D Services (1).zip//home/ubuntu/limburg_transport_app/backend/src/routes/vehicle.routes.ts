import express from 'express';
import {
  getProviderVehicles,
  getVehicleById,
  createVehicle,
  updateVehicle,
  deleteVehicle,
  updateVehicleVerificationStatus,
  addVehicleDocument,
  updateVehicleDocumentStatus,
  getVehiclesByType,
  assignDriverToVehicle
} from '../controllers/vehicle.controller';

const router = express.Router();

// Vehicle routes for a specific provider
router.route('/provider/:providerId')
  .get(getProviderVehicles)
  .post(createVehicle);

// Vehicle routes by ID
router.route('/:id')
  .get(getVehicleById)
  .put(updateVehicle)
  .delete(deleteVehicle);

// Vehicle verification routes
router.route('/:id/verification')
  .put(updateVehicleVerificationStatus);

// Vehicle document routes
router.route('/:id/documents')
  .post(addVehicleDocument);

router.route('/:id/documents/verification')
  .put(updateVehicleDocumentStatus);

// Get vehicles by type
router.route('/type/:vehicleType')
  .get(getVehiclesByType);

// Assign driver to vehicle
router.route('/:vehicleId/driver/:driverId')
  .put(assignDriverToVehicle);

export default router;
