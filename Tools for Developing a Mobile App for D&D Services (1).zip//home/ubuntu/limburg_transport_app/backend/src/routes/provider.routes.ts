import express from 'express';
import {
  getAllProviders,
  getProviderById,
  createProvider,
  updateProvider,
  deleteProvider,
  updateProviderVerificationStatus,
  addProviderDocument,
  updateProviderDocumentStatus,
  getProvidersByServiceType,
  getProvidersByLocation
} from '../controllers/provider.controller';

const router = express.Router();

// Provider routes
router.route('/')
  .get(getAllProviders)
  .post(createProvider);

router.route('/:id')
  .get(getProviderById)
  .put(updateProvider)
  .delete(deleteProvider);

router.route('/:id/verification')
  .put(updateProviderVerificationStatus);

router.route('/:id/documents')
  .post(addProviderDocument);

router.route('/:id/documents/verification')
  .put(updateProviderDocumentStatus);

router.route('/service-type/:serviceType')
  .get(getProvidersByServiceType);

router.route('/location/nearby')
  .get(getProvidersByLocation);

export default router;
