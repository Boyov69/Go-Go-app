import express from 'express';
import {
  requestRide,
  getRideById,
  getUserRides,
  cancelRide,
  rateRide
} from '../controllers/ride.controller';
import { protect } from '../middleware/auth.middleware';

const router = express.Router();

// All ride routes are protected
router.use(protect);

// Ride routes
router.post('/', requestRide);
router.get('/me', getUserRides);
router.get('/:id', getRideById);
router.put('/:id/cancel', cancelRide);
router.post('/:id/rate', rateRide);

export default router;
