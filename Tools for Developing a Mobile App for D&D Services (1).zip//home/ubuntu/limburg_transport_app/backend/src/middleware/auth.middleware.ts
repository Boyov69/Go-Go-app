import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import config from '../config/config';
import Provider from '../models/provider.model';
import logger from '../utils/logger';

// Interface for JWT payload
interface JwtPayload {
  id: string;
  role: string;
}

// Middleware to protect routes
export const protect = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    let token;

    // Check if token exists in headers
    if (
      req.headers.authorization &&
      req.headers.authorization.startsWith('Bearer')
    ) {
      // Get token from header
      token = req.headers.authorization.split(' ')[1];
    }

    // Check if token exists
    if (!token) {
      return res.status(401).json({
        success: false,
        error: 'Not authorized to access this route'
      });
    }

    try {
      // Verify token
      const decoded = jwt.verify(token, config.jwtSecret) as JwtPayload;

      // Add user to request object
      if (decoded.role === 'provider') {
        const provider = await Provider.findById(decoded.id);
        if (!provider) {
          return res.status(401).json({
            success: false,
            error: 'Provider not found'
          });
        }
        
        // Add provider to request
        (req as any).provider = provider;
      }

      next();
    } catch (error) {
      logger.error('Invalid token', { error });
      return res.status(401).json({
        success: false,
        error: 'Not authorized to access this route'
      });
    }
  } catch (error) {
    logger.error('Error in auth middleware', { error });
    next(error);
  }
};

// Middleware to restrict access to specific roles
export const authorize = (...roles: string[]) => {
  return (req: Request, res: Response, next: NextFunction) => {
    // Get provider from request
    const provider = (req as any).provider;
    
    // Check if provider exists and has required role
    if (!provider || !roles.includes(provider.businessType)) {
      return res.status(403).json({
        success: false,
        error: `Provider role ${provider.businessType} is not authorized to access this route`
      });
    }
    
    next();
  };
};

// Middleware to check if provider is verified
export const isVerified = (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  // Get provider from request
  const provider = (req as any).provider;
  
  // Check if provider is verified
  if (provider.verificationStatus !== 'verified') {
    return res.status(403).json({
      success: false,
      error: 'Provider is not verified'
    });
  }
  
  next();
};

// Middleware to check if provider is active
export const isActive = (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  // Get provider from request
  const provider = (req as any).provider;
  
  // Check if provider is active
  if (provider.status !== 'active') {
    return res.status(403).json({
      success: false,
      error: 'Provider is not active'
    });
  }
  
  next();
};

// Middleware to check if provider owns the resource
export const isResourceOwner = (resourceType: string) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      // Get provider from request
      const provider = (req as any).provider;
      
      // Get resource ID from request
      const resourceId = req.params.id;
      
      // Get resource model based on type
      let Resource;
      switch (resourceType) {
        case 'vehicle':
          Resource = require('../models/vehicle.model').default;
          break;
        case 'driver':
          Resource = require('../models/driver.model').default;
          break;
        default:
          return res.status(400).json({
            success: false,
            error: 'Invalid resource type'
          });
      }
      
      // Find resource
      const resource = await Resource.findById(resourceId);
      
      // Check if resource exists
      if (!resource) {
        return res.status(404).json({
          success: false,
          error: `${resourceType.charAt(0).toUpperCase() + resourceType.slice(1)} not found`
        });
      }
      
      // Check if provider owns the resource
      if (resource.providerId.toString() !== provider._id.toString()) {
        return res.status(403).json({
          success: false,
          error: `Not authorized to access this ${resourceType}`
        });
      }
      
      next();
    } catch (error) {
      logger.error(`Error in isResourceOwner middleware for ${resourceType}`, { error });
      next(error);
    }
  };
};
