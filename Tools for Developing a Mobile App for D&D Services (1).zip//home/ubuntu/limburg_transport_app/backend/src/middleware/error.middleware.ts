import { Request, Response, NextFunction } from 'express';
import logger from '../utils/logger';

// Error handler middleware
export const errorHandler = (
  err: Error,
  req: Request,
  res: Response,
  next: NextFunction
) => {
  // Log error
  logger.error(err.message, { error: err, stack: err.stack });

  // Default error status and message
  let statusCode = 500;
  let message = 'Server Error';

  // Check if error has status code and message
  if ('statusCode' in err && typeof (err as any).statusCode === 'number') {
    statusCode = (err as any).statusCode;
  }

  if ('message' in err && typeof err.message === 'string') {
    message = err.message;
  }

  // Send error response
  res.status(statusCode).json({
    success: false,
    error: message,
    stack: process.env.NODE_ENV === 'production' ? undefined : err.stack
  });
};

// Not found middleware
export const notFound = (req: Request, res: Response, next: NextFunction) => {
  const error = new Error(`Not Found - ${req.originalUrl}`);
  (error as any).statusCode = 404;
  next(error);
};

// Request logger middleware
export const requestLogger = (req: Request, res: Response, next: NextFunction) => {
  logger.info(`${req.method} ${req.originalUrl}`, {
    ip: req.ip,
    userAgent: req.headers['user-agent']
  });
  next();
};

// CORS error handler middleware
export const corsErrorHandler = (
  err: Error,
  req: Request,
  res: Response,
  next: NextFunction
) => {
  if (err.name === 'CorsError') {
    return res.status(403).json({
      success: false,
      error: 'CORS error: Request origin not allowed'
    });
  }
  next(err);
};

// File upload size limit middleware
export const fileSizeLimiter = (
  err: Error,
  req: Request,
  res: Response,
  next: NextFunction
) => {
  if (err.name === 'MulterError' && err.message === 'File too large') {
    return res.status(413).json({
      success: false,
      error: 'File size exceeds the limit'
    });
  }
  next(err);
};
