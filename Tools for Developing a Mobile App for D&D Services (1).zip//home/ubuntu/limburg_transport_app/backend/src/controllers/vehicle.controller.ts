import { Request, Response, NextFunction } from 'express';
import Vehicle, { IVehicle } from '../models/vehicle.model';
import Provider from '../models/provider.model';
import logger from '../utils/logger';
import mongoose from 'mongoose';

// Get all vehicles for a provider
export const getProviderVehicles = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { providerId } = req.params;
    
    // Verify provider exists
    const provider = await Provider.findById(providerId);
    if (!provider) {
      return res.status(404).json({
        success: false,
        error: 'Provider not found'
      });
    }
    
    const vehicles = await Vehicle.find({ providerId });
    
    res.status(200).json({
      success: true,
      count: vehicles.length,
      data: vehicles
    });
  } catch (error) {
    logger.error(`Error fetching vehicles for provider ${req.params.providerId}`, { error });
    next(error);
  }
};

// Get single vehicle by ID
export const getVehicleById = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const vehicle = await Vehicle.findById(req.params.id);
    
    if (!vehicle) {
      return res.status(404).json({
        success: false,
        error: 'Vehicle not found'
      });
    }
    
    res.status(200).json({
      success: true,
      data: vehicle
    });
  } catch (error) {
    logger.error(`Error fetching vehicle with id ${req.params.id}`, { error });
    next(error);
  }
};

// Create new vehicle for a provider
export const createVehicle = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { providerId } = req.params;
    
    // Verify provider exists
    const provider = await Provider.findById(providerId);
    if (!provider) {
      return res.status(404).json({
        success: false,
        error: 'Provider not found'
      });
    }
    
    // Check if vehicle with license plate already exists
    const existingVehicle = await Vehicle.findOne({ licensePlate: req.body.licensePlate });
    if (existingVehicle) {
      return res.status(400).json({
        success: false,
        error: 'Vehicle with this license plate already exists'
      });
    }
    
    // Create vehicle with provider ID
    const vehicleData = {
      ...req.body,
      providerId
    };
    
    const vehicle = await Vehicle.create(vehicleData);
    
    res.status(201).json({
      success: true,
      data: vehicle
    });
  } catch (error) {
    logger.error(`Error creating vehicle for provider ${req.params.providerId}`, { error });
    
    if (error instanceof mongoose.Error.ValidationError) {
      const messages = Object.values(error.errors).map(val => val.message);
      return res.status(400).json({
        success: false,
        error: messages
      });
    }
    
    next(error);
  }
};

// Update vehicle
export const updateVehicle = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    // Find vehicle and update
    const vehicle = await Vehicle.findByIdAndUpdate(
      req.params.id,
      req.body,
      {
        new: true,
        runValidators: true
      }
    );
    
    if (!vehicle) {
      return res.status(404).json({
        success: false,
        error: 'Vehicle not found'
      });
    }
    
    res.status(200).json({
      success: true,
      data: vehicle
    });
  } catch (error) {
    logger.error(`Error updating vehicle with id ${req.params.id}`, { error });
    
    if (error instanceof mongoose.Error.ValidationError) {
      const messages = Object.values(error.errors).map(val => val.message);
      return res.status(400).json({
        success: false,
        error: messages
      });
    }
    
    next(error);
  }
};

// Delete vehicle
export const deleteVehicle = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const vehicle = await Vehicle.findById(req.params.id);
    
    if (!vehicle) {
      return res.status(404).json({
        success: false,
        error: 'Vehicle not found'
      });
    }
    
    await vehicle.deleteOne();
    
    res.status(200).json({
      success: true,
      data: {}
    });
  } catch (error) {
    logger.error(`Error deleting vehicle with id ${req.params.id}`, { error });
    next(error);
  }
};

// Update vehicle verification status
export const updateVehicleVerificationStatus = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { verificationStatus } = req.body;
    
    if (!['unverified', 'pending', 'verified', 'rejected'].includes(verificationStatus)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid verification status'
      });
    }
    
    const vehicle = await Vehicle.findByIdAndUpdate(
      req.params.id,
      { verificationStatus },
      {
        new: true,
        runValidators: true
      }
    );
    
    if (!vehicle) {
      return res.status(404).json({
        success: false,
        error: 'Vehicle not found'
      });
    }
    
    res.status(200).json({
      success: true,
      data: vehicle
    });
  } catch (error) {
    logger.error(`Error updating vehicle verification status with id ${req.params.id}`, { error });
    next(error);
  }
};

// Add vehicle document
export const addVehicleDocument = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { type, url, expiryDate } = req.body;
    
    if (!type || !url) {
      return res.status(400).json({
        success: false,
        error: 'Document type and URL are required'
      });
    }
    
    const vehicle = await Vehicle.findById(req.params.id);
    
    if (!vehicle) {
      return res.status(404).json({
        success: false,
        error: 'Vehicle not found'
      });
    }
    
    const newDocument = {
      type,
      url,
      verificationStatus: 'pending',
      expiryDate: expiryDate ? new Date(expiryDate) : undefined
    };
    
    if (!vehicle.documents) {
      vehicle.documents = [];
    }
    
    vehicle.documents.push(newDocument);
    await vehicle.save();
    
    res.status(200).json({
      success: true,
      data: vehicle
    });
  } catch (error) {
    logger.error(`Error adding document to vehicle with id ${req.params.id}`, { error });
    next(error);
  }
};

// Update vehicle document verification status
export const updateVehicleDocumentStatus = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { documentId, verificationStatus } = req.body;
    
    if (!documentId || !verificationStatus) {
      return res.status(400).json({
        success: false,
        error: 'Document ID and verification status are required'
      });
    }
    
    if (!['unverified', 'pending', 'verified', 'rejected'].includes(verificationStatus)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid verification status'
      });
    }
    
    const vehicle = await Vehicle.findById(req.params.id);
    
    if (!vehicle) {
      return res.status(404).json({
        success: false,
        error: 'Vehicle not found'
      });
    }
    
    if (!vehicle.documents) {
      return res.status(404).json({
        success: false,
        error: 'No documents found for this vehicle'
      });
    }
    
    const documentIndex = vehicle.documents.findIndex(
      doc => doc._id.toString() === documentId
    );
    
    if (documentIndex === -1) {
      return res.status(404).json({
        success: false,
        error: 'Document not found'
      });
    }
    
    vehicle.documents[documentIndex].verificationStatus = verificationStatus;
    await vehicle.save();
    
    res.status(200).json({
      success: true,
      data: vehicle
    });
  } catch (error) {
    logger.error(`Error updating document status for vehicle with id ${req.params.id}`, { error });
    next(error);
  }
};

// Get vehicles by type
export const getVehiclesByType = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { vehicleType } = req.params;
    const { providerId } = req.query;
    
    const query: any = { vehicleType };
    
    // If providerId is provided, filter by provider
    if (providerId) {
      query.providerId = providerId;
    }
    
    const vehicles = await Vehicle.find(query);
    
    res.status(200).json({
      success: true,
      count: vehicles.length,
      data: vehicles
    });
  } catch (error) {
    logger.error(`Error fetching vehicles by type ${req.params.vehicleType}`, { error });
    next(error);
  }
};

// Assign driver to vehicle
export const assignDriverToVehicle = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { vehicleId, driverId } = req.params;
    
    // Update vehicle with driver ID
    const vehicle = await Vehicle.findByIdAndUpdate(
      vehicleId,
      { currentDriverId: driverId },
      {
        new: true,
        runValidators: true
      }
    );
    
    if (!vehicle) {
      return res.status(404).json({
        success: false,
        error: 'Vehicle not found'
      });
    }
    
    // Also update driver with vehicle ID
    const Driver = mongoose.model('Driver');
    await Driver.findByIdAndUpdate(
      driverId,
      { currentVehicleId: vehicleId }
    );
    
    res.status(200).json({
      success: true,
      data: vehicle
    });
  } catch (error) {
    logger.error(`Error assigning driver ${req.params.driverId} to vehicle ${req.params.vehicleId}`, { error });
    next(error);
  }
};
