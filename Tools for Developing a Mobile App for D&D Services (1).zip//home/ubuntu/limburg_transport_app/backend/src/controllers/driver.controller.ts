import { Request, Response, NextFunction } from 'express';
import Driver, { IDriver } from '../models/driver.model';
import Provider from '../models/provider.model';
import Vehicle from '../models/vehicle.model';
import logger from '../utils/logger';
import mongoose from 'mongoose';

// Get all drivers for a provider
export const getProviderDrivers = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { providerId } = req.params;
    
    // Verify provider exists
    const provider = await Provider.findById(providerId);
    if (!provider) {
      return res.status(404).json({
        success: false,
        error: 'Provider not found'
      });
    }
    
    const drivers = await Driver.find({ providerId });
    
    res.status(200).json({
      success: true,
      count: drivers.length,
      data: drivers
    });
  } catch (error) {
    logger.error(`Error fetching drivers for provider ${req.params.providerId}`, { error });
    next(error);
  }
};

// Get single driver by ID
export const getDriverById = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const driver = await Driver.findById(req.params.id);
    
    if (!driver) {
      return res.status(404).json({
        success: false,
        error: 'Driver not found'
      });
    }
    
    res.status(200).json({
      success: true,
      data: driver
    });
  } catch (error) {
    logger.error(`Error fetching driver with id ${req.params.id}`, { error });
    next(error);
  }
};

// Create new driver for a provider
export const createDriver = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { providerId } = req.params;
    
    // Verify provider exists
    const provider = await Provider.findById(providerId);
    if (!provider) {
      return res.status(404).json({
        success: false,
        error: 'Provider not found'
      });
    }
    
    // Check if driver with email already exists
    const existingDriver = await Driver.findOne({ email: req.body.email });
    if (existingDriver) {
      return res.status(400).json({
        success: false,
        error: 'Driver with this email already exists'
      });
    }
    
    // Create driver with provider ID
    const driverData = {
      ...req.body,
      providerId
    };
    
    const driver = await Driver.create(driverData);
    
    res.status(201).json({
      success: true,
      data: driver
    });
  } catch (error) {
    logger.error(`Error creating driver for provider ${req.params.providerId}`, { error });
    
    if (error instanceof mongoose.Error.ValidationError) {
      const messages = Object.values(error.errors).map(val => val.message);
      return res.status(400).json({
        success: false,
        error: messages
      });
    }
    
    next(error);
  }
};

// Update driver
export const updateDriver = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    // Find driver and update
    const driver = await Driver.findByIdAndUpdate(
      req.params.id,
      req.body,
      {
        new: true,
        runValidators: true
      }
    );
    
    if (!driver) {
      return res.status(404).json({
        success: false,
        error: 'Driver not found'
      });
    }
    
    res.status(200).json({
      success: true,
      data: driver
    });
  } catch (error) {
    logger.error(`Error updating driver with id ${req.params.id}`, { error });
    
    if (error instanceof mongoose.Error.ValidationError) {
      const messages = Object.values(error.errors).map(val => val.message);
      return res.status(400).json({
        success: false,
        error: messages
      });
    }
    
    next(error);
  }
};

// Delete driver
export const deleteDriver = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const driver = await Driver.findById(req.params.id);
    
    if (!driver) {
      return res.status(404).json({
        success: false,
        error: 'Driver not found'
      });
    }
    
    // If driver is assigned to a vehicle, remove the assignment
    if (driver.currentVehicleId) {
      await Vehicle.findByIdAndUpdate(
        driver.currentVehicleId,
        { $unset: { currentDriverId: 1 } }
      );
    }
    
    await driver.deleteOne();
    
    res.status(200).json({
      success: true,
      data: {}
    });
  } catch (error) {
    logger.error(`Error deleting driver with id ${req.params.id}`, { error });
    next(error);
  }
};

// Update driver verification status
export const updateDriverVerificationStatus = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { verificationStatus } = req.body;
    
    if (!['unverified', 'pending', 'verified', 'rejected'].includes(verificationStatus)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid verification status'
      });
    }
    
    const driver = await Driver.findByIdAndUpdate(
      req.params.id,
      { verificationStatus },
      {
        new: true,
        runValidators: true
      }
    );
    
    if (!driver) {
      return res.status(404).json({
        success: false,
        error: 'Driver not found'
      });
    }
    
    res.status(200).json({
      success: true,
      data: driver
    });
  } catch (error) {
    logger.error(`Error updating driver verification status with id ${req.params.id}`, { error });
    next(error);
  }
};

// Add driver document
export const addDriverDocument = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { type, url, expiryDate } = req.body;
    
    if (!type || !url) {
      return res.status(400).json({
        success: false,
        error: 'Document type and URL are required'
      });
    }
    
    const driver = await Driver.findById(req.params.id);
    
    if (!driver) {
      return res.status(404).json({
        success: false,
        error: 'Driver not found'
      });
    }
    
    const newDocument = {
      type,
      url,
      verificationStatus: 'pending',
      expiryDate: expiryDate ? new Date(expiryDate) : undefined
    };
    
    if (!driver.documents) {
      driver.documents = [];
    }
    
    driver.documents.push(newDocument);
    await driver.save();
    
    res.status(200).json({
      success: true,
      data: driver
    });
  } catch (error) {
    logger.error(`Error adding document to driver with id ${req.params.id}`, { error });
    next(error);
  }
};

// Update driver document verification status
export const updateDriverDocumentStatus = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { documentId, verificationStatus } = req.body;
    
    if (!documentId || !verificationStatus) {
      return res.status(400).json({
        success: false,
        error: 'Document ID and verification status are required'
      });
    }
    
    if (!['unverified', 'pending', 'verified', 'rejected'].includes(verificationStatus)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid verification status'
      });
    }
    
    const driver = await Driver.findById(req.params.id);
    
    if (!driver) {
      return res.status(404).json({
        success: false,
        error: 'Driver not found'
      });
    }
    
    if (!driver.documents) {
      return res.status(404).json({
        success: false,
        error: 'No documents found for this driver'
      });
    }
    
    const documentIndex = driver.documents.findIndex(
      doc => doc._id.toString() === documentId
    );
    
    if (documentIndex === -1) {
      return res.status(404).json({
        success: false,
        error: 'Document not found'
      });
    }
    
    driver.documents[documentIndex].verificationStatus = verificationStatus;
    await driver.save();
    
    res.status(200).json({
      success: true,
      data: driver
    });
  } catch (error) {
    logger.error(`Error updating document status for driver with id ${req.params.id}`, { error });
    next(error);
  }
};

// Update driver availability
export const updateDriverAvailability = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { isAvailable } = req.body;
    
    if (isAvailable === undefined) {
      return res.status(400).json({
        success: false,
        error: 'Availability status is required'
      });
    }
    
    const driver = await Driver.findByIdAndUpdate(
      req.params.id,
      { isAvailable },
      {
        new: true,
        runValidators: true
      }
    );
    
    if (!driver) {
      return res.status(404).json({
        success: false,
        error: 'Driver not found'
      });
    }
    
    res.status(200).json({
      success: true,
      data: driver
    });
  } catch (error) {
    logger.error(`Error updating driver availability with id ${req.params.id}`, { error });
    next(error);
  }
};

// Update driver location
export const updateDriverLocation = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { latitude, longitude } = req.body;
    
    if (!latitude || !longitude) {
      return res.status(400).json({
        success: false,
        error: 'Latitude and longitude are required'
      });
    }
    
    const driver = await Driver.findByIdAndUpdate(
      req.params.id,
      {
        currentLocation: {
          latitude,
          longitude,
          updatedAt: new Date()
        }
      },
      {
        new: true,
        runValidators: true
      }
    );
    
    if (!driver) {
      return res.status(404).json({
        success: false,
        error: 'Driver not found'
      });
    }
    
    res.status(200).json({
      success: true,
      data: driver
    });
  } catch (error) {
    logger.error(`Error updating driver location with id ${req.params.id}`, { error });
    next(error);
  }
};

// Get available drivers near location
export const getAvailableDriversNearLocation = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { latitude, longitude, distance = 5, providerId } = req.query;
    
    if (!latitude || !longitude) {
      return res.status(400).json({
        success: false,
        error: 'Latitude and longitude are required'
      });
    }
    
    const lat = parseFloat(latitude as string);
    const lng = parseFloat(longitude as string);
    const dist = parseFloat(distance as string);
    
    if (isNaN(lat) || isNaN(lng) || isNaN(dist)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid coordinates or distance'
      });
    }
    
    // Build query
    const query: any = {
      'currentLocation.latitude': { $exists: true },
      'currentLocation.longitude': { $exists: true },
      isAvailable: true,
      status: 'active',
      verificationStatus: 'verified'
    };
    
    // If providerId is provided, filter by provider
    if (providerId) {
      query.providerId = providerId;
    }
    
    // Find drivers within the specified distance (in kilometers)
    // Note: This is a simplified approach. For production, use proper geospatial queries
    const drivers = await Driver.find(query);
    
    // Filter drivers by distance
    const nearbyDrivers = drivers.filter(driver => {
      if (!driver.currentLocation) return false;
      
      // Calculate distance using Haversine formula
      const R = 6371; // Earth radius in km
      const dLat = (driver.currentLocation.latitude - lat) * Math.PI / 180;
      const dLon = (driver.currentLocation.longitude - lng) * Math.PI / 180;
      const a = 
        Math.sin(dLat/2) * Math.sin(dLat/2) +
        Math.cos(lat * Math.PI / 180) * Math.cos(driver.currentLocation.latitude * Math.PI / 180) * 
        Math.sin(dLon/2) * Math.sin(dLon/2);
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
      const distance = R * c;
      
      return distance <= dist;
    });
    
    res.status(200).json({
      success: true,
      count: nearbyDrivers.length,
      data: nearbyDrivers
    });
  } catch (error) {
    logger.error('Error fetching available drivers near location', { error });
    next(error);
  }
};
