import { Request, Response, NextFunction } from 'express';
import Provider, { IProvider } from '../models/provider.model';
import logger from '../utils/logger';
import mongoose from 'mongoose';

// Get all providers
export const getAllProviders = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const providers = await Provider.find();
    
    res.status(200).json({
      success: true,
      count: providers.length,
      data: providers
    });
  } catch (error) {
    logger.error('Error fetching providers', { error });
    next(error);
  }
};

// Get single provider by ID
export const getProviderById = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const provider = await Provider.findById(req.params.id);
    
    if (!provider) {
      return res.status(404).json({
        success: false,
        error: 'Provider not found'
      });
    }
    
    res.status(200).json({
      success: true,
      data: provider
    });
  } catch (error) {
    logger.error(`Error fetching provider with id ${req.params.id}`, { error });
    next(error);
  }
};

// Create new provider
export const createProvider = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    // Check if provider with email already exists
    const existingProvider = await Provider.findOne({ email: req.body.email });
    
    if (existingProvider) {
      return res.status(400).json({
        success: false,
        error: 'Provider with this email already exists'
      });
    }
    
    const provider = await Provider.create(req.body);
    
    res.status(201).json({
      success: true,
      data: provider
    });
  } catch (error) {
    logger.error('Error creating provider', { error });
    
    if (error instanceof mongoose.Error.ValidationError) {
      const messages = Object.values(error.errors).map(val => val.message);
      return res.status(400).json({
        success: false,
        error: messages
      });
    }
    
    next(error);
  }
};

// Update provider
export const updateProvider = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    // Find provider and update
    const provider = await Provider.findByIdAndUpdate(
      req.params.id,
      req.body,
      {
        new: true,
        runValidators: true
      }
    );
    
    if (!provider) {
      return res.status(404).json({
        success: false,
        error: 'Provider not found'
      });
    }
    
    res.status(200).json({
      success: true,
      data: provider
    });
  } catch (error) {
    logger.error(`Error updating provider with id ${req.params.id}`, { error });
    
    if (error instanceof mongoose.Error.ValidationError) {
      const messages = Object.values(error.errors).map(val => val.message);
      return res.status(400).json({
        success: false,
        error: messages
      });
    }
    
    next(error);
  }
};

// Delete provider
export const deleteProvider = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const provider = await Provider.findById(req.params.id);
    
    if (!provider) {
      return res.status(404).json({
        success: false,
        error: 'Provider not found'
      });
    }
    
    await provider.deleteOne();
    
    res.status(200).json({
      success: true,
      data: {}
    });
  } catch (error) {
    logger.error(`Error deleting provider with id ${req.params.id}`, { error });
    next(error);
  }
};

// Update provider verification status
export const updateProviderVerificationStatus = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { verificationStatus } = req.body;
    
    if (!['unverified', 'pending', 'verified', 'rejected'].includes(verificationStatus)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid verification status'
      });
    }
    
    const provider = await Provider.findByIdAndUpdate(
      req.params.id,
      { verificationStatus },
      {
        new: true,
        runValidators: true
      }
    );
    
    if (!provider) {
      return res.status(404).json({
        success: false,
        error: 'Provider not found'
      });
    }
    
    res.status(200).json({
      success: true,
      data: provider
    });
  } catch (error) {
    logger.error(`Error updating provider verification status with id ${req.params.id}`, { error });
    next(error);
  }
};

// Add provider document
export const addProviderDocument = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { type, url, expiryDate } = req.body;
    
    if (!type || !url) {
      return res.status(400).json({
        success: false,
        error: 'Document type and URL are required'
      });
    }
    
    const provider = await Provider.findById(req.params.id);
    
    if (!provider) {
      return res.status(404).json({
        success: false,
        error: 'Provider not found'
      });
    }
    
    const newDocument = {
      type,
      url,
      verificationStatus: 'pending',
      expiryDate: expiryDate ? new Date(expiryDate) : undefined
    };
    
    if (!provider.documents) {
      provider.documents = [];
    }
    
    provider.documents.push(newDocument);
    await provider.save();
    
    res.status(200).json({
      success: true,
      data: provider
    });
  } catch (error) {
    logger.error(`Error adding document to provider with id ${req.params.id}`, { error });
    next(error);
  }
};

// Update provider document verification status
export const updateProviderDocumentStatus = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { documentId, verificationStatus } = req.body;
    
    if (!documentId || !verificationStatus) {
      return res.status(400).json({
        success: false,
        error: 'Document ID and verification status are required'
      });
    }
    
    if (!['unverified', 'pending', 'verified', 'rejected'].includes(verificationStatus)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid verification status'
      });
    }
    
    const provider = await Provider.findById(req.params.id);
    
    if (!provider) {
      return res.status(404).json({
        success: false,
        error: 'Provider not found'
      });
    }
    
    if (!provider.documents) {
      return res.status(404).json({
        success: false,
        error: 'No documents found for this provider'
      });
    }
    
    const documentIndex = provider.documents.findIndex(
      doc => doc._id.toString() === documentId
    );
    
    if (documentIndex === -1) {
      return res.status(404).json({
        success: false,
        error: 'Document not found'
      });
    }
    
    provider.documents[documentIndex].verificationStatus = verificationStatus;
    await provider.save();
    
    res.status(200).json({
      success: true,
      data: provider
    });
  } catch (error) {
    logger.error(`Error updating document status for provider with id ${req.params.id}`, { error });
    next(error);
  }
};

// Get providers by service type
export const getProvidersByServiceType = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { serviceType } = req.params;
    
    const providers = await Provider.find({
      serviceTypes: serviceType,
      status: 'active',
      verificationStatus: 'verified'
    });
    
    res.status(200).json({
      success: true,
      count: providers.length,
      data: providers
    });
  } catch (error) {
    logger.error(`Error fetching providers by service type ${req.params.serviceType}`, { error });
    next(error);
  }
};

// Get providers by location
export const getProvidersByLocation = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { latitude, longitude, distance = 10 } = req.query;
    
    if (!latitude || !longitude) {
      return res.status(400).json({
        success: false,
        error: 'Latitude and longitude are required'
      });
    }
    
    const lat = parseFloat(latitude as string);
    const lng = parseFloat(longitude as string);
    const dist = parseFloat(distance as string);
    
    if (isNaN(lat) || isNaN(lng) || isNaN(dist)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid coordinates or distance'
      });
    }
    
    // Find providers within the specified distance (in kilometers)
    const providers = await Provider.find({
      coordinates: {
        $near: {
          $geometry: {
            type: 'Point',
            coordinates: [lng, lat]
          },
          $maxDistance: dist * 1000 // Convert to meters
        }
      },
      status: 'active',
      verificationStatus: 'verified'
    });
    
    res.status(200).json({
      success: true,
      count: providers.length,
      data: providers
    });
  } catch (error) {
    logger.error('Error fetching providers by location', { error });
    next(error);
  }
};
