import { Request, Response, NextFunction } from 'express';
import Payment, { IPayment } from '../models/payment.model';
import Ride from '../models/ride.model';
import User from '../models/user.model';
import Provider from '../models/provider.model';
import logger from '../utils/logger';
import mongoose from 'mongoose';

// Process payment for a ride
export const processPayment = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { rideId } = req.params;
    const { paymentMethod, paymentToken } = req.body;

    // Check if required fields are provided
    if (!paymentMethod) {
      return res.status(400).json({
        success: false,
        error: 'Payment method is required'
      });
    }

    // Find ride
    const ride = await Ride.findById(rideId);

    if (!ride) {
      return res.status(404).json({
        success: false,
        error: 'Ride not found'
      });
    }

    // Check if user is authorized to process payment for this ride
    if (ride.userId.toString() !== (req as any).user.id) {
      return res.status(403).json({
        success: false,
        error: 'Not authorized to process payment for this ride'
      });
    }

    // Check if ride is in a valid state for payment
    const validStatuses = ['completed'];
    if (!validStatuses.includes(ride.status)) {
      return res.status(400).json({
        success: false,
        error: `Cannot process payment for ride with status ${ride.status}`
      });
    }

    // Check if payment is already processed
    if (ride.paymentStatus === 'completed') {
      return res.status(400).json({
        success: false,
        error: 'Payment already processed for this ride'
      });
    }

    // Get payment amount
    const amount = ride.finalPrice || ride.estimatedPrice;
    if (!amount) {
      return res.status(400).json({
        success: false,
        error: 'Ride has no price information'
      });
    }

    // Find provider
    const provider = await Provider.findById(ride.providerId);
    if (!provider) {
      return res.status(404).json({
        success: false,
        error: 'Provider not found'
      });
    }

    // Calculate fees
    const platformFee = amount * 0.15; // 15% platform fee
    const providerAmount = amount - platformFee;

    // In a real application, this would call a payment processor API
    // For this example, we'll simulate a successful payment
    const paymentIntentId = `pi_${Date.now()}_${Math.floor(Math.random() * 1000000)}`;
    
    // Create payment record
    const payment = await Payment.create({
      rideId,
      userId: ride.userId,
      providerId: ride.providerId,
      amount,
      currency: ride.currency || 'EUR',
      status: 'completed',
      paymentMethod: paymentMethod || ride.paymentMethod,
      paymentIntentId,
      platformFee,
      providerAmount,
      receiptUrl: `https://limburg-transport.example/receipts/${paymentIntentId}`,
      metadata: {
        rideType: ride.rideType,
        serviceType: ride.serviceType,
        distance: ride.actualDistance || ride.estimatedDistance,
        duration: ride.actualDuration || ride.estimatedDuration
      }
    });

    // Update ride with payment information
    ride.paymentStatus = 'completed';
    ride.paymentId = payment._id;
    await ride.save();

    res.status(200).json({
      success: true,
      data: payment
    });
  } catch (error) {
    logger.error(`Error processing payment for ride ${req.params.rideId}`, { error });
    next(error);
  }
};

// Get payment by ID
export const getPaymentById = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { id } = req.params;

    const payment = await Payment.findById(id);

    if (!payment) {
      return res.status(404).json({
        success: false,
        error: 'Payment not found'
      });
    }

    // Check if user is authorized to view this payment
    if (payment.userId.toString() !== (req as any).user.id) {
      return res.status(403).json({
        success: false,
        error: 'Not authorized to view this payment'
      });
    }

    res.status(200).json({
      success: true,
      data: payment
    });
  } catch (error) {
    logger.error(`Error getting payment with id ${req.params.id}`, { error });
    next(error);
  }
};

// Get user's payments
export const getUserPayments = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { status, limit = 10, page = 1 } = req.query;

    // Build query
    const query: any = { userId: (req as any).user.id };

    // Filter by status if provided
    if (status) {
      query.status = status;
    }

    // Calculate pagination
    const skip = (parseInt(page as string) - 1) * parseInt(limit as string);

    // Get payments
    const payments = await Payment.find(query)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit as string))
      .populate('rideId', 'status serviceType pickup destination')
      .populate('providerId', 'companyName');

    // Get total count
    const total = await Payment.countDocuments(query);

    res.status(200).json({
      success: true,
      count: payments.length,
      total,
      pagination: {
        page: parseInt(page as string),
        limit: parseInt(limit as string),
        pages: Math.ceil(total / parseInt(limit as string))
      },
      data: payments
    });
  } catch (error) {
    logger.error('Error getting user payments', { error });
    next(error);
  }
};

// Request refund
export const requestRefund = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { paymentId } = req.params;
    const { reason } = req.body;

    // Check if reason is provided
    if (!reason) {
      return res.status(400).json({
        success: false,
        error: 'Refund reason is required'
      });
    }

    // Find payment
    const payment = await Payment.findById(paymentId);

    if (!payment) {
      return res.status(404).json({
        success: false,
        error: 'Payment not found'
      });
    }

    // Check if user is authorized to request refund for this payment
    if (payment.userId.toString() !== (req as any).user.id) {
      return res.status(403).json({
        success: false,
        error: 'Not authorized to request refund for this payment'
      });
    }

    // Check if payment is in a valid state for refund
    if (payment.status !== 'completed') {
      return res.status(400).json({
        success: false,
        error: `Cannot request refund for payment with status ${payment.status}`
      });
    }

    // Check if payment is already refunded
    if (payment.status === 'refunded' || payment.status === 'partially_refunded') {
      return res.status(400).json({
        success: false,
        error: 'Payment already refunded'
      });
    }

    // In a real application, this would call a payment processor API
    // For this example, we'll simulate a successful refund
    
    // Update payment with refund information
    payment.status = 'refunded';
    payment.refundAmount = payment.amount;
    payment.refundReason = reason;
    await payment.save();

    // Update ride payment status
    const ride = await Ride.findById(payment.rideId);
    if (ride) {
      ride.paymentStatus = 'refunded';
      await ride.save();
    }

    res.status(200).json({
      success: true,
      data: payment
    });
  } catch (error) {
    logger.error(`Error requesting refund for payment ${req.params.paymentId}`, { error });
    next(error);
  }
};

// Generate payment receipt
export const generateReceipt = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { paymentId } = req.params;

    // Find payment
    const payment = await Payment.findById(paymentId)
      .populate('rideId', 'serviceType pickup destination requestTime dropoffTime estimatedDistance actualDistance')
      .populate('providerId', 'companyName address')
      .populate('userId', 'firstName lastName email');

    if (!payment) {
      return res.status(404).json({
        success: false,
        error: 'Payment not found'
      });
    }

    // Check if user is authorized to view this payment
    if (payment.userId._id.toString() !== (req as any).user.id) {
      return res.status(403).json({
        success: false,
        error: 'Not authorized to view this payment'
      });
    }

    // In a real application, this would generate a PDF receipt
    // For this example, we'll return a receipt object
    const receipt = {
      receiptNumber: `R-${payment._id.toString().substr(-6)}`,
      date: payment.createdAt,
      customer: {
        name: `${payment.userId.firstName} ${payment.userId.lastName}`,
        email: payment.userId.email
      },
      provider: {
        name: payment.providerId.companyName,
        address: payment.providerId.address
      },
      ride: {
        from: payment.rideId.pickup.address,
        to: payment.rideId.destination.address,
        date: payment.rideId.requestTime,
        completedAt: payment.rideId.dropoffTime,
        distance: payment.rideId.actualDistance || payment.rideId.estimatedDistance,
        serviceType: payment.rideId.serviceType
      },
      payment: {
        amount: payment.amount,
        currency: payment.currency,
        method: payment.paymentMethod,
        status: payment.status,
        platformFee: payment.platformFee,
        refundAmount: payment.refundAmount
      }
    };

    res.status(200).json({
      success: true,
      data: receipt
    });
  } catch (error) {
    logger.error(`Error generating receipt for payment ${req.params.paymentId}`, { error });
    next(error);
  }
};
