import { Request, Response, NextFunction } from 'express';
import Ride, { IRide } from '../models/ride.model';
import User from '../models/user.model';
import Provider from '../models/provider.model';
import Driver from '../models/driver.model';
import Vehicle from '../models/vehicle.model';
import Payment from '../models/payment.model';
import logger from '../utils/logger';
import mongoose from 'mongoose';

// Request a new ride
export const requestRide = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const {
      providerId,
      rideType,
      serviceType,
      pickup,
      destination,
      intermediateStops,
      scheduledTime,
      paymentMethod,
      specialRequirements,
      passengerCount
    } = req.body;

    // Check if required fields are provided
    if (!providerId || !serviceType || !pickup || !destination || !paymentMethod) {
      return res.status(400).json({
        success: false,
        error: 'Provider ID, service type, pickup, destination, and payment method are required'
      });
    }

    // Validate provider exists
    const provider = await Provider.findById(providerId);
    if (!provider) {
      return res.status(404).json({
        success: false,
        error: 'Provider not found'
      });
    }

    // Validate provider is active and verified
    if (provider.status !== 'active' || provider.verificationStatus !== 'verified') {
      return res.status(400).json({
        success: false,
        error: 'Provider is not active or verified'
      });
    }

    // Validate provider offers the requested service type
    if (!provider.serviceTypes.includes(serviceType)) {
      return res.status(400).json({
        success: false,
        error: `Provider does not offer ${serviceType} service`
      });
    }

    // For scheduled rides, validate scheduled time
    if (rideType === 'scheduled') {
      if (!scheduledTime) {
        return res.status(400).json({
          success: false,
          error: 'Scheduled time is required for scheduled rides'
        });
      }

      const scheduledDate = new Date(scheduledTime);
      const now = new Date();

      // Scheduled time must be at least 30 minutes in the future
      if (scheduledDate.getTime() - now.getTime() < 30 * 60 * 1000) {
        return res.status(400).json({
          success: false,
          error: 'Scheduled time must be at least 30 minutes in the future'
        });
      }
    }

    // Create new ride
    const ride = await Ride.create({
      userId: (req as any).user.id,
      providerId,
      status: rideType === 'scheduled' ? 'scheduled' : 'requested',
      rideType: rideType || 'immediate',
      serviceType,
      pickup,
      destination,
      intermediateStops,
      scheduledTime: scheduledTime ? new Date(scheduledTime) : undefined,
      requestTime: new Date(),
      paymentMethod,
      specialRequirements,
      passengerCount: passengerCount || 1,
      currency: 'EUR'
    });

    // Calculate estimated price, distance, and duration
    // Note: In a real application, this would use a mapping service API
    // For this example, we'll use a simplified calculation
    const estimatedDistance = calculateDistance(
      pickup.coordinates.latitude,
      pickup.coordinates.longitude,
      destination.coordinates.latitude,
      destination.coordinates.longitude
    );

    const estimatedDuration = Math.round(estimatedDistance * 2); // Rough estimate: 2 minutes per km
    const basePrice = 2.5; // Base fare in EUR
    const pricePerKm = 1.8; // Price per km in EUR
    const estimatedPrice = basePrice + (pricePerKm * estimatedDistance);

    // Update ride with estimates
    ride.estimatedDistance = parseFloat(estimatedDistance.toFixed(2));
    ride.estimatedDuration = estimatedDuration;
    ride.estimatedPrice = parseFloat(estimatedPrice.toFixed(2));
    await ride.save();

    // If immediate ride, start searching for a driver
    if (rideType !== 'scheduled') {
      // In a real application, this would trigger a background job or websocket event
      // For this example, we'll just update the status
      ride.status = 'searching';
      await ride.save();
    }

    res.status(201).json({
      success: true,
      data: ride
    });
  } catch (error) {
    logger.error('Error requesting ride', { error });
    next(error);
  }
};

// Get ride by ID
export const getRideById = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { id } = req.params;

    const ride = await Ride.findById(id)
      .populate('providerId', 'companyName phone email')
      .populate('driverId', 'firstName lastName phone profilePicture')
      .populate('vehicleId', 'make model color licensePlate');

    if (!ride) {
      return res.status(404).json({
        success: false,
        error: 'Ride not found'
      });
    }

    // Check if user is authorized to view this ride
    if (ride.userId.toString() !== (req as any).user.id) {
      return res.status(403).json({
        success: false,
        error: 'Not authorized to view this ride'
      });
    }

    res.status(200).json({
      success: true,
      data: ride
    });
  } catch (error) {
    logger.error(`Error getting ride with id ${req.params.id}`, { error });
    next(error);
  }
};

// Get user's rides
export const getUserRides = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { status, limit = 10, page = 1 } = req.query;

    // Build query
    const query: any = { userId: (req as any).user.id };

    // Filter by status if provided
    if (status) {
      query.status = status;
    }

    // Calculate pagination
    const skip = (parseInt(page as string) - 1) * parseInt(limit as string);

    // Get rides
    const rides = await Ride.find(query)
      .sort({ requestTime: -1 })
      .skip(skip)
      .limit(parseInt(limit as string))
      .populate('providerId', 'companyName')
      .populate('driverId', 'firstName lastName')
      .populate('vehicleId', 'make model color');

    // Get total count
    const total = await Ride.countDocuments(query);

    res.status(200).json({
      success: true,
      count: rides.length,
      total,
      pagination: {
        page: parseInt(page as string),
        limit: parseInt(limit as string),
        pages: Math.ceil(total / parseInt(limit as string))
      },
      data: rides
    });
  } catch (error) {
    logger.error('Error getting user rides', { error });
    next(error);
  }
};

// Cancel ride
export const cancelRide = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { id } = req.params;
    const { reason } = req.body;

    const ride = await Ride.findById(id);

    if (!ride) {
      return res.status(404).json({
        success: false,
        error: 'Ride not found'
      });
    }

    // Check if user is authorized to cancel this ride
    if (ride.userId.toString() !== (req as any).user.id) {
      return res.status(403).json({
        success: false,
        error: 'Not authorized to cancel this ride'
      });
    }

    // Check if ride can be cancelled
    const cancelableStatuses = ['requested', 'searching', 'accepted', 'scheduled'];
    if (!cancelableStatuses.includes(ride.status)) {
      return res.status(400).json({
        success: false,
        error: `Cannot cancel ride with status ${ride.status}`
      });
    }

    // Update ride
    ride.status = 'cancelled';
    ride.cancelTime = new Date();
    ride.cancelReason = reason || 'Cancelled by user';
    ride.cancelledBy = 'user';
    await ride.save();

    // If payment was already processed, initiate refund
    if (ride.paymentStatus === 'completed' && ride.paymentId) {
      // In a real application, this would call the payment provider's API
      // For this example, we'll just create a refund record
      await Payment.findOneAndUpdate(
        { _id: ride.paymentId },
        {
          status: 'refunded',
          refundAmount: ride.finalPrice || ride.estimatedPrice,
          refundReason: 'Ride cancelled by user'
        }
      );

      ride.paymentStatus = 'refunded';
      await ride.save();
    }

    res.status(200).json({
      success: true,
      data: ride
    });
  } catch (error) {
    logger.error(`Error cancelling ride with id ${req.params.id}`, { error });
    next(error);
  }
};

// Rate ride
export const rateRide = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { id } = req.params;
    const { score, comment } = req.body;

    // Validate rating
    if (!score || score < 1 || score > 5) {
      return res.status(400).json({
        success: false,
        error: 'Rating must be between 1 and 5'
      });
    }

    const ride = await Ride.findById(id);

    if (!ride) {
      return res.status(404).json({
        success: false,
        error: 'Ride not found'
      });
    }

    // Check if user is authorized to rate this ride
    if (ride.userId.toString() !== (req as any).user.id) {
      return res.status(403).json({
        success: false,
        error: 'Not authorized to rate this ride'
      });
    }

    // Check if ride is completed
    if (ride.status !== 'completed') {
      return res.status(400).json({
        success: false,
        error: 'Can only rate completed rides'
      });
    }

    // Check if ride is already rated by user
    if (ride.rating && ride.rating.driver) {
      return res.status(400).json({
        success: false,
        error: 'Ride already rated'
      });
    }

    // Update ride with rating
    if (!ride.rating) {
      ride.rating = {};
    }
    
    ride.rating.driver = {
      score,
      comment,
      createdAt: new Date()
    };
    
    await ride.save();

    // Update driver's rating
    if (ride.driverId) {
      const driver = await Driver.findById(ride.driverId);
      if (driver) {
        // Calculate new average rating
        const totalRatings = (driver.ratingCount || 0) + 1;
        const currentTotalScore = (driver.ratingAverage || 0) * (driver.ratingCount || 0);
        const newAverage = (currentTotalScore + score) / totalRatings;
        
        // Update driver
        driver.ratingAverage = parseFloat(newAverage.toFixed(2));
        driver.ratingCount = totalRatings;
        await driver.save();
      }
    }

    res.status(200).json({
      success: true,
      data: ride
    });
  } catch (error) {
    logger.error(`Error rating ride with id ${req.params.id}`, { error });
    next(error);
  }
};

// Helper function to calculate distance between two coordinates using Haversine formula
const calculateDistance = (
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number => {
  const R = 6371; // Earth radius in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  const distance = R * c;
  
  return distance;
};
