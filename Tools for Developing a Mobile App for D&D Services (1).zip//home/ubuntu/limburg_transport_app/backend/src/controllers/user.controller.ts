import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import User, { IUser } from '../models/user.model';
import logger from '../utils/logger';
import config from '../config/config';

// Register new user
export const registerUser = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { firstName, lastName, email, password, phone } = req.body;

    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({
        success: false,
        error: 'User with this email already exists'
      });
    }

    // Create new user
    const user = await User.create({
      firstName,
      lastName,
      email,
      password,
      phone
    });

    // Generate JWT token
    const token = jwt.sign(
      { id: user._id, role: 'user' },
      config.jwtSecret,
      { expiresIn: config.jwtExpiresIn }
    );

    res.status(201).json({
      success: true,
      token,
      data: {
        id: user._id,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        phone: user.phone,
        role: user.role
      }
    });
  } catch (error) {
    logger.error('Error registering user', { error });
    next(error);
  }
};

// Login user
export const loginUser = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { email, password } = req.body;

    // Check if email and password are provided
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        error: 'Please provide email and password'
      });
    }

    // Find user by email and include password field
    const user = await User.findOne({ email }).select('+password');

    // Check if user exists
    if (!user) {
      return res.status(401).json({
        success: false,
        error: 'Invalid credentials'
      });
    }

    // Check if password matches
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        error: 'Invalid credentials'
      });
    }

    // Check if user is active
    if (user.status !== 'active') {
      return res.status(403).json({
        success: false,
        error: 'Your account is not active. Please contact support.'
      });
    }

    // Generate JWT token
    const token = jwt.sign(
      { id: user._id, role: 'user' },
      config.jwtSecret,
      { expiresIn: config.jwtExpiresIn }
    );

    res.status(200).json({
      success: true,
      token,
      data: {
        id: user._id,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        phone: user.phone,
        role: user.role
      }
    });
  } catch (error) {
    logger.error('Error logging in user', { error });
    next(error);
  }
};

// Get current user profile
export const getCurrentUser = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const user = await User.findById((req as any).user.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    res.status(200).json({
      success: true,
      data: user
    });
  } catch (error) {
    logger.error('Error getting current user', { error });
    next(error);
  }
};

// Update user profile
export const updateUserProfile = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    // Fields that are not allowed to be updated
    const restrictedFields = ['password', 'role', 'status'];
    
    // Check if request contains restricted fields
    const updates = Object.keys(req.body);
    const isRestrictedUpdate = updates.some(update => restrictedFields.includes(update));
    
    if (isRestrictedUpdate) {
      return res.status(400).json({
        success: false,
        error: 'Cannot update restricted fields'
      });
    }

    // Find and update user
    const user = await User.findByIdAndUpdate(
      (req as any).user.id,
      req.body,
      {
        new: true,
        runValidators: true
      }
    );

    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    res.status(200).json({
      success: true,
      data: user
    });
  } catch (error) {
    logger.error('Error updating user profile', { error });
    next(error);
  }
};

// Change password
export const changePassword = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { currentPassword, newPassword } = req.body;

    // Check if passwords are provided
    if (!currentPassword || !newPassword) {
      return res.status(400).json({
        success: false,
        error: 'Please provide current and new password'
      });
    }

    // Find user by ID and include password field
    const user = await User.findById((req as any).user.id).select('+password');

    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    // Check if current password matches
    const isMatch = await user.comparePassword(currentPassword);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        error: 'Current password is incorrect'
      });
    }

    // Update password
    user.password = newPassword;
    await user.save();

    res.status(200).json({
      success: true,
      message: 'Password updated successfully'
    });
  } catch (error) {
    logger.error('Error changing password', { error });
    next(error);
  }
};

// Add payment method
export const addPaymentMethod = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { type, cardNumber, expiryDate, cardholderName, isDefault } = req.body;

    // Check if required fields are provided
    if (!type) {
      return res.status(400).json({
        success: false,
        error: 'Payment method type is required'
      });
    }

    // For card payments, validate additional fields
    if ((type === 'credit_card' || type === 'debit_card') && 
        (!cardNumber || !expiryDate || !cardholderName)) {
      return res.status(400).json({
        success: false,
        error: 'Card details are required for credit/debit card payment methods'
      });
    }

    // Find user
    const user = await User.findById((req as any).user.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    // Create new payment method
    const newPaymentMethod = {
      type,
      cardNumber: cardNumber ? cardNumber.slice(-4) : undefined, // Store only last 4 digits
      expiryDate,
      cardholderName,
      isDefault: isDefault || false
    };

    // If this is the first payment method or set as default, update all others
    if (isDefault || !user.paymentMethods || user.paymentMethods.length === 0) {
      if (user.paymentMethods && user.paymentMethods.length > 0) {
        user.paymentMethods.forEach(method => {
          method.isDefault = false;
        });
      }
      newPaymentMethod.isDefault = true;
      user.preferredPaymentMethod = type;
    }

    // Add new payment method
    if (!user.paymentMethods) {
      user.paymentMethods = [];
    }
    user.paymentMethods.push(newPaymentMethod);

    // Save user
    await user.save();

    res.status(200).json({
      success: true,
      data: user.paymentMethods
    });
  } catch (error) {
    logger.error('Error adding payment method', { error });
    next(error);
  }
};

// Remove payment method
export const removePaymentMethod = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { paymentMethodId } = req.params;

    // Find user
    const user = await User.findById((req as any).user.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    // Check if user has payment methods
    if (!user.paymentMethods || user.paymentMethods.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'No payment methods found'
      });
    }

    // Find payment method index
    const paymentMethodIndex = user.paymentMethods.findIndex(
      method => method._id.toString() === paymentMethodId
    );

    if (paymentMethodIndex === -1) {
      return res.status(404).json({
        success: false,
        error: 'Payment method not found'
      });
    }

    // Check if removing default payment method
    const isDefault = user.paymentMethods[paymentMethodIndex].isDefault;

    // Remove payment method
    user.paymentMethods.splice(paymentMethodIndex, 1);

    // If removed default payment method and other methods exist, set a new default
    if (isDefault && user.paymentMethods.length > 0) {
      user.paymentMethods[0].isDefault = true;
      user.preferredPaymentMethod = user.paymentMethods[0].type;
    } else if (user.paymentMethods.length === 0) {
      user.preferredPaymentMethod = undefined;
    }

    // Save user
    await user.save();

    res.status(200).json({
      success: true,
      data: user.paymentMethods
    });
  } catch (error) {
    logger.error('Error removing payment method', { error });
    next(error);
  }
};

// Set default payment method
export const setDefaultPaymentMethod = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { paymentMethodId } = req.params;

    // Find user
    const user = await User.findById((req as any).user.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    // Check if user has payment methods
    if (!user.paymentMethods || user.paymentMethods.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'No payment methods found'
      });
    }

    // Find payment method index
    const paymentMethodIndex = user.paymentMethods.findIndex(
      method => method._id.toString() === paymentMethodId
    );

    if (paymentMethodIndex === -1) {
      return res.status(404).json({
        success: false,
        error: 'Payment method not found'
      });
    }

    // Update all payment methods
    user.paymentMethods.forEach((method, index) => {
      method.isDefault = index === paymentMethodIndex;
    });

    // Update preferred payment method
    user.preferredPaymentMethod = user.paymentMethods[paymentMethodIndex].type;

    // Save user
    await user.save();

    res.status(200).json({
      success: true,
      data: user.paymentMethods
    });
  } catch (error) {
    logger.error('Error setting default payment method', { error });
    next(error);
  }
};

// Add favorite location
export const addFavoriteLocation = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { name, address, coordinates, type } = req.body;

    // Check if required fields are provided
    if (!name || !address || !coordinates || !coordinates.latitude || !coordinates.longitude) {
      return res.status(400).json({
        success: false,
        error: 'Name, address, and coordinates are required'
      });
    }

    // Find user
    const user = await User.findById((req as any).user.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    // Create new favorite location
    const newLocation = {
      name,
      address,
      coordinates,
      type: type || 'other'
    };

    // Add new favorite location
    if (!user.favoriteLocations) {
      user.favoriteLocations = [];
    }
    user.favoriteLocations.push(newLocation);

    // Save user
    await user.save();

    res.status(200).json({
      success: true,
      data: user.favoriteLocations
    });
  } catch (error) {
    logger.error('Error adding favorite location', { error });
    next(error);
  }
};

// Remove favorite location
export const removeFavoriteLocation = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { locationId } = req.params;

    // Find user
    const user = await User.findById((req as any).user.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    // Check if user has favorite locations
    if (!user.favoriteLocations || user.favoriteLocations.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'No favorite locations found'
      });
    }

    // Find location index
    const locationIndex = user.favoriteLocations.findIndex(
      location => location._id.toString() === locationId
    );

    if (locationIndex === -1) {
      return res.status(404).json({
        success: false,
        error: 'Favorite location not found'
      });
    }

    // Remove location
    user.favoriteLocations.splice(locationIndex, 1);

    // Save user
    await user.save();

    res.status(200).json({
      success: true,
      data: user.favoriteLocations
    });
  } catch (error) {
    logger.error('Error removing favorite location', { error });
    next(error);
  }
};

// Add favorite provider
export const addFavoriteProvider = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { providerId } = req.body;

    // Check if provider ID is provided
    if (!providerId) {
      return res.status(400).json({
        success: false,
        error: 'Provider ID is required'
      });
    }

    // Find user
    const user = await User.findById((req as any).user.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    // Check if provider already in favorites
    if (user.favoriteProviders && user.favoriteProviders.includes(providerId)) {
      return res.status(400).json({
        success: false,
        error: 'Provider already in favorites'
      });
    }

    // Add provider to favorites
    if (!user.favoriteProviders) {
      user.favoriteProviders = [];
    }
    user.favoriteProviders.push(providerId);

    // Save user
    await user.save();

    res.status(200).json({
      success: true,
      data: user.favoriteProviders
    });
  } catch (error) {
    logger.error('Error adding favorite provider', { error });
    next(error);
  }
};

// Remove favorite provider
export const removeFavoriteProvider = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { providerId } = req.params;

    // Find user
    const user = await User.findById((req as any).user.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    // Check if user has favorite providers
    if (!user.favoriteProviders || user.favoriteProviders.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'No favorite providers found'
      });
    }

    // Find provider index
    const providerIndex = user.favoriteProviders.findIndex(
      provider => provider.toString() === providerId
    );

    if (providerIndex === -1) {
      return res.status(404).json({
        success: false,
        error: 'Provider not in favorites'
      });
    }

    // Remove provider from favorites
    user.favoriteProviders.splice(providerIndex, 1);

    // Save user
    await user.save();

    res.status(200).json({
      success: true,
      data: user.favoriteProviders
    });
  } catch (error) {
    logger.error('Error removing favorite provider', { error });
    next(error);
  }
};
