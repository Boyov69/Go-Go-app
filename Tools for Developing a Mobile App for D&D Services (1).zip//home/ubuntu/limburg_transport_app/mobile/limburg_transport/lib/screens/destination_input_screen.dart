import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:limburg_transport/providers/ride_provider.dart';
import 'package:limburg_transport/utils/theme.dart';
import 'package:limburg_transport/widgets/custom_button.dart';

class DestinationInputScreen extends StatefulWidget {
  const DestinationInputScreen({super.key});

  @override
  State<DestinationInputScreen> createState() => _DestinationInputScreenState();
}

class _DestinationInputScreenState extends State<DestinationInputScreen> {
  final TextEditingController _pickupController = TextEditingController();
  final TextEditingController _destinationController = TextEditingController();
  final FocusNode _pickupFocusNode = FocusNode();
  final FocusNode _destinationFocusNode = FocusNode();
  
  bool _isLoading = false;
  bool _hasCalculatedPrice = false;
  List<Map<String, dynamic>> _pickupSuggestions = [];
  List<Map<String, dynamic>> _destinationSuggestions = [];
  Map<String, dynamic>? _selectedPickup;
  Map<String, dynamic>? _selectedDestination;
  Map<String, dynamic>? _rideEstimate;
  
  @override
  void initState() {
    super.initState();
    _pickupFocusNode.addListener(_onPickupFocusChange);
    _destinationFocusNode.addListener(_onDestinationFocusChange);
  }
  
  @override
  void dispose() {
    _pickupController.dispose();
    _destinationController.dispose();
    _pickupFocusNode.removeListener(_onPickupFocusChange);
    _destinationFocusNode.removeListener(_onDestinationFocusChange);
    _pickupFocusNode.dispose();
    _destinationFocusNode.dispose();
    super.dispose();
  }
  
  void _onPickupFocusChange() {
    if (_pickupFocusNode.hasFocus) {
      _getSuggestions(_pickupController.text, true);
    }
  }
  
  void _onDestinationFocusChange() {
    if (_destinationFocusNode.hasFocus) {
      _getSuggestions(_destinationController.text, false);
    }
  }
  
  Future<void> _getSuggestions(String query, bool isPickup) async {
    if (query.length < 3) {
      setState(() {
        if (isPickup) {
          _pickupSuggestions = [];
        } else {
          _destinationSuggestions = [];
        }
      });
      return;
    }
    
    setState(() {
      _isLoading = true;
    });
    
    try {
      final rideProvider = Provider.of<RideProvider>(context, listen: false);
      final suggestions = await rideProvider.getLocationSuggestions(query);
      
      setState(() {
        if (isPickup) {
          _pickupSuggestions = suggestions;
        } else {
          _destinationSuggestions = suggestions;
        }
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to get suggestions: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }
  
  Future<void> _calculateRideEstimate() async {
    if (_selectedPickup == null || _selectedDestination == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select pickup and destination locations'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }
    
    setState(() {
      _isLoading = true;
      _hasCalculatedPrice = false;
    });
    
    try {
      final rideProvider = Provider.of<RideProvider>(context, listen: false);
      final estimate = await rideProvider.calculateRideEstimate(
        _selectedPickup!['placeId'],
        _selectedDestination!['placeId'],
      );
      
      setState(() {
        _rideEstimate = estimate;
        _isLoading = false;
        _hasCalculatedPrice = true;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to calculate ride estimate: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }
  
  void _selectLocation(Map<String, dynamic> location, bool isPickup) {
    setState(() {
      if (isPickup) {
        _selectedPickup = location;
        _pickupController.text = location['description'];
        _pickupSuggestions = [];
        FocusScope.of(context).requestFocus(_destinationFocusNode);
      } else {
        _selectedDestination = location;
        _destinationController.text = location['description'];
        _destinationSuggestions = [];
        FocusScope.of(context).unfocus();
        
        // Auto-calculate ride estimate when both locations are selected
        if (_selectedPickup != null && _selectedDestination != null) {
          _calculateRideEstimate();
        }
      }
    });
  }
  
  void _proceedToBooking() {
    if (_rideEstimate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please calculate ride estimate first'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }
    
    Navigator.pushNamed(
      context,
      '/book-ride',
      arguments: {
        'pickup': _selectedPickup,
        'destination': _selectedDestination,
        'estimate': _rideEstimate,
      },
    );
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Plan Your Ride'),
      ),
      body: GestureDetector(
        onTap: () {
          FocusScope.of(context).unfocus();
        },
        child: Column(
          children: [
            // Location input section
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    spreadRadius: 1,
                    blurRadius: 3,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                children: [
                  // Pickup location
                  TextField(
                    controller: _pickupController,
                    focusNode: _pickupFocusNode,
                    decoration: InputDecoration(
                      hintText: 'Enter pickup location',
                      prefixIcon: const Icon(
                        Icons.my_location,
                        color: AppTheme.primaryColor,
                      ),
                      suffixIcon: _pickupController.text.isNotEmpty
                          ? IconButton(
                              icon: const Icon(Icons.clear),
                              onPressed: () {
                                setState(() {
                                  _pickupController.clear();
                                  _selectedPickup = null;
                                  _hasCalculatedPrice = false;
                                });
                              },
                            )
                          : null,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                    ),
                    onChanged: (value) {
                      _getSuggestions(value, true);
                      setState(() {
                        _hasCalculatedPrice = false;
                      });
                    },
                  ),
                  const SizedBox(height: 16),
                  
                  // Destination location
                  TextField(
                    controller: _destinationController,
                    focusNode: _destinationFocusNode,
                    decoration: InputDecoration(
                      hintText: 'Enter destination',
                      prefixIcon: const Icon(
                        Icons.location_on,
                        color: Colors.red,
                      ),
                      suffixIcon: _destinationController.text.isNotEmpty
                          ? IconButton(
                              icon: const Icon(Icons.clear),
                              onPressed: () {
                                setState(() {
                                  _destinationController.clear();
                                  _selectedDestination = null;
                                  _hasCalculatedPrice = false;
                                });
                              },
                            )
                          : null,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                    ),
                    onChanged: (value) {
                      _getSuggestions(value, false);
                      setState(() {
                        _hasCalculatedPrice = false;
                      });
                    },
                  ),
                  const SizedBox(height: 16),
                  
                  // Calculate button
                  CustomButton(
                    text: 'Calculate Ride Cost',
                    onPressed: _calculateRideEstimate,
                    isLoading: _isLoading,
                    width: double.infinity,
                  ),
                ],
              ),
            ),
            
            // Suggestions
            if (_pickupFocusNode.hasFocus && _pickupSuggestions.isNotEmpty)
              Expanded(
                child: _buildSuggestionsList(_pickupSuggestions, true),
              )
            else if (_destinationFocusNode.hasFocus && _destinationSuggestions.isNotEmpty)
              Expanded(
                child: _buildSuggestionsList(_destinationSuggestions, false),
              )
            else if (_hasCalculatedPrice && _rideEstimate != null)
              Expanded(
                child: _buildRideEstimate(),
              )
            else
              Expanded(
                child: _buildEmptyState(),
              ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildSuggestionsList(List<Map<String, dynamic>> suggestions, bool isPickup) {
    return ListView.builder(
      padding: const EdgeInsets.all(0),
      itemCount: suggestions.length,
      itemBuilder: (context, index) {
        final suggestion = suggestions[index];
        return ListTile(
          leading: Icon(
            isPickup ? Icons.my_location : Icons.location_on,
            color: isPickup ? AppTheme.primaryColor : Colors.red,
          ),
          title: Text(suggestion['mainText']),
          subtitle: Text(
            suggestion['secondaryText'],
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          onTap: () {
            _selectLocation(suggestion, isPickup);
          },
        );
      },
    );
  }
  
  Widget _buildRideEstimate() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Route summary
          Card(
            margin: const EdgeInsets.only(bottom: 16),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Route Summary',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      const Icon(
                        Icons.my_location,
                        color: AppTheme.primaryColor,
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Pickup',
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 12,
                              ),
                            ),
                            Text(
                              _selectedPickup!['description'],
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 12),
                    child: SizedBox(
                      height: 30,
                      child: VerticalDivider(
                        color: Colors.grey[400],
                        thickness: 1,
                        width: 20,
                      ),
                    ),
                  ),
                  Row(
                    children: [
                      const Icon(
                        Icons.location_on,
                        color: Colors.red,
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Destination',
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 12,
                              ),
                            ),
                            Text(
                              _selectedDestination!['description'],
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          
          // Ride details
          Card(
            margin: const EdgeInsets.only(bottom: 16),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Ride Details',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Distance',
                            style: TextStyle(
                              color: Colors.grey,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            '${_rideEstimate!['dist
(Content truncated due to size limit. Use line ranges to read in chunks)