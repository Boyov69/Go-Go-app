import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:limburg_transport/providers/ride_provider.dart';
import 'package:limburg_transport/providers/transport_provider.dart';
import 'package:limburg_transport/utils/theme.dart';
import 'package:limburg_transport/widgets/custom_button.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

class BookRideScreen extends StatefulWidget {
  final Map<String, dynamic>? initialData;
  
  const BookRideScreen({super.key, this.initialData});

  @override
  State<BookRideScreen> createState() => _BookRideScreenState();
}

class _BookRideScreenState extends State<BookRideScreen> {
  final _formKey = GlobalKey<FormState>();
  
  final _pickupController = TextEditingController();
  final _destinationController = TextEditingController();
  final _notesController = TextEditingController();
  
  DateTime? _scheduledTime;
  String _serviceType = 'taxi';
  String _selectedProviderId = '';
  
  bool _isScheduled = false;
  int _currentStep = 0;
  
  final List<String> _serviceTypes = ['taxi', 'luxury', 'van', 'healthcare'];
  
  @override
  void initState() {
    super.initState();
    
    // If initialData contains a serviceType, set it
    if (widget.initialData != null && widget.initialData!.containsKey('serviceType')) {
      _serviceType = widget.initialData!['serviceType'].toString().toLowerCase();
    }
    
    // Fetch providers for selection
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<TransportProvider>(context, listen: false).fetchProviders();
    });
  }
  
  @override
  void dispose() {
    _pickupController.dispose();
    _destinationController.dispose();
    _notesController.dispose();
    super.dispose();
  }
  
  void _bookRide() async {
    if (_formKey.currentState!.validate()) {
      final rideProvider = Provider.of<RideProvider>(context, listen: false);
      
      try {
        final rideData = {
          'pickup': {
            'address': _pickupController.text,
            'coordinates': [5.3276, 50.9307], // Mock coordinates for Hasselt
          },
          'destination': {
            'address': _destinationController.text,
            'coordinates': [5.5022, 50.9659], // Mock coordinates for Genk
          },
          'serviceType': _serviceType,
          'scheduledTime': _isScheduled ? _scheduledTime!.toIso8601String() : null,
          'notes': _notesController.text.isNotEmpty ? _notesController.text : null,
          'providerId': _selectedProviderId.isNotEmpty ? _selectedProviderId : null,
        };
        
        final newRide = await rideProvider.bookRide(rideData);
        
        if (!mounted) return;
        
        // Navigate to ride details or payment screen
        if (_isScheduled) {
          // For scheduled rides, go to confirmation
          Navigator.pushReplacementNamed(
            context, 
            '/ride-confirmation',
            arguments: newRide['id'],
          );
        } else {
          // For immediate rides, go to tracking
          Navigator.pushReplacementNamed(
            context, 
            '/ride-tracking',
            arguments: newRide['id'],
          );
        }
      } catch (e) {
        // Show error message
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to book ride: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }
  
  @override
  Widget build(BuildContext context) {
    final transportProvider = Provider.of<TransportProvider>(context);
    final rideProvider = Provider.of<RideProvider>(context);
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('Book a Ride'),
      ),
      body: Stepper(
        currentStep: _currentStep,
        onStepContinue: () {
          if (_currentStep < 2) {
            setState(() {
              _currentStep += 1;
            });
          } else {
            _bookRide();
          }
        },
        onStepCancel: () {
          if (_currentStep > 0) {
            setState(() {
              _currentStep -= 1;
            });
          } else {
            Navigator.pop(context);
          }
        },
        controlsBuilder: (context, details) {
          return Padding(
            padding: const EdgeInsets.only(top: 20.0),
            child: Row(
              children: [
                CustomButton(
                  text: _currentStep == 2 ? 'Book Now' : 'Continue',
                  onPressed: details.onStepContinue!,
                  isLoading: rideProvider.isLoading,
                  width: 120,
                ),
                const SizedBox(width: 12),
                TextButton(
                  onPressed: details.onStepCancel!,
                  child: Text(_currentStep == 0 ? 'Cancel' : 'Back'),
                ),
              ],
            ),
          );
        },
        steps: [
          // Step 1: Location
          Step(
            title: const Text('Pickup & Destination'),
            content: Form(
              key: _formKey,
              child: Column(
                children: [
                  // Map preview (mock)
                  Container(
                    height: 200,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: Colors.grey[300],
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Center(
                      child: Icon(
                        Icons.map,
                        size: 80,
                        color: Colors.grey,
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  
                  // Pickup location
                  TextFormField(
                    controller: _pickupController,
                    decoration: const InputDecoration(
                      labelText: 'Pickup Location',
                      prefixIcon: Icon(Icons.location_on),
                      suffixIcon: Icon(Icons.my_location),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter pickup location';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  
                  // Destination
                  TextFormField(
                    controller: _destinationController,
                    decoration: const InputDecoration(
                      labelText: 'Destination',
                      prefixIcon: Icon(Icons.location_on),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter destination';
                      }
                      return null;
                    },
                  ),
                ],
              ),
            ),
            isActive: _currentStep >= 0,
            state: _currentStep > 0 ? StepState.complete : StepState.indexed,
          ),
          
          // Step 2: Service Type
          Step(
            title: const Text('Service Type'),
            content: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Select Service Type',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 16),
                
                // Service type selection
                Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  children: _serviceTypes.map((type) {
                    final isSelected = _serviceType == type;
                    final icon = _getServiceTypeIcon(type);
                    final color = _getServiceTypeColor(type);
                    
                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          _serviceType = type;
                        });
                      },
                      child: Container(
                        width: MediaQuery.of(context).size.width / 2 - 24,
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: isSelected ? color.withOpacity(0.1) : Colors.grey[100],
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: isSelected ? color : Colors.grey[300]!,
                            width: 2,
                          ),
                        ),
                        child: Column(
                          children: [
                            Icon(
                              icon,
                              color: isSelected ? color : Colors.grey,
                              size: 32,
                            ),
                            const SizedBox(height: 8),
                            Text(
                              _capitalizeFirstLetter(type),
                              style: TextStyle(
                                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                                color: isSelected ? color : Colors.black,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                ),
                
                const SizedBox(height: 24),
                
                // Schedule toggle
                SwitchListTile(
                  title: const Text('Schedule for Later'),
                  value: _isScheduled,
                  onChanged: (value) {
                    setState(() {
                      _isScheduled = value;
                      if (value && _scheduledTime == null) {
                        // Set default scheduled time to 1 hour from now
                        _scheduledTime = DateTime.now().add(const Duration(hours: 1));
                      }
                    });
                  },
                  activeColor: AppTheme.primaryColor,
                ),
                
                // Date time picker (if scheduled)
                if (_isScheduled) ...[
                  const SizedBox(height: 16),
                  ListTile(
                    title: const Text('Pickup Time'),
                    subtitle: Text(
                      _scheduledTime != null
                          ? '${_scheduledTime!.day}/${_scheduledTime!.month}/${_scheduledTime!.year} at ${_scheduledTime!.hour}:${_scheduledTime!.minute.toString().padLeft(2, '0')}'
                          : 'Select time',
                    ),
                    trailing: const Icon(Icons.calendar_today),
                    onTap: () async {
                      final date = await showDatePicker(
                        context: context,
                        initialDate: _scheduledTime ?? DateTime.now().add(const Duration(hours: 1)),
                        firstDate: DateTime.now(),
                        lastDate: DateTime.now().add(const Duration(days: 30)),
                      );
                      
                      if (date != null) {
                        final time = await showTimePicker(
                          context: context,
                          initialTime: TimeOfDay.fromDateTime(
                            _scheduledTime ?? DateTime.now().add(const Duration(hours: 1)),
                          ),
                        );
                        
                        if (time != null) {
                          setState(() {
                            _scheduledTime = DateTime(
                              date.year,
                              date.month,
                              date.day,
                              time.hour,
                              time.minute,
                            );
                          });
                        }
                      }
                    },
                  ),
                ],
              ],
            ),
            isActive: _currentStep >= 1,
            state: _currentStep > 1 ? StepState.complete : StepState.indexed,
          ),
          
          // Step 3: Provider & Confirmation
          Step(
            title: const Text('Provider & Confirmation'),
            content: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Select Provider',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 16),
                
                // Provider selection
                if (transportProvider.isLoading)
                  const Center(child: CircularProgressIndicator())
                else if (transportProvider.providers.isEmpty)
                  const Text('No providers available')
                else
                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: transportProvider.providers.length,
                    itemBuilder: (context, index) {
                      final provider = transportProvider.providers[index];
                      final isSelected = _selectedProviderId == provider['id'];
                      
                      // Only show providers that offer the selected service type
                      if (!provider['types'].contains(_serviceType)) {
                        return const SizedBox.shrink();
                      }
                      
                      return Card(
                        margin: const EdgeInsets.only(bottom: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                          side: BorderSide(
                            color: isSelected ? AppTheme.primaryColor : Colors.transparent,
                            width: 2,
                          ),
                        ),
                        child: InkWell(
                          onTap: () {
                            setState(() {
                              _selectedProviderId = provider['id'];
                            });
                          },
                          child: Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: Row(
                              children: [
                                CircleAvatar(
                                  radius: 24,
                                  backgroundColor: AppTheme.primaryLightColor,
                                  child: Text(
                                    provider['name'][0],
                                    style: const TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                      color: AppTheme.primaryColor,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 16),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
(Content truncated due to size limit. Use line ranges to read in chunks)