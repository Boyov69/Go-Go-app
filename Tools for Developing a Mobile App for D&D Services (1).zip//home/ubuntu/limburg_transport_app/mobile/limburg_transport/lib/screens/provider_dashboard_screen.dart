import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:limburg_transport/providers/auth_provider.dart';
import 'package:limburg_transport/providers/transport_provider.dart';
import 'package:limburg_transport/utils/theme.dart';
import 'package:limburg_transport/widgets/custom_button.dart';

class ProviderDashboardScreen extends StatefulWidget {
  const ProviderDashboardScreen({super.key});

  @override
  State<ProviderDashboardScreen> createState() => _ProviderDashboardScreenState();
}

class _ProviderDashboardScreenState extends State<ProviderDashboardScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _isLoading = true;
  Map<String, dynamic>? _providerData;
  List<Map<String, dynamic>> _activeRides = [];
  List<Map<String, dynamic>> _pendingRides = [];
  List<Map<String, dynamic>> _completedRides = [];
  List<Map<String, dynamic>> _vehicles = [];
  List<Map<String, dynamic>> _drivers = [];
  
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _fetchProviderData();
  }
  
  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }
  
  Future<void> _fetchProviderData() async {
    final transportProvider = Provider.of<TransportProvider>(context, listen: false);
    
    setState(() {
      _isLoading = true;
    });
    
    try {
      // Fetch provider data
      final providerData = await transportProvider.fetchProviderDetails();
      
      // Fetch rides
      final rides = await transportProvider.fetchProviderRides();
      
      // Fetch vehicles
      final vehicles = await transportProvider.fetchProviderVehicles();
      
      // Fetch drivers
      final drivers = await transportProvider.fetchProviderDrivers();
      
      // Sort rides by status
      final activeRides = rides.where((ride) => ride['status'] == 'in_progress').toList();
      final pendingRides = rides.where((ride) => ride['status'] == 'pending').toList();
      final completedRides = rides.where((ride) => ride['status'] == 'completed').toList();
      
      setState(() {
        _providerData = providerData;
        _activeRides = activeRides;
        _pendingRides = pendingRides;
        _completedRides = completedRides;
        _vehicles = vehicles;
        _drivers = drivers;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      
      // Show error message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to fetch provider data: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }
  
  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('Provider Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _fetchProviderData,
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              authProvider.logout();
              Navigator.pushReplacementNamed(context, '/login');
            },
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Overview'),
            Tab(text: 'Rides'),
            Tab(text: 'Vehicles'),
            Tab(text: 'Drivers'),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Show action menu based on current tab
          final currentTab = _tabController.index;
          
          switch (currentTab) {
            case 1: // Rides tab
              _showRideFilterOptions();
              break;
            case 2: // Vehicles tab
              Navigator.pushNamed(context, '/add-vehicle');
              break;
            case 3: // Drivers tab
              Navigator.pushNamed(context, '/add-driver');
              break;
            default:
              break;
          }
        },
        child: Icon(
          _getFloatingActionButtonIcon(_tabController.index),
        ),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _providerData == null
              ? const Center(child: Text('Provider data not found'))
              : TabBarView(
                  controller: _tabController,
                  children: [
                    // Overview tab
                    _buildOverviewTab(),
                    
                    // Rides tab
                    _buildRidesTab(),
                    
                    // Vehicles tab
                    _buildVehiclesTab(),
                    
                    // Drivers tab
                    _buildDriversTab(),
                  ],
                ),
    );
  }
  
  Widget _buildOverviewTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Provider info card
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      CircleAvatar(
                        radius: 30,
                        backgroundColor: AppTheme.primaryLightColor,
                        child: Text(
                          _providerData!['name'][0],
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: AppTheme.primaryColor,
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _providerData!['name'],
                              style: const TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Row(
                              children: [
                                const Icon(
                                  Icons.star,
                                  color: Colors.amber,
                                  size: 16,
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  '${_providerData!['rating']} (${_providerData!['reviewCount']} reviews)',
                                  style: TextStyle(
                                    color: Colors.grey[600],
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.edit),
                        onPressed: () {
                          Navigator.pushNamed(
                            context,
                            '/edit-provider-profile',
                          );
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  const Divider(),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _buildStatItem(
                        'Active Rides',
                        _activeRides.length.toString(),
                        Icons.directions_car,
                        Colors.green,
                      ),
                      _buildStatItem(
                        'Vehicles',
                        _vehicles.length.toString(),
                        Icons.local_taxi,
                        Colors.blue,
                      ),
                      _buildStatItem(
                        'Drivers',
                        _drivers.length.toString(),
                        Icons.person,
                        Colors.orange,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          
          const SizedBox(height: 24),
          
          // Earnings card
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Earnings',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _buildEarningsItem(
                        'Today',
                        '€${_calculateEarnings(1)}',
                        Colors.green,
                      ),
                      _buildEarningsItem(
                        'This Week',
                        '€${_calculateEarnings(7)}',
                        Colors.blue,
                      ),
                      _buildEarningsItem(
                        'This Month',
                        '€${_calculateEarnings(30)}',
                        Colors.purple,
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  CustomButton(
                    text: 'View Earnings Details',
                    onPressed: () {
                      Navigator.pushNamed(context, '/earnings-details');
                    },
                    width: double.infinity,
                    icon: Icons.bar_chart,
                  ),
                ],
              ),
            ),
          ),
          
          const SizedBox(height: 24),
          
          // Active rides
          const Text(
            'Active Rides',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          
          if (_activeRides.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Center(
                  child: Text('No active rides'),
                ),
              ),
            )
          else
            Column(
              children: _activeRides.map((ride) => _buildRideCard(ride)).toList(),
            ),
          
          const SizedBox(height: 24),
          
          // Pending rides
          const Text(
            'Pending Rides',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          
          if (_pendingRides.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Center(
                  child: Text('No pending rides'),
                ),
              ),
            )
          else
            Column(
              children: _pendingRides.map((ride) => _buildRideCard(ride)).toList(),
            ),
        ],
      ),
    );
  }
  
  Widget _buildRidesTab() {
    return DefaultTabController(
      length: 3,
      child: Column(
        children: [
          const TabBar(
            labelColor: AppTheme.primaryColor,
            tabs: [
              Tab(text: 'Active'),
              Tab(text: 'Pending'),
              Tab(text: 'Completed'),
            ],
          ),
          Expanded(
            child: TabBarView(
              children: [
                // Active rides tab
                _activeRides.isEmpty
                    ? const Center(child: Text('No active rides'))
                    : ListView.builder(
                        padding: const EdgeInsets.all(16),
                        itemCount: _activeRides.length,
                        itemBuilder: (context, index) {
                          return _buildRideCard(_activeRides[index]);
                        },
                      ),
                
                // Pending rides tab
                _pendingRides.isEmpty
                    ? const Center(child: Text('No pending rides'))
                    : ListView.builder(
                        padding: const EdgeInsets.all(16),
                        itemCount: _pendingRides.length,
                        itemBuilder: (context, index) {
                          return _buildRideCard(_pendingRides[index]);
                        },
                      ),
                
                // Completed rides tab
                _completedRides.isEmpty
                    ? const Center(child: Text('No completed rides'))
                    : ListView.builder(
                        padding: const EdgeInsets.all(16),
                        itemCount: _completedRides.length,
                        itemBuilder: (context, index) {
                          return _buildRideCard(_completedRides[index]);
                        },
                      ),
              ],
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildVehiclesTab() {
    return _vehicles.isEmpty
        ? Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text('No vehicles added yet'),
                const SizedBox(height: 16),
                CustomButton(
                  text: 'Add Vehicle',
                  onPressed: () {
                    Navigator.pushNamed(context, '/add-vehicle');
                  },
                  icon: Icons.add,
                ),
              ],
            ),
          )
        : ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: _vehicles.length,
            itemBuilder: (context, index) {
              final vehicle = _vehicles[index];
              
              return Card(
                margin: const EdgeInsets.only(bottom: 16),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 60,
                            height: 60,
                            decoration: BoxDecoration(
                              color: Colors.blue.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: const Icon(
                              Icons.directions_car,
                              color: Colors.blue,
                              size: 30,
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
            
(Content truncated due to size limit. Use line ranges to read in chunks)