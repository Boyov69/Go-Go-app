import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:limburg_transport/providers/payment_provider.dart';
import 'package:limburg_transport/providers/ride_provider.dart';
import 'package:limburg_transport/utils/theme.dart';
import 'package:limburg_transport/widgets/custom_button.dart';

class PaymentScreen extends StatefulWidget {
  final String rideId;
  
  const PaymentScreen({super.key, required this.rideId});

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  Map<String, dynamic>? _ride;
  String _selectedPaymentMethodId = '';
  bool _isLoading = true;
  
  @override
  void initState() {
    super.initState();
    _fetchData();
  }
  
  Future<void> _fetchData() async {
    final rideProvider = Provider.of<RideProvider>(context, listen: false);
    final paymentProvider = Provider.of<PaymentProvider>(context, listen: false);
    
    setState(() {
      _isLoading = true;
    });
    
    try {
      // Fetch ride details
      final rides = rideProvider.rides;
      final ride = rides.firstWhere((r) => r['id'] == widget.rideId);
      
      // Fetch payment methods
      await paymentProvider.fetchPaymentMethods();
      
      // Set default payment method
      final defaultMethod = paymentProvider.paymentMethods.firstWhere(
        (method) => method['isDefault'] == true,
        orElse: () => paymentProvider.paymentMethods.isNotEmpty 
            ? paymentProvider.paymentMethods.first 
            : {},
      );
      
      setState(() {
        _ride = ride;
        if (defaultMethod.isNotEmpty) {
          _selectedPaymentMethodId = defaultMethod['id'];
        }
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      
      // Show error message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to fetch data: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }
  
  Future<void> _processPayment() async {
    if (_ride == null || _selectedPaymentMethodId.isEmpty) return;
    
    final paymentProvider = Provider.of<PaymentProvider>(context, listen: false);
    
    try {
      await paymentProvider.processPayment(
        widget.rideId,
        _selectedPaymentMethodId,
        _ride!['price'],
      );
      
      if (!mounted) return;
      
      // Navigate to confirmation screen
      Navigator.pushReplacementNamed(
        context,
        '/payment-confirmation',
        arguments: widget.rideId,
      );
    } catch (e) {
      // Show error message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Payment failed: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }
  
  @override
  Widget build(BuildContext context) {
    final paymentProvider = Provider.of<PaymentProvider>(context);
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('Payment'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _ride == null
              ? const Center(child: Text('Ride not found'))
              : SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Ride summary
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Ride Summary',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 16),
                              _buildSummaryItem(
                                'From',
                                _ride!['pickup']['address'],
                                Icons.location_on,
                                Colors.green,
                              ),
                              const SizedBox(height: 12),
                              _buildSummaryItem(
                                'To',
                                _ride!['destination']['address'],
                                Icons.location_on,
                                Colors.red,
                              ),
                              const SizedBox(height: 12),
                              _buildSummaryItem(
                                'Service',
                                _capitalizeFirstLetter(_ride!['serviceType']),
                                _getServiceTypeIcon(_ride!['serviceType']),
                                _getServiceTypeColor(_ride!['serviceType']),
                              ),
                              const SizedBox(height: 12),
                              _buildSummaryItem(
                                'Provider',
                                _ride!['provider']['name'],
                                Icons.business,
                                Colors.blue,
                              ),
                              const Divider(height: 32),
                              _buildSummaryItem(
                                'Distance',
                                '${_ride!['distance']} km',
                                Icons.straighten,
                                Colors.purple,
                              ),
                              const SizedBox(height: 12),
                              _buildSummaryItem(
                                'Duration',
                                '${_ride!['duration']} min',
                                Icons.access_time,
                                Colors.orange,
                              ),
                            ],
                          ),
                        ),
                      ),
                      
                      const SizedBox(height: 24),
                      
                      // Payment details
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Payment Details',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 16),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text('Base fare'),
                                  Text('€${(_ride!['price'] * 0.7).toStringAsFixed(2)}'),
                                ],
                              ),
                              const SizedBox(height: 8),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text('Distance charge'),
                                  Text('€${(_ride!['price'] * 0.2).toStringAsFixed(2)}'),
                                ],
                              ),
                              const SizedBox(height: 8),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text('Service fee'),
                                  Text('€${(_ride!['price'] * 0.1).toStringAsFixed(2)}'),
                                ],
                              ),
                              const Divider(height: 24),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text(
                                    'Total',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 18,
                                    ),
                                  ),
                                  Text(
                                    '€${_ride!['price'].toStringAsFixed(2)}',
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 18,
                                      color: AppTheme.primaryColor,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                      
                      const SizedBox(height: 24),
                      
                      // Payment methods
                      const Text(
                        'Payment Method',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 16),
                      
                      if (paymentProvider.isLoading)
                        const Center(child: CircularProgressIndicator())
                      else if (paymentProvider.paymentMethods.isEmpty)
                        Card(
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              children: [
                                const Text('No payment methods available'),
                                const SizedBox(height: 12),
                                CustomButton(
                                  text: 'Add Payment Method',
                                  onPressed: () {
                                    Navigator.pushNamed(context, '/add-payment-method')
                                        .then((_) => _fetchData());
                                  },
                                  icon: Icons.add,
                                  width: double.infinity,
                                ),
                              ],
                            ),
                          ),
                        )
                      else
                        Column(
                          children: [
                            ...paymentProvider.paymentMethods.map((method) {
                              final isSelected = _selectedPaymentMethodId == method['id'];
                              
                              return Card(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8),
                                  side: BorderSide(
                                    color: isSelected ? AppTheme.primaryColor : Colors.transparent,
                                    width: 2,
                                  ),
                                ),
                                child: InkWell(
                                  onTap: () {
                                    setState(() {
                                      _selectedPaymentMethodId = method['id'];
                                    });
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.all(16),
                                    child: Row(
                                      children: [
                                        Container(
                                          width: 48,
                                          height: 30,
                                          decoration: BoxDecoration(
                                            color: _getCardColor(method['brand']),
                                            borderRadius: BorderRadius.circular(4),
                                          ),
                                          child: Center(
                                            child: Text(
                                              method['brand'],
                                              style: const TextStyle(
                                                color: Colors.white,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 12,
                                              ),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: 16),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                '${method['brand']} •••• ${method['last4']}',
                                                style: const TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                              Text(
                                                'Expires ${method['expiryMonth']}/${method['expiryYear']}',
                                                style: TextStyle(
                                                  color: Colors.grey[600],
                                                  fontSize: 14,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Radio<String>(
                                          value: method['id'],
                                          groupValue: _selectedPaymentMethodId,
                                          onChanged: (value) {
                                            setState(() {
                                              _selectedPaymentMethodId = value!;
                                            });
                                          },
                                          activeColor: AppTheme.primaryColor,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            }).toList(),
                            
                            const SizedBox(height: 16),
                            
                            TextButton.icon(
                              onPressed: () {
                                Navigator.pushNam
(Content truncated due to size limit. Use line ranges to read in chunks)