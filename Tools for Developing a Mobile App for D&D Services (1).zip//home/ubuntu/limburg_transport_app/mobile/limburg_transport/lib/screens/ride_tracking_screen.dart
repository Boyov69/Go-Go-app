import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:limburg_transport/providers/ride_provider.dart';
import 'package:limburg_transport/utils/theme.dart';
import 'package:limburg_transport/widgets/custom_button.dart';

class RideTrackingScreen extends StatefulWidget {
  final String rideId;
  
  const RideTrackingScreen({super.key, required this.rideId});

  @override
  State<RideTrackingScreen> createState() => _RideTrackingScreenState();
}

class _RideTrackingScreenState extends State<RideTrackingScreen> {
  Map<String, dynamic>? _ride;
  Timer? _timer;
  bool _isLoading = true;
  
  @override
  void initState() {
    super.initState();
    _fetchRideDetails();
    
    // Set up timer to refresh ride status every 10 seconds
    _timer = Timer.periodic(const Duration(seconds: 10), (timer) {
      _fetchRideDetails();
    });
  }
  
  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
  
  Future<void> _fetchRideDetails() async {
    final rideProvider = Provider.of<RideProvider>(context, listen: false);
    
    try {
      // In a real app, this would fetch the latest ride details from the server
      // For now, we'll just use the ride from the provider's list
      final rides = rideProvider.rides;
      final ride = rides.firstWhere((r) => r['id'] == widget.rideId);
      
      // Simulate ride status progression
      if (ride['status'] == 'pending' && !rideProvider.isLoading) {
        // After 20 seconds, change status to in_progress
        if (_ride != null && DateTime.now().difference(DateTime.parse(ride['startTime'])).inSeconds > 20) {
          ride['status'] = 'in_progress';
          ride['driver'] = {
            'id': '1',
            'name': 'Jan Janssen',
            'rating': 4.7,
            'phone': '+32 123 456 789',
          };
          ride['vehicle'] = {
            'id': '1',
            'model': 'Mercedes E-Class',
            'licensePlate': 'ABC-123',
            'color': 'Black',
          };
        }
      }
      
      setState(() {
        _ride = ride;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      
      // Show error message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to fetch ride details: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }
  
  void _cancelRide() async {
    final rideProvider = Provider.of<RideProvider>(context, listen: false);
    
    try {
      await rideProvider.cancelRide(widget.rideId);
      
      if (!mounted) return;
      
      Navigator.pushReplacementNamed(context, '/dashboard');
      
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Ride cancelled successfully'),
          backgroundColor: Colors.green,
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to cancel ride: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ride Tracking'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _ride == null
              ? const Center(child: Text('Ride not found'))
              : SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Map view (mock)
                      Container(
                        height: 250,
                        width: double.infinity,
                        color: Colors.grey[300],
                        child: Stack(
                          children: [
                            Center(
                              child: Icon(
                                Icons.map,
                                size: 80,
                                color: Colors.grey[400],
                              ),
                            ),
                            if (_ride!['status'] == 'in_progress')
                              Positioned(
                                bottom: 16,
                                left: 16,
                                right: 16,
                                child: Container(
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(8),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black.withOpacity(0.1),
                                        blurRadius: 4,
                                        offset: const Offset(0, 2),
                                      ),
                                    ],
                                  ),
                                  child: Row(
                                    children: [
                                      const Icon(
                                        Icons.access_time,
                                        color: AppTheme.primaryColor,
                                      ),
                                      const SizedBox(width: 8),
                                      const Text(
                                        'Estimated arrival:',
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      const SizedBox(width: 4),
                                      Text(
                                        '${_ride!['duration']} minutes',
                                        style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                          color: AppTheme.primaryColor,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),
                      
                      // Ride status
                      Container(
                        padding: const EdgeInsets.all(16),
                        color: AppTheme.primaryColor,
                        child: Row(
                          children: [
                            Icon(
                              _getStatusIcon(_ride!['status']),
                              color: Colors.white,
                            ),
                            const SizedBox(width: 12),
                            Text(
                              _getStatusText(_ride!['status']),
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      // Ride details
                      Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Ride Details',
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 16),
                            
                            // Pickup and destination
                            _buildDetailItem(
                              'Pickup',
                              _ride!['pickup']['address'],
                              Icons.location_on,
                              Colors.green,
                            ),
                            const SizedBox(height: 12),
                            _buildDetailItem(
                              'Destination',
                              _ride!['destination']['address'],
                              Icons.location_on,
                              Colors.red,
                            ),
                            const SizedBox(height: 12),
                            _buildDetailItem(
                              'Service Type',
                              _capitalizeFirstLetter(_ride!['serviceType']),
                              _getServiceTypeIcon(_ride!['serviceType']),
                              _getServiceTypeColor(_ride!['serviceType']),
                            ),
                            const SizedBox(height: 12),
                            _buildDetailItem(
                              'Price',
                              '€${_ride!['price'].toStringAsFixed(2)}',
                              Icons.euro,
                              Colors.blue,
                            ),
                            
                            const Divider(height: 32),
                            
                            // Provider details
                            const Text(
                              'Provider',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 12),
                            _buildProviderCard(_ride!['provider']),
                            
                            if (_ride!['driver'] != null) ...[
                              const SizedBox(height: 24),
                              
                              // Driver details
                              const Text(
                                'Driver',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 12),
                              _buildDriverCard(_ride!['driver']),
                            ],
                            
                            if (_ride!['vehicle'] != null) ...[
                              const SizedBox(height: 24),
                              
                              // Vehicle details
                              const Text(
                                'Vehicle',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 12),
                              _buildVehicleCard(_ride!['vehicle']),
                            ],
                            
                            const SizedBox(height: 32),
                            
                            // Action buttons
                            if (_ride!['status'] == 'pending' || _ride!['status'] == 'in_progress')
                              Column(
                                children: [
                                  CustomButton(
                                    text: 'Contact Driver',
                                    onPressed: () {
                                      // In a real app, this would open the phone dialer
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        const SnackBar(
                                          content: Text('Calling driver...'),
                                        ),
                                      );
                                    },
                                    icon: Icons.phone,
                                    width: double.infinity,
                                  ),
                                  const SizedBox(height: 12),
                                  CustomButton(
                                    text: 'Cancel Ride',
                                    onPressed: _cancelRide,
                                    icon: Icons.cancel,
                                    width: double.infinity,
                                    color: Colors.red,
                                  ),
                                ],
                              )
                            else if (_ride!['status'] == 'completed' && _ride!['rating'] == null)
                              CustomButton(
                                text: 'Rate Ride',
                                onPressed: () {
                                  Navigator.pushNamed(
                                    context,
                                    '/rate-ride',
                                    arguments: widget.rideId,
                                  );
                                },
                                icon: Icons.star,
                                width: double.infinity,
                              ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
    );
  }
  
  Widget _buildDetailItem(String label, String value, IconData icon, Color color) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(
            icon,
            color: color,
            size: 20,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: TextStyle(
                  color: Colors.grey[600],
                  fontSize: 14,
                ),
              ),
              Text(
                value,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
  
  Widget _buildProviderCard(Map<String, dynamic> provider) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            CircleAvatar(
              radius: 24,
              backgroundColor: AppTheme.primaryLightColor,
              child: Text(
                provider['name'][0],
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: AppTheme.primaryColor,
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    provider['name'],
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
             
(Content truncated due to size limit. Use line ranges to read in chunks)