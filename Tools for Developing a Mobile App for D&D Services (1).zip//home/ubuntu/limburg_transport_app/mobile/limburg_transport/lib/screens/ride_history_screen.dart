import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:limburg_transport/providers/ride_provider.dart';
import 'package:limburg_transport/utils/theme.dart';
import 'package:limburg_transport/widgets/custom_button.dart';

class RideHistoryScreen extends StatefulWidget {
  const RideHistoryScreen({super.key});

  @override
  State<RideHistoryScreen> createState() => _RideHistoryScreenState();
}

class _RideHistoryScreenState extends State<RideHistoryScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _isLoading = true;
  List<Map<String, dynamic>> _completedRides = [];
  List<Map<String, dynamic>> _cancelledRides = [];
  String _filterPeriod = 'All Time';
  
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _fetchRideHistory();
  }
  
  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }
  
  Future<void> _fetchRideHistory() async {
    setState(() {
      _isLoading = true;
    });
    
    try {
      final rideProvider = Provider.of<RideProvider>(context, listen: false);
      final rides = await rideProvider.fetchRideHistory();
      
      // Filter rides by status
      final completedRides = rides.where((ride) => ride['status'] == 'completed').toList();
      final cancelledRides = rides.where((ride) => ride['status'] == 'cancelled').toList();
      
      setState(() {
        _completedRides = completedRides;
        _cancelledRides = cancelledRides;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to load ride history: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }
  
  List<Map<String, dynamic>> _getFilteredRides(List<Map<String, dynamic>> rides) {
    if (_filterPeriod == 'All Time') {
      return rides;
    }
    
    final now = DateTime.now();
    DateTime startDate;
    
    switch (_filterPeriod) {
      case 'Last 7 Days':
        startDate = now.subtract(const Duration(days: 7));
        break;
      case 'Last 30 Days':
        startDate = now.subtract(const Duration(days: 30));
        break;
      case 'Last 90 Days':
        startDate = now.subtract(const Duration(days: 90));
        break;
      default:
        return rides;
    }
    
    return rides.where((ride) {
      final rideDate = DateTime.parse(ride['completedAt'] ?? ride['cancelledAt'] ?? ride['createdAt']);
      return rideDate.isAfter(startDate);
    }).toList();
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ride History'),
        actions: [
          IconButton(
            icon: const Icon(Icons.filter_list),
            onPressed: _showFilterOptions,
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Completed'),
            Tab(text: 'Cancelled'),
          ],
        ),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                // Filter indicator
                if (_filterPeriod != 'All Time')
                  Container(
                    padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                    color: AppTheme.primaryLightColor.withOpacity(0.1),
                    child: Row(
                      children: [
                        const Icon(
                          Icons.filter_list,
                          size: 16,
                          color: AppTheme.primaryColor,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'Filtered by: $_filterPeriod',
                          style: const TextStyle(
                            color: AppTheme.primaryColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const Spacer(),
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              _filterPeriod = 'All Time';
                            });
                          },
                          child: const Text(
                            'Clear',
                            style: TextStyle(
                              color: AppTheme.primaryColor,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                
                Expanded(
                  child: TabBarView(
                    controller: _tabController,
                    children: [
                      // Completed rides tab
                      _buildRidesList(_getFilteredRides(_completedRides), 'completed'),
                      
                      // Cancelled rides tab
                      _buildRidesList(_getFilteredRides(_cancelledRides), 'cancelled'),
                    ],
                  ),
                ),
              ],
            ),
    );
  }
  
  Widget _buildRidesList(List<Map<String, dynamic>> rides, String type) {
    if (rides.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              type == 'completed' ? Icons.check_circle : Icons.cancel,
              size: 64,
              color: Colors.grey[400],
            ),
            const SizedBox(height: 16),
            Text(
              'No ${type == 'completed' ? 'completed' : 'cancelled'} rides',
              style: TextStyle(
                fontSize: 18,
                color: Colors.grey[600],
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Your ${type == 'completed' ? 'completed' : 'cancelled'} rides will appear here',
              style: TextStyle(
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      );
    }
    
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: rides.length,
      itemBuilder: (context, index) {
        return _buildRideCard(rides[index], type);
      },
    );
  }
  
  Widget _buildRideCard(Map<String, dynamic> ride, String type) {
    final statusColor = type == 'completed' ? Colors.green : Colors.red;
    final dateTime = DateTime.parse(
      type == 'completed' ? ride['completedAt'] : ride['cancelledAt'] ?? ride['createdAt'],
    );
    
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: InkWell(
        onTap: () {
          Navigator.pushNamed(
            context,
            '/ride-details',
            arguments: ride['id'],
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: statusColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Text(
                      type == 'completed' ? 'Completed' : 'Cancelled',
                      style: TextStyle(
                        color: statusColor,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                    ),
                  ),
                  const Spacer(),
                  Text(
                    '€${ride['price'].toStringAsFixed(2)}',
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: AppTheme.primaryColor,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  const Icon(
                    Icons.access_time,
                    size: 16,
                    color: Colors.grey,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    _formatDateTime(dateTime),
                    style: TextStyle(
                      color: Colors.grey[600],
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    children: [
                      const Icon(
                        Icons.circle,
                        size: 12,
                        color: Colors.green,
                      ),
                      Container(
                        width: 1,
                        height: 30,
                        color: Colors.grey[300],
                      ),
                      const Icon(
                        Icons.circle,
                        size: 12,
                        color: Colors.red,
                      ),
                    ],
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          ride['pickup']['address'],
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 20),
                        Text(
                          ride['destination']['address'],
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      CircleAvatar(
                        radius: 16,
                        backgroundColor: Colors.grey[200],
                        backgroundImage: ride['provider']['logo'] != null
                            ? NetworkImage(ride['provider']['logo'])
                            : null,
                        child: ride['provider']['logo'] == null
                            ? Text(
                                ride['provider']['name'][0],
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                ),
                              )
                            : null,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        ride['provider']['name'],
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      const Icon(
                        Icons.straighten,
                        size: 16,
                        color: Colors.grey,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        '${ride['distance']} km',
                        style: TextStyle(
                          color: Colors.grey[600],
                          fontSize: 14,
                        ),
                      ),
                      const SizedBox(width: 8),
                      const Icon(
                        Icons.timer,
                        size: 16,
                        color: Colors.grey,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        '${ride['duration']} min',
                        style: TextStyle(
                          color: Colors.grey[600],
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 16),
              const Divider(),
              const SizedBox(height: 8),
              Row(
                children: [
                  if (type == 'completed')
                    Expanded(
                      child: CustomButton(
                        text: 'View Receipt',
                        onPressed: () {
                          Navigator.pushNamed(
                            context,
                            '/receipt',
                            arguments: ride['id'],
                          );
                        },
                        icon: Icons.receipt,
                      ),
                    ),
                  if (type == 'completed') const SizedBox(width: 12),
                  Expanded(
                    child: CustomButton(
                      text: type == 'completed' ? 'Rate Ride' : 'Book Again',
                      onPressed: () {
                        if (type == 'completed') {
                          Navigator.pushNamed(
                            context,
                            '/rate-ride',
                            arguments: ride['id'],
                          );
                        } else {
                          Navigator.pushNamed(
                            context,
                            '/book-ride',
                            arguments: {
                              'pickup': ride['pickup'],
                              'destination': ride['destination'],
                            },
                          );
                        }
                      },
                      icon: type == 'completed' ? Icons.star : Icons.refresh,
                      color: type == 'completed' ? Colors.amber : AppTheme.primaryColor,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
  
  void _showFilterOptions() {
    final filterOptions = ['All Time', 'Last 7 Days', 'Last 30 Days', 'Last 90 Days'];
    
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Filter by Period',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              ...filterOptions.map(
                (option) => ListTile(
                  title: Tex
(Content truncated due to size limit. Use line ranges to read in chunks)