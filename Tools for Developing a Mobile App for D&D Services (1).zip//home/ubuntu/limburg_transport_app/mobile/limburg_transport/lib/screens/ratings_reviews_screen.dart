import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:limburg_transport/providers/ride_provider.dart';
import 'package:limburg_transport/utils/theme.dart';
import 'package:limburg_transport/widgets/custom_button.dart';

class RatingsReviewsScreen extends StatefulWidget {
  const RatingsReviewsScreen({super.key});

  @override
  State<RatingsReviewsScreen> createState() => _RatingsReviewsScreenState();
}

class _RatingsReviewsScreenState extends State<RatingsReviewsScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _isLoading = true;
  List<Map<String, dynamic>> _myReviews = [];
  List<Map<String, dynamic>> _pendingReviews = [];
  
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _fetchReviews();
  }
  
  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }
  
  Future<void> _fetchReviews() async {
    setState(() {
      _isLoading = true;
    });
    
    try {
      final rideProvider = Provider.of<RideProvider>(context, listen: false);
      final myReviews = await rideProvider.fetchMyReviews();
      final pendingReviews = await rideProvider.fetchPendingReviews();
      
      setState(() {
        _myReviews = myReviews;
        _pendingReviews = pendingReviews;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to load reviews: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ratings & Reviews'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'My Reviews'),
            Tab(text: 'Pending Reviews'),
          ],
        ),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : TabBarView(
              controller: _tabController,
              children: [
                // My Reviews tab
                _buildMyReviewsList(),
                
                // Pending Reviews tab
                _buildPendingReviewsList(),
              ],
            ),
    );
  }
  
  Widget _buildMyReviewsList() {
    if (_myReviews.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.rate_review,
              size: 64,
              color: Colors.grey[400],
            ),
            const SizedBox(height: 16),
            Text(
              'No reviews yet',
              style: TextStyle(
                fontSize: 18,
                color: Colors.grey[600],
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Your reviews will appear here',
              style: TextStyle(
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      );
    }
    
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _myReviews.length,
      itemBuilder: (context, index) {
        return _buildReviewCard(_myReviews[index], false);
      },
    );
  }
  
  Widget _buildPendingReviewsList() {
    if (_pendingReviews.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.thumb_up,
              size: 64,
              color: Colors.grey[400],
            ),
            const SizedBox(height: 16),
            Text(
              'No pending reviews',
              style: TextStyle(
                fontSize: 18,
                color: Colors.grey[600],
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'You\'ve reviewed all your rides',
              style: TextStyle(
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      );
    }
    
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _pendingReviews.length,
      itemBuilder: (context, index) {
        return _buildReviewCard(_pendingReviews[index], true);
      },
    );
  }
  
  Widget _buildReviewCard(Map<String, dynamic> review, bool isPending) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 24,
                  backgroundColor: Colors.grey[200],
                  backgroundImage: review['provider']['logo'] != null
                      ? NetworkImage(review['provider']['logo'])
                      : null,
                  child: review['provider']['logo'] == null
                      ? Text(
                          review['provider']['name'][0],
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                          ),
                        )
                      : null,
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        review['provider']['name'],
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        _formatDateTime(DateTime.parse(review['date'])),
                        style: TextStyle(
                          color: Colors.grey[600],
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
                if (!isPending)
                  Row(
                    children: [
                      const Icon(
                        Icons.star,
                        color: Colors.amber,
                        size: 20,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        review['rating'].toString(),
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                    ],
                  ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Column(
                  children: [
                    const Icon(
                      Icons.circle,
                      size: 12,
                      color: Colors.green,
                    ),
                    Container(
                      width: 1,
                      height: 30,
                      color: Colors.grey[300],
                    ),
                    const Icon(
                      Icons.circle,
                      size: 12,
                      color: Colors.red,
                    ),
                  ],
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        review['pickup'],
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 20),
                      Text(
                        review['destination'],
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              ],
            ),
            if (!isPending) ...[
              const SizedBox(height: 16),
              const Divider(),
              const SizedBox(height: 8),
              if (review['comment'] != null && review['comment'].isNotEmpty)
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Your Review:',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(review['comment']),
                    const SizedBox(height: 16),
                  ],
                ),
              Row(
                children: [
                  _buildRatingItem('Driver', review['driverRating']),
                  const SizedBox(width: 16),
                  _buildRatingItem('Vehicle', review['vehicleRating']),
                  const SizedBox(width: 16),
                  _buildRatingItem('Service', review['serviceRating']),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: CustomButton(
                      text: 'Edit Review',
                      onPressed: () {
                        Navigator.pushNamed(
                          context,
                          '/edit-review',
                          arguments: review['id'],
                        ).then((_) => _fetchReviews());
                      },
                      icon: Icons.edit,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: CustomButton(
                      text: 'Delete',
                      onPressed: () {
                        _showDeleteConfirmation(review['id']);
                      },
                      icon: Icons.delete,
                      color: Colors.red,
                    ),
                  ),
                ],
              ),
            ] else ...[
              const SizedBox(height: 16),
              CustomButton(
                text: 'Rate this Ride',
                onPressed: () {
                  Navigator.pushNamed(
                    context,
                    '/rate-ride',
                    arguments: review['rideId'],
                  ).then((_) => _fetchReviews());
                },
                icon: Icons.star,
                width: double.infinity,
                color: Colors.amber,
              ),
            ],
          ],
        ),
      ),
    );
  }
  
  Widget _buildRatingItem(String label, double rating) {
    return Expanded(
      child: Column(
        children: [
          Text(
            label,
            style: TextStyle(
              color: Colors.grey[600],
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.star,
                color: Colors.amber,
                size: 16,
              ),
              const SizedBox(width: 4),
              Text(
                rating.toString(),
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
  
  void _showDeleteConfirmation(String reviewId) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Delete Review'),
          content: const Text(
            'Are you sure you want to delete this review? This action cannot be undone.',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                _deleteReview(reviewId);
              },
              child: const Text(
                'Delete',
                style: TextStyle(color: Colors.red),
              ),
            ),
          ],
        );
      },
    );
  }
  
  Future<void> _deleteReview(String reviewId) async {
    setState(() {
      _isLoading = true;
    });
    
    try {
      final rideProvider = Provider.of<RideProvider>(context, listen: false);
      await rideProvider.deleteReview(reviewId);
      
      setState(() {
        _myReviews = _myReviews.where((review) => review['id'] != reviewId).toList();
        _isLoading = false;
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Review deleted successfully'),
          backgroundColor: Colors.green,
        ),
      );
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to delete review: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }
  
  String _formatDateTime(DateTime dateTime) {
    final now = DateTime.now();
    
    if (dateTime.year == now.year && dateTime.month == now.month && dateTime.day == now.day) {
      // Today, show time only
      return 'Today, ${dateTime.hour}:${dateTime.minute.toString().padLeft(2, '0')}';
    } else if (dateTime.year == now.year && dateTime.month == now.month && dateTime.day == now.day - 1) {
      // Yesterday, show "Yesterday" and time
      return 'Yesterday, ${dateTime.hour}:${dateTime.minute.toString().padLeft(2, '0')}';
    } else {
      // Other days, show date and time
      return '${dateTime.day}/${dateTime.month}/${dateTime.year}, ${dateTime.hour}:${dateTime.minute.toString().padLeft(2, '0')}';
    }
  }
}

class RateRideScreen extends StatefulWidget {
  final String rideId;
  
  const RateRideScreen({super.key, required this.rideId});
  
  @override
  State<RateRideScreen> createState() => _RateRideScreenState();
}

class _RateRideScreenState extends State<RateRideScreen> {
  bool _isLoading = true;
  Map<String, dynamic>? _rideDetails;
  
  // Rating values
  double _overallRating = 5.0;
  double _driverRating = 5.0;
  double _vehicleRating = 5.0;
  double _serviceRating = 5.0;
  
  // Comment
  final _commentController = TextEditingController();
  
  // Selected tags
  final List<String> _availableTags = [
    'Punctual',
    'Clean Vehicle',
    'Professional',
    'Safe Driving',
    'Friendly',
    'Helpful',
    'Comfortable',
    'Good Communication',
  ];
  final List<String> _selectedTags = [];
  
  @override
  void initState() {
    super.initState();
    _fetchRideDetails();
  }
  
  @override
  void dispose() {
    _commentController.dispose();
    super.dispose();
  }
  
  Future<void> _fetchRideDetails() async {
    setState(() {
      _isLoading = true;
    });
    
    try {
      final rideProvider = Provider.of<RideProvider>(context, listen: false);
      final rideDetails =
(Content truncated due to size limit. Use line ranges to read in chunks)