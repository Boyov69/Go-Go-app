# Application Architecture and Database Design for Limburg Transportation Marketplace

## System Architecture Overview

The Limburg Transportation Marketplace application follows a microservices architecture to ensure scalability, maintainability, and flexibility. This document outlines the high-level architecture, component interactions, and database design.

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────┐
│                        Client Applications                           │
│                                                                     │
│  ┌───────────────┐  ┌───────────────┐  ┌───────────────────────┐   │
│  │ Flutter Mobile │  │ Provider Web  │  │ Admin Dashboard (Web) │   │
│  │  Application   │  │  Application  │  │                       │   │
│  └───────┬───────┘  └───────┬───────┘  └───────────┬───────────┘   │
└──────────┼───────────────────┼─────────────────────┼───────────────┘
           │                   │                     │
           ▼                   ▼                     ▼
┌─────────────────────────────────────────────────────────────────────┐
│                          API Gateway                                 │
│                       (AWS API Gateway)                              │
└─────────────┬─────────────────┬────────────────────┬────────────────┘
              │                 │                    │
    ┌─────────┼─────────┐      │                    │
    │         │         │      │                    │
    ▼         ▼         ▼      ▼                    ▼
┌─────────┐ ┌─────┐ ┌───────┐ ┌──────────┐ ┌────────────────┐
│  Auth   │ │User │ │Provider│ │  Ride    │ │   Payment      │
│ Service │ │Service│ │Service│ │ Service  │ │   Service     │
└────┬────┘ └──┬───┘ └───┬───┘ └────┬─────┘ └────────┬───────┘
     │         │         │          │                │
     │         │         │          │                │
     ▼         ▼         ▼          ▼                ▼
┌─────────────────────────────────────────────────────────────────────┐
│                        Message Broker                                │
│                       (AWS SQS/Redis)                                │
└─────────────────────────────────────────────────────────────────────┘
     │         │         │          │                │
     │         │         │          │                │
     ▼         ▼         ▼          ▼                ▼
┌─────────┐ ┌─────┐ ┌───────┐ ┌──────────┐ ┌────────────────┐
│Notification│ │Analytics│ │Reporting│ │ Mapping  │ │   Admin       │
│ Service │ │Service│ │Service│ │ Service  │ │   Service     │
└─────────┘ └─────┘ └───────┘ └──────────┘ └────────────────┘
     │         │         │          │                │
     │         │         │          │                │
     ▼         ▼         ▼          ▼                ▼
┌─────────────────────────────────────────────────────────────────────┐
│                        Data Layer                                    │
│                                                                     │
│  ┌───────────────┐  ┌───────────────┐  ┌───────────────────────┐   │
│  │    MongoDB    │  │   PostgreSQL  │  │        Redis          │   │
│  │  (Document DB)│  │  (Relational) │  │      (Cache)          │   │
│  └───────────────┘  └───────────────┘  └───────────────────────┘   │
└─────────────────────────────────────────────────────────────────────┘
```

## Microservices Architecture

### 1. API Gateway
- **Technology**: AWS API Gateway
- **Responsibilities**:
  - Route requests to appropriate microservices
  - Handle authentication and authorization
  - Rate limiting and throttling
  - Request validation
  - API documentation (Swagger/OpenAPI)

### 2. Auth Service
- **Technology**: Node.js, JWT, Auth0
- **Responsibilities**:
  - User authentication and authorization
  - Token management
  - Role-based access control
  - Social login integration
  - Multi-factor authentication

### 3. User Service
- **Technology**: Node.js, Express, MongoDB
- **Responsibilities**:
  - User profile management
  - User preferences
  - Ride history
  - Saved locations
  - Rating and review management

### 4. Provider Service
- **Technology**: Node.js, Express, MongoDB
- **Responsibilities**:
  - Provider registration and onboarding
  - Provider profile management
  - Vehicle management
  - Driver management
  - Service area management
  - Availability scheduling

### 5. Ride Service
- **Technology**: Node.js, Express, MongoDB, Redis
- **Responsibilities**:
  - Ride booking and management
  - Ride matching algorithm
  - Fare calculation
  - Route optimization
  - Real-time ride tracking
  - Ride status updates

### 6. Payment Service
- **Technology**: Node.js, Express, PostgreSQL, Stripe/Adyen
- **Responsibilities**:
  - Payment processing
  - Transaction management
  - Refund handling
  - Payment method management
  - Financial reporting
  - Commission calculation

### 7. Notification Service
- **Technology**: Node.js, Firebase Cloud Messaging, Twilio, SendGrid
- **Responsibilities**:
  - Push notifications
  - SMS notifications
  - Email notifications
  - In-app notifications
  - Notification preferences

### 8. Analytics Service
- **Technology**: Node.js, MongoDB, AWS Kinesis
- **Responsibilities**:
  - User behavior tracking
  - Performance metrics
  - Business intelligence
  - Data visualization
  - Reporting

### 9. Reporting Service
- **Technology**: Node.js, PostgreSQL
- **Responsibilities**:
  - Financial reporting
  - Operational reporting
  - Regulatory compliance reporting
  - Data export

### 10. Mapping Service
- **Technology**: Node.js, MongoDB, Google Maps API
- **Responsibilities**:
  - Geocoding
  - Reverse geocoding
  - Route calculation
  - ETA prediction
  - Traffic information

### 11. Admin Service
- **Technology**: Node.js, Express, MongoDB
- **Responsibilities**:
  - System configuration
  - User management
  - Provider management
  - Content management
  - System monitoring

## Database Design

### MongoDB Collections (Document Database)

#### 1. Users Collection
```json
{
  "_id": "ObjectId",
  "email": "string",
  "phone": "string",
  "firstName": "string",
  "lastName": "string",
  "profilePicture": "string",
  "authProvider": "string",
  "authProviderId": "string",
  "role": "string",
  "status": "string",
  "createdAt": "date",
  "updatedAt": "date",
  "lastLoginAt": "date",
  "preferences": {
    "language": "string",
    "currency": "string",
    "notifications": {
      "push": "boolean",
      "email": "boolean",
      "sms": "boolean"
    },
    "paymentMethods": [
      {
        "id": "string",
        "type": "string",
        "lastFour": "string",
        "isDefault": "boolean"
      }
    ]
  },
  "savedLocations": [
    {
      "id": "string",
      "name": "string",
      "address": "string",
      "coordinates": {
        "latitude": "number",
        "longitude": "number"
      },
      "type": "string"
    }
  ],
  "ratingAverage": "number",
  "ratingCount": "number"
}
```

#### 2. Providers Collection
```json
{
  "_id": "ObjectId",
  "companyName": "string",
  "businessType": "string",
  "email": "string",
  "phone": "string",
  "address": {
    "street": "string",
    "city": "string",
    "state": "string",
    "postalCode": "string",
    "country": "string"
  },
  "coordinates": {
    "latitude": "number",
    "longitude": "number"
  },
  "contactPerson": {
    "firstName": "string",
    "lastName": "string",
    "email": "string",
    "phone": "string"
  },
  "logo": "string",
  "description": "string",
  "website": "string",
  "licenseNumber": "string",
  "taxIdentifier": "string",
  "serviceTypes": ["string"],
  "serviceAreas": [
    {
      "name": "string",
      "coordinates": [
        {
          "latitude": "number",
          "longitude": "number"
        }
      ]
    }
  ],
  "commissionRate": "number",
  "status": "string",
  "verificationStatus": "string",
  "documents": [
    {
      "type": "string",
      "url": "string",
      "verificationStatus": "string",
      "expiryDate": "date"
    }
  ],
  "bankInformation": {
    "accountHolder": "string",
    "accountNumber": "string",
    "bankName": "string",
    "iban": "string",
    "swiftCode": "string"
  },
  "createdAt": "date",
  "updatedAt": "date",
  "ratingAverage": "number",
  "ratingCount": "number"
}
```

#### 3. Drivers Collection
```json
{
  "_id": "ObjectId",
  "providerId": "ObjectId",
  "userId": "ObjectId",
  "firstName": "string",
  "lastName": "string",
  "email": "string",
  "phone": "string",
  "profilePicture": "string",
  "address": {
    "street": "string",
    "city": "string",
    "state": "string",
    "postalCode": "string",
    "country": "string"
  },
  "dateOfBirth": "date",
  "licenseNumber": "string",
  "licenseExpiryDate": "date",
  "documents": [
    {
      "type": "string",
      "url": "string",
      "verificationStatus": "string",
      "expiryDate": "date"
    }
  ],
  "status": "string",
  "verificationStatus": "string",
  "currentLocation": {
    "latitude": "number",
    "longitude": "number",
    "updatedAt": "date"
  },
  "currentVehicleId": "ObjectId",
  "isAvailable": "boolean",
  "createdAt": "date",
  "updatedAt": "date",
  "ratingAverage": "number",
  "ratingCount": "number"
}
```

#### 4. Vehicles Collection
```json
{
  "_id": "ObjectId",
  "providerId": "ObjectId",
  "make": "string",
  "model": "string",
  "year": "number",
  "color": "string",
  "licensePlate": "string",
  "registrationNumber": "string",
  "vehicleType": "string",
  "capacity": "number",
  "features": ["string"],
  "photos": ["string"],
  "documents": [
    {
      "type": "string",
      "url": "string",
      "verificationStatus": "string",
      "expiryDate": "date"
    }
  ],
  "status": "string",
  "verificationStatus": "string",
  "isAccessible": "boolean",
  "isElectric": "boolean",
  "currentDriverId": "ObjectId",
  "createdAt": "date",
  "updatedAt": "date"
}
```

#### 5. Rides Collection
```json
{
  "_id": "ObjectId",
  "userId": "ObjectId",
  "providerId": "ObjectId",
  "driverId": "ObjectId",
  "vehicleId": "ObjectId",
  "rideType": "string",
  "status": "string",
  "pickup": {
    "address": "string",
    "coordinates": {
      "latitude": "number",
      "longitude": "number"
    },
    "instructions": "string"
  },
  "dropoff": {
    "address": "string",
    "coordinates": {
      "latitude": "number",
      "longitude": "number"
    },
    "instructions": "string"
  },
  "stops": [
    {
      "address": "string",
      "coordinates": {
        "latitude": "number",
        "longitude": "number"
      },
      "instructions": "string"
    }
  ],
  "route": {
    "distance": "number",
    "duration": "number",
    "polyline": "string"
  },
  "pricing": {
    "baseFare": "number",
    "distanceFare": "number",
    "timeFare": "number",
    "surgeMultiplier": "number",
    "taxes": "number",
    "fees": "number",
    "total": "number",
    "currency": "string"
  },
  "paymentId": "string",
  "paymentStatus": "string",
  "paymentMethod": "string",
  "scheduledTime": "date",
  "requestedAt": "date",
  "acceptedAt": "date",
  "arrivedAt": "date",
  "startedAt": "date",
  "completedAt": "date",
  "cancelledAt": "date",
  "cancellationReason": "string",
  "cancellationFee": "number",
  "rating": {
    "userToDriver": "number",
    "driverToUser": "number",
    "userComment": "string",
    "driverComment": "string"
  },
  "createdAt": "date",
  "updatedAt": "date"
}
```

### PostgreSQL Tables (Relational Database)

#### 1. Transactions Table
```sql
CREATE TABLE transactions (
    id SERIAL PRIMARY KEY,
    ride_id VARCHAR(255),
    user_id VARCHAR(255),
    provider_id VARCHAR(255),
    payment_method_id VARCHAR(255),
    payment_intent_id VARCHAR(255),
    amount DECIMAL(10, 2),
    currency VARCHAR(3),
    status VARCHAR(50),
    type VARCHAR(50),
    commission_amount DECIMAL(10, 2),
    provider_amount DECIMAL(10, 2),
    tax_amount DECIMAL(10, 2),
    refunded_amount DECIMAL(10, 2),
    refund_reason TEXT,
    metadata JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 2. Payment Methods Table
```sql
CREATE TABLE payment_methods (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(255),
    payment_provider VARCHAR(50),
    payment_token VARCHAR(255),
    card_type VARCHAR(50),
    last_four VARCHAR(4),
    expiry_month INTEGER,
    expiry_year INTEGER,
    is_default BOOLEAN DEFAULT FALSE,
    status VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 3. Financial Reports Table
```sql
CREATE TABLE financial_reports (
    id SERIAL PRIMARY KEY,
    provider_id VARCHAR(255),
    report_type VARCHAR(50),
    period_start DATE,
    period_end DATE,
    total_rides INTEGER,
    total_revenue DECIMAL(10, 2),
    total_commission DECIMAL(10, 2),
    total_provider_amount DECIMAL(10, 2),
    total_tax_amount DECIMAL(10, 2),
    currency VARCHAR(3),
    status VARCHAR(50),
    report_url VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 4. Regulatory Reports Table
```sql
CREATE TABLE regulatory_reports (
    id SERIAL PRIMARY KEY,
    report_type VARCHAR(50),
    period_start DATE,
    period_end DATE,
    total_rides INTEGER,
    total_providers INTEGER,
    total_drivers INTEGER,
    total_revenue DECIMAL(10, 2),
    total_tax_amount DECIMAL(10, 2),
    currency VARCHAR(3),
    status VARCHAR(50),
    report_url VARCHAR(255),
    submitted_to VARCHAR(255),
    submission_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Redis Cache (Key-Value Store)

#### 1. User Sessions
- Key: `session:{sessionId}`
- Value: User session data (JSON)
- TTL: 24 hours

#### 2. Driver Locations
- Key: `driver:location:{driverId}`
- Value: `{latitude}:{longitude}:{timestamp}`
- TTL: 1 minute

#### 3. Available Drivers
- Key: `available:drivers:{serviceType}:{geohash}`
- Value: Set of driver IDs
- TTL: 1 minute

#### 4. Ride Status
- Key: `ride:status:{rideId}`
- Value: Current ride status
- TTL: 24 hours

#### 5. Rate Limiting
- Key: `ratelimit:{userId}:{endpoint}`
- Value: Count of requests
- TTL: Varies by endpoint

## API Endpoints

### Authentication API
- `POST /api/auth/register` - Register a new user
- `POST /api/auth/login` - User login
- `POST /api/auth/refresh-token` - Refresh authentication token
- `POST /api/auth/forgot-password` - Initiate password reset
- `POST /api/auth/reset-password` - Complete password reset
- `GET /api/auth/me` - Get current user information

### User API
- `GET /api/users/profile` - Get user profile
- `PUT /api/users/profile` - Update user profile
- `GET /api/users/rides` - Get user ride history
- `GET /api/users/payment-methods` - Get user payment methods
- `POST /api/users/payment-methods` - Add payment method
- `DELETE /api/users/payment-methods/{id}` - Remove payment method
- `GET /api/users/saved-locations` - Get saved locations
- `POST /api/users/saved-locations` - Add saved location
- `PUT /api/users/saved-locations/{id}` - Update saved location
- `DELETE /api/users/saved-locations/{id}` - Delete saved location

### Provider API
- `POST /api/providers/register` - Register new provider
- `GET /api/providers/profile` - Get provider profile
- `PUT /api/providers/profile` - Update provider profile
- `GET /api/providers/drivers` - Get provider drivers
- `POST /api/providers/drivers` - Add new driver
- `PUT /api/providers/drivers/{id}` - Update driver
- `GET /api/providers/vehicles` - Get provider vehicles
- `POST /api/providers/vehicles` - Add new vehicle
- `PUT /api/providers/vehicles/{id}` - Update vehicle
- `GET /api/providers/earnings` - Get provider earnings
- `GET /api/providers/reports` - Get financial reports

### Driver API
- `GET /api/drivers/profile` - Get driver profile
- `PUT /api/drivers/profile` - Update driver profile
- `PUT /api/drivers/status` - Update availability status
- `PUT /api/drivers/location` - Update current location
- `GET /api/drivers/rides` - Get assigned rides
- `GET /api/drivers/earnings` - Get earnings information
- `GET /api/drivers/current-ride` - Get current ride details

### Ride API
- `POST /api/rides/estimate` - Get ride estimate
- `POST /api/rides/request` - Request a ride
- `GET /api/rides/{id}` - Get ride details
- `PUT /api/rides/{id}/cancel` - Cancel ride
- `PUT /api/rides/{id}/accept` - Accept ride (driver)
- `PUT /api/rides/{id}/arrive` - Mark arrival at pickup (driver)
- `PUT /api/rides/{id}/start` - Start ride (driver)
- `PUT /api/rides/{id}/complete` - Complete ride (driver)
- `POST /api/rides/{id}/rating` - Rate ride

### Payment API
- `POST /api/payments/process` - Process payment
- `POST /api/payments/refund` - Process refund
- `GET /api/payments/transactions` - Get transaction history

### Admin API
- `GET /api/admin/users` - Get all users
- `GET /api/admin/providers` - Get all providers
- `GET /api/admin/rides` - Get all rides
- `GET /api/admin/transactions` - Get all transactions
- `GET /api/admin/reports` - Get system reports
- `PUT /api/admin/providers/{id}/verify` - Verify provider
- `PUT /api/admin/drivers/{id}/verify` - Verify driver

## Data Flow

### Ride Booking Flow
1. User requests ride estimate through mobile app
2. Estimate request routed through API Gateway to Ride Service
3. Ride Service calculates fare using Mapping Service
4. User confirms booking, creating ride request
5. Ride Service publishes ride request to Message Broker
6. Provider Service finds available drivers and notifies them
7. Driver accepts ride through Driver App
8. Ride Service updates ride status and notifies user
9. Real-time location updates flow from Driver App to Ride Service
10. User receives location updates through WebSockets
11. Driver marks ride as complete
12. Payment Service processes payment
13. Ride Service finalizes ride and allows ratings
14. Analytics Service records ride data for reporting

### Provider Onboarding Flow
1. Provider registers through web application
2. Registration routed through API Gateway to Provider Service
3. Provider Service creates provider record in MongoDB
4. Provider uploads required documents
5. Admin Service reviews documents for verification
6. Provider adds vehicles and drivers
7. Each driver and vehicle goes through verification process
8. Once verified, provider status updated to active
9. Provider can begin receiving ride requests

## Security Considerations

### Authentication and Authorization
- JWT-based authentication
- Role-based access control
- Token refresh mechanism
- API key authentication for service-to-service communication

### Data Protection
- Encryption of sensitive data at rest and in transit
- PII (Personally Identifiable Information) handling according to GDPR
- Data anonymization for analytics
- Regular security audits

### API Security
- Rate limiting
- Input validation
- CORS configuration
- HTTPS enforcement
- API versioning

## Scalability Considerations

### Horizontal Scaling
- Stateless microservices for easy replication
- Database sharding strategy for MongoDB
- Read replicas for PostgreSQL
- Auto-scaling groups in AWS

### Performance Optimization
- Redis caching for frequently accessed data
- Database indexing strategy
- CDN for static assets
- Lazy loading of non-critical data

## Monitoring and Logging

### Monitoring
- AWS CloudWatch for infrastructure monitoring
- New Relic for application performance monitoring
- Custom dashboards for business metrics
- Alerting system for critical issues

### Logging
- Centralized logging with ELK stack
- Structured logging format
- Log retention policies
- Error tracking with Sentry

## Disaster Recovery

### Backup Strategy
- Automated daily backups of all databases
- Point-in-time recovery capability
- Cross-region replication for critical data
- Regular backup restoration testing

### Failover Mechanism
- Multi-AZ deployment in AWS
- Database failover configuration
- Circuit breaker pattern for service dependencies
- Graceful degradation of non-critical services

## Conclusion

This architecture and database design provides a robust foundation for the Limburg Transportation Marketplace application. The microservices approach allows for independent scaling and development of components, while the combination of MongoDB and PostgreSQL addresses different data storage needs. The real-time capabilities are supported by WebSockets and Redis, ensuring a responsive user experience for both riders and drivers.

The design prioritizes scalability, security, and maintainability, with clear separation of concerns between services. The API-first approach facilitates the development of multiple client applications (mobile and web) while maintaining a consistent business logic layer.

As development progresses, this architecture can evolve to accommodate new features and requirements, with each microservice able to be updated independently without affecting the entire system.
