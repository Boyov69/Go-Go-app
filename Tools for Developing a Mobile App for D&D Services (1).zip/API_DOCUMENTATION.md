# Provider Onboarding and Management API Documentation

## Overview

This document provides comprehensive documentation for the Provider Onboarding and Management API for the Limburg Transportation Marketplace. The API enables transportation providers to register, manage their vehicles and drivers, and participate in the marketplace.

## Base URL

```
http://localhost:5000/api
```

## Authentication

Most endpoints require authentication using JWT (JSON Web Token). Include the token in the Authorization header:

```
Authorization: Bearer <token>
```

## Provider Endpoints

### Register Provider

Register a new transportation provider in the marketplace.

- **URL**: `/providers`
- **Method**: `POST`
- **Auth Required**: No
- **Request Body**:
  ```json
  {
    "companyName": "Hasselt Taxi Service",
    "businessType": "taxi",
    "email": "info@hasselttaxi.be",
    "password": "securePassword123",
    "phone": "+32123456789",
    "address": {
      "street": "Koning Albertstraat 15",
      "city": "Hasselt",
      "state": "Limburg",
      "postalCode": "3500",
      "country": "Belgium"
    },
    "contactPerson": {
      "firstName": "Jan",
      "lastName": "Janssen",
      "email": "jan@hasselttaxi.be",
      "phone": "+32123456789"
    },
    "licenseNumber": "TX-LIM-12345",
    "taxIdentifier": "BE0123456789",
    "serviceTypes": ["standard", "premium"]
  }
  ```
- **Success Response**: `201 Created`
  ```json
  {
    "success": true,
    "data": {
      "_id": "60d21b4667d0d8992e610c85",
      "companyName": "Hasselt Taxi Service",
      "businessType": "taxi",
      "email": "info@hasselttaxi.be",
      "phone": "+32123456789",
      "address": {
        "street": "Koning Albertstraat 15",
        "city": "Hasselt",
        "state": "Limburg",
        "postalCode": "3500",
        "country": "Belgium"
      },
      "contactPerson": {
        "firstName": "Jan",
        "lastName": "Janssen",
        "email": "jan@hasselttaxi.be",
        "phone": "+32123456789"
      },
      "licenseNumber": "TX-LIM-12345",
      "taxIdentifier": "BE0123456789",
      "serviceTypes": ["standard", "premium"],
      "status": "pending",
      "verificationStatus": "unverified",
      "createdAt": "2025-03-30T17:24:00.000Z",
      "updatedAt": "2025-03-30T17:24:00.000Z"
    }
  }
  ```

### Get All Providers

Retrieve a list of all providers (admin only).

- **URL**: `/providers`
- **Method**: `GET`
- **Auth Required**: Yes (Admin)
- **Success Response**: `200 OK`
  ```json
  {
    "success": true,
    "count": 1,
    "data": [
      {
        "_id": "60d21b4667d0d8992e610c85",
        "companyName": "Hasselt Taxi Service",
        "businessType": "taxi",
        "email": "info@hasselttaxi.be",
        "phone": "+32123456789",
        "address": {
          "street": "Koning Albertstraat 15",
          "city": "Hasselt",
          "state": "Limburg",
          "postalCode": "3500",
          "country": "Belgium"
        },
        "contactPerson": {
          "firstName": "Jan",
          "lastName": "Janssen",
          "email": "jan@hasselttaxi.be",
          "phone": "+32123456789"
        },
        "licenseNumber": "TX-LIM-12345",
        "taxIdentifier": "BE0123456789",
        "serviceTypes": ["standard", "premium"],
        "status": "pending",
        "verificationStatus": "unverified",
        "createdAt": "2025-03-30T17:24:00.000Z",
        "updatedAt": "2025-03-30T17:24:00.000Z"
      }
    ]
  }
  ```

### Get Provider by ID

Retrieve a specific provider by ID.

- **URL**: `/providers/:id`
- **Method**: `GET`
- **Auth Required**: Yes
- **URL Params**: `id=[string]`
- **Success Response**: `200 OK`
  ```json
  {
    "success": true,
    "data": {
      "_id": "60d21b4667d0d8992e610c85",
      "companyName": "Hasselt Taxi Service",
      "businessType": "taxi",
      "email": "info@hasselttaxi.be",
      "phone": "+32123456789",
      "address": {
        "street": "Koning Albertstraat 15",
        "city": "Hasselt",
        "state": "Limburg",
        "postalCode": "3500",
        "country": "Belgium"
      },
      "contactPerson": {
        "firstName": "Jan",
        "lastName": "Janssen",
        "email": "jan@hasselttaxi.be",
        "phone": "+32123456789"
      },
      "licenseNumber": "TX-LIM-12345",
      "taxIdentifier": "BE0123456789",
      "serviceTypes": ["standard", "premium"],
      "status": "pending",
      "verificationStatus": "unverified",
      "createdAt": "2025-03-30T17:24:00.000Z",
      "updatedAt": "2025-03-30T17:24:00.000Z"
    }
  }
  ```

### Update Provider

Update provider information.

- **URL**: `/providers/:id`
- **Method**: `PUT`
- **Auth Required**: Yes
- **URL Params**: `id=[string]`
- **Request Body**: Fields to update
  ```json
  {
    "phone": "+32987654321",
    "address": {
      "street": "Stationsplein 10",
      "city": "Hasselt",
      "state": "Limburg",
      "postalCode": "3500",
      "country": "Belgium"
    }
  }
  ```
- **Success Response**: `200 OK`
  ```json
  {
    "success": true,
    "data": {
      "_id": "60d21b4667d0d8992e610c85",
      "companyName": "Hasselt Taxi Service",
      "businessType": "taxi",
      "email": "info@hasselttaxi.be",
      "phone": "+32987654321",
      "address": {
        "street": "Stationsplein 10",
        "city": "Hasselt",
        "state": "Limburg",
        "postalCode": "3500",
        "country": "Belgium"
      },
      "contactPerson": {
        "firstName": "Jan",
        "lastName": "Janssen",
        "email": "jan@hasselttaxi.be",
        "phone": "+32123456789"
      },
      "licenseNumber": "TX-LIM-12345",
      "taxIdentifier": "BE0123456789",
      "serviceTypes": ["standard", "premium"],
      "status": "pending",
      "verificationStatus": "unverified",
      "createdAt": "2025-03-30T17:24:00.000Z",
      "updatedAt": "2025-03-30T17:24:00.000Z"
    }
  }
  ```

### Update Provider Verification Status

Update the verification status of a provider (admin only).

- **URL**: `/providers/:id/verification`
- **Method**: `PUT`
- **Auth Required**: Yes (Admin)
- **URL Params**: `id=[string]`
- **Request Body**:
  ```json
  {
    "verificationStatus": "verified"
  }
  ```
- **Success Response**: `200 OK`
  ```json
  {
    "success": true,
    "data": {
      "_id": "60d21b4667d0d8992e610c85",
      "companyName": "Hasselt Taxi Service",
      "businessType": "taxi",
      "email": "info@hasselttaxi.be",
      "phone": "+32987654321",
      "address": {
        "street": "Stationsplein 10",
        "city": "Hasselt",
        "state": "Limburg",
        "postalCode": "3500",
        "country": "Belgium"
      },
      "contactPerson": {
        "firstName": "Jan",
        "lastName": "Janssen",
        "email": "jan@hasselttaxi.be",
        "phone": "+32123456789"
      },
      "licenseNumber": "TX-LIM-12345",
      "taxIdentifier": "BE0123456789",
      "serviceTypes": ["standard", "premium"],
      "status": "pending",
      "verificationStatus": "verified",
      "createdAt": "2025-03-30T17:24:00.000Z",
      "updatedAt": "2025-03-30T17:24:00.000Z"
    }
  }
  ```

### Add Provider Document

Add a document to a provider.

- **URL**: `/providers/:id/documents`
- **Method**: `POST`
- **Auth Required**: Yes
- **URL Params**: `id=[string]`
- **Request Body**:
  ```json
  {
    "type": "business_license",
    "url": "https://storage.example.com/documents/license123.pdf",
    "expiryDate": "2026-12-31T00:00:00.000Z"
  }
  ```
- **Success Response**: `200 OK`
  ```json
  {
    "success": true,
    "data": {
      "_id": "60d21b4667d0d8992e610c85",
      "companyName": "Hasselt Taxi Service",
      "documents": [
        {
          "_id": "60d21b4667d0d8992e610c86",
          "type": "business_license",
          "url": "https://storage.example.com/documents/license123.pdf",
          "verificationStatus": "pending",
          "expiryDate": "2026-12-31T00:00:00.000Z"
        }
      ],
      "createdAt": "2025-03-30T17:24:00.000Z",
      "updatedAt": "2025-03-30T17:24:00.000Z"
    }
  }
  ```

## Vehicle Endpoints

### Get Provider Vehicles

Retrieve all vehicles for a specific provider.

- **URL**: `/vehicles/provider/:providerId`
- **Method**: `GET`
- **Auth Required**: Yes
- **URL Params**: `providerId=[string]`
- **Success Response**: `200 OK`
  ```json
  {
    "success": true,
    "count": 1,
    "data": [
      {
        "_id": "60d21b4667d0d8992e610c87",
        "providerId": "60d21b4667d0d8992e610c85",
        "make": "Mercedes",
        "model": "E-Class",
        "year": 2023,
        "color": "Black",
        "licensePlate": "1-ABC-123",
        "registrationNumber": "REG12345",
        "vehicleType": "sedan",
        "capacity": 4,
        "features": ["air_conditioning", "wifi"],
        "status": "active",
        "verificationStatus": "verified",
        "isAccessible": false,
        "isElectric": false,
        "createdAt": "2025-03-30T17:24:00.000Z",
        "updatedAt": "2025-03-30T17:24:00.000Z"
      }
    ]
  }
  ```

### Create Vehicle

Add a new vehicle for a provider.

- **URL**: `/vehicles/provider/:providerId`
- **Method**: `POST`
- **Auth Required**: Yes
- **URL Params**: `providerId=[string]`
- **Request Body**:
  ```json
  {
    "make": "Mercedes",
    "model": "E-Class",
    "year": 2023,
    "color": "Black",
    "licensePlate": "1-ABC-123",
    "registrationNumber": "REG12345",
    "vehicleType": "sedan",
    "capacity": 4,
    "features": ["air_conditioning", "wifi"],
    "isAccessible": false,
    "isElectric": false
  }
  ```
- **Success Response**: `201 Created`
  ```json
  {
    "success": true,
    "data": {
      "_id": "60d21b4667d0d8992e610c87",
      "providerId": "60d21b4667d0d8992e610c85",
      "make": "Mercedes",
      "model": "E-Class",
      "year": 2023,
      "color": "Black",
      "licensePlate": "1-ABC-123",
      "registrationNumber": "REG12345",
      "vehicleType": "sedan",
      "capacity": 4,
      "features": ["air_conditioning", "wifi"],
      "status": "pending",
      "verificationStatus": "unverified",
      "isAccessible": false,
      "isElectric": false,
      "createdAt": "2025-03-30T17:24:00.000Z",
      "updatedAt": "2025-03-30T17:24:00.000Z"
    }
  }
  ```

### Add Vehicle Document

Add a document to a vehicle.

- **URL**: `/vehicles/:id/documents`
- **Method**: `POST`
- **Auth Required**: Yes
- **URL Params**: `id=[string]`
- **Request Body**:
  ```json
  {
    "type": "registration",
    "url": "https://storage.example.com/documents/vehicle_reg123.pdf",
    "expiryDate": "2026-12-31T00:00:00.000Z"
  }
  ```
- **Success Response**: `200 OK`
  ```json
  {
    "success": true,
    "data": {
      "_id": "60d21b4667d0d8992e610c87",
      "make": "Mercedes",
      "model": "E-Class",
      "documents": [
        {
          "_id": "60d21b4667d0d8992e610c88",
          "type": "registration",
          "url": "https://storage.example.com/documents/vehicle_reg123.pdf",
          "verificationStatus": "pending",
          "expiryDate": "2026-12-31T00:00:00.000Z"
        }
      ],
      "createdAt": "2025-03-30T17:24:00.000Z",
      "updatedAt": "2025-03-30T17:24:00.000Z"
    }
  }
  ```

## Driver Endpoints

### Get Provider Drivers

Retrieve all drivers for a specific provider.

- **URL**: `/drivers/provider/:providerId`
- **Method**: `GET`
- **Auth Required**: Yes
- **URL Params**: `providerId=[string]`
- **Success Response**: `200 OK`
  ```json
  {
    "success": true,
    "count": 1,
    "data": [
      {
        "_id": "60d21b4667d0d8992e610c89",
        "providerId": "60d21b4667d0d8992e610c85",
        "firstName": "Pieter",
        "lastName": "Janssens",
        "email": "pieter@hasselttaxi.be",
        "phone": "+32123456790",
        "address": {
          "street": "Dorpstraat 5",
          "city": "Hasselt",
          "state": "Limburg",
          "postalCode": "3500",
          "country": "Belgium"
        },
        "dateOfBirth": "1985-05-15T00:00:00.000Z",
        "licenseNumber": "B12345678",
        "licenseExpiryDate": "2028-05-15T00:00:00.000Z",
        "status": "active",
        "verificationStatus": "verified",
        "isAvailable": true,
        "ratingAverage": 4.8,
        "ratingCount": 25,
        "createdAt": "2025-03-30T17:24:00.000Z",
        "updatedAt": "2025-03-30T17:24:00.000Z"
      }
    ]
  }
  ```

### Create Driver

Add a new driver for a provider.

- **URL**: `/drivers/provider/:providerId`
- **Method**: `POST`
- **Auth Required**: Yes
- **URL Params**: `providerId=[string]`
- **Request Body**:
  ```json
  {
    "firstName": "Pieter",
    "lastName": "Janssens",
    "email": "pieter@hasselttaxi.be",
    "phone": "+32123456790",
    "address": {
      "street": "Dorpstraat 5",
      "city": "Hasselt",
      "state": "Limburg",
      "postalCode": "3500",
      "country": "Belgium"
    },
    "dateOfBirth": "1985-05-15T00:00:00.000Z",
    "licenseNumber": "B12345678",
    "licenseExpiryDate": "2028-05-15T00:00:00.000Z"
  }
  ```
- **Success Response**: `201 Created`
  ```json
  {
    "success": true,
    "data": {
      "_id": "60d21b4667d0d8992e610c89",
      "providerId": "60d21b4667d0d8992e610c85",
      "firstName": "Pieter",
      "lastName": "Janssens",
      "email": "pieter@hasselttaxi.be",
      "phone": "+32123456790",
      "address": {
        "street": "Dorpstraat 5",
        "city": "Hasselt",
        "state": "Limburg",
        "postalCode": "3500",
        "country": "Belgium"
      },
      "dateOfBirth": "1985-05-15T00:00:00.000Z",
      "licenseNumber": "B12345678",
      "licenseExpiryDate": "2028-05-15T00:00:00.000Z",
      "status": "pending",
      "verificationStatus": "unverified",
      "isAvailable": false,
      "createdAt": "2025-03-30T17:24:00.000Z",
      "updatedAt": "2025-03-30T17:24:00.000Z"
    }
  }
  ```

### Update Driver Availability

Update a driver's availability status.

- **URL**: `/drivers/:id/availability`
- **Method**: `PUT`
- **Auth Required**: Yes
- **URL Params**: `id=[string]`
- **Request Body**:
  ```json
  {
    "isAvailable": true
  }
  ```
- **Success Response**: `200 OK`
  ```json
  {
    "success": true,
    "data": {
      "_id": "60d21b4667d0d8992e610c89",
      "firstName": "Pieter",
      "lastName": "Janssens",
      "isAvailable": true,
      "updatedAt": "2025-03-30T17:24:00.000Z"
    }
  }
  ```

### Update Driver Location

Update a driver's current location.

- **URL**: `/drivers/:id/location`
- **Method**: `PUT`
- **Auth Required**: Yes
- **URL Params**: `id=[string]`
- **Request Body**:
  ```json
  {
    "latitude": 50.9307,
    "longitude": 5.3378
  }
  ```
- **Success Response**: `200 OK`
  ```json
  {
    "success": true,
    "data": {
      "_id": "60d21b4667d0d8992e610c89",
      "firstName": "Pieter",
      "lastName": "Janssens",
      "currentLocation": {
        "latitude": 50.9307,
        "longitude": 5.3378,
        "updatedAt": "2025-03-30T17:24:00.000Z"
      },
      "updatedAt": "2025-03-30T17:24:00.000Z"
    }
  }
  ```

### Get Available Drivers Near Location

Find available drivers near a specific location.

- **URL**: `/drivers/available/nearby`
- **Method**: `GET`
- **Auth Required**: Yes
- **Query Params**:
  - `latitude=[number]` (required)
  - `longitude=[number]` (required)
  - `distance=[number]` (optional, default: 5 km)
  - `providerId=[string]` (optional)
- **Success Response**: `200 OK`
  ```json
  {
    "success": true,
    "count": 1,
    "data": [
      {
        "_id": "60d21b4667d0d8992e610c89",
        "providerId": "60d21b4667d0d8992e610c85",
        "firstName": "Pieter",
        "lastName": "Janssens",
        "currentLocation": {
          "latitude": 50.9307,
          "longitude": 5.3378,
          "updatedAt": "2025-03-30T17:24:00.000Z"
        },
        "isAvailable": true,
        "status": "active",
        "verificationStatus": "verified",
        "currentVehicleId": "60d21b4667d0d8992e610c87",
        "ratingAverage": 4.8
      }
    ]
  }
  ```

## Error Responses

### 400 Bad Request

```json
{
  "success": false,
  "error": ["Validation error message"]
}
```

### 401 Unauthorized

```json
{
  "success": false,
  "error": "Not authorized to access this route"
}
```

### 403 Forbidden

```json
{
  "success": false,
  "error": "Provider is not verified"
}
```

### 404 Not Found

```json
{
  "success": false,
  "error": "Resource not found"
}
```

### 500 Server Error

```json
{
  "success": false,
  "error": "Server Error",
  "stack": "Error stack trace (development mode only)"
}
```

## Running the API Locally

1. Install dependencies:
   ```
   cd /home/ubuntu/limburg_transport_app/backend
   npm install
   ```

2. Create a `.env` file with the following variables:
   ```
   NODE_ENV=development
   PORT=5000
   MONGODB_URI=mongodb://localhost:27017/limburg_transport
   JWT_SECRET=your_jwt_secret
   JWT_EXPIRES_IN=1d
   ```

3. Start the development server:
   ```
   npm run dev
   ```

4. The API will be available at `http://localhost:5000/api`
