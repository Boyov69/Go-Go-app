# User Booking and Payment System API Documentation

## Overview

This document provides comprehensive documentation for the User Booking and Payment API for the Limburg Transportation Marketplace. The API enables users to register, book rides, make payments, and manage their profiles.

## Base URL

```
http://localhost:5000/api
```

## Authentication

Most endpoints require authentication using JWT (JSON Web Token). Include the token in the Authorization header:

```
Authorization: Bearer <token>
```

## User Endpoints

### Register User

Register a new user in the marketplace.

- **URL**: `/users/register`
- **Method**: `POST`
- **Auth Required**: No
- **Request Body**:
  ```json
  {
    "firstName": "John",
    "lastName": "Doe",
    "email": "john.doe@example.com",
    "password": "securePassword123",
    "phone": "+32123456789"
  }
  ```
- **Success Response**: `201 Created`
  ```json
  {
    "success": true,
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "data": {
      "id": "60d21b4667d0d8992e610c85",
      "firstName": "John",
      "lastName": "Doe",
      "email": "john.doe@example.com",
      "phone": "+32123456789",
      "role": "user"
    }
  }
  ```

### Login User

Authenticate a user and get a token.

- **URL**: `/users/login`
- **Method**: `POST`
- **Auth Required**: No
- **Request Body**:
  ```json
  {
    "email": "john.doe@example.com",
    "password": "securePassword123"
  }
  ```
- **Success Response**: `200 OK`
  ```json
  {
    "success": true,
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "data": {
      "id": "60d21b4667d0d8992e610c85",
      "firstName": "John",
      "lastName": "Doe",
      "email": "john.doe@example.com",
      "phone": "+32123456789",
      "role": "user"
    }
  }
  ```

### Get Current User Profile

Retrieve the profile of the currently authenticated user.

- **URL**: `/users/me`
- **Method**: `GET`
- **Auth Required**: Yes
- **Success Response**: `200 OK`
  ```json
  {
    "success": true,
    "data": {
      "_id": "60d21b4667d0d8992e610c85",
      "firstName": "John",
      "lastName": "Doe",
      "email": "john.doe@example.com",
      "phone": "+32123456789",
      "role": "user",
      "status": "active",
      "paymentMethods": [
        {
          "_id": "60d21b4667d0d8992e610c86",
          "type": "credit_card",
          "cardNumber": "1234",
          "expiryDate": "12/25",
          "cardholderName": "John Doe",
          "isDefault": true
        }
      ],
      "favoriteLocations": [
        {
          "_id": "60d21b4667d0d8992e610c87",
          "name": "Home",
          "address": "Koning Albertstraat 15, Hasselt",
          "coordinates": {
            "latitude": 50.9307,
            "longitude": 5.3378
          },
          "type": "home"
        }
      ],
      "createdAt": "2025-03-30T17:24:00.000Z",
      "updatedAt": "2025-03-30T17:24:00.000Z"
    }
  }
  ```

### Update User Profile

Update the profile of the currently authenticated user.

- **URL**: `/users/me`
- **Method**: `PUT`
- **Auth Required**: Yes
- **Request Body**: Fields to update
  ```json
  {
    "firstName": "Johnny",
    "phone": "+32987654321",
    "address": {
      "street": "Stationsplein 10",
      "city": "Hasselt",
      "state": "Limburg",
      "postalCode": "3500",
      "country": "Belgium"
    }
  }
  ```
- **Success Response**: `200 OK`
  ```json
  {
    "success": true,
    "data": {
      "_id": "60d21b4667d0d8992e610c85",
      "firstName": "Johnny",
      "lastName": "Doe",
      "email": "john.doe@example.com",
      "phone": "+32987654321",
      "address": {
        "street": "Stationsplein 10",
        "city": "Hasselt",
        "state": "Limburg",
        "postalCode": "3500",
        "country": "Belgium"
      },
      "role": "user",
      "status": "active",
      "createdAt": "2025-03-30T17:24:00.000Z",
      "updatedAt": "2025-03-30T17:24:00.000Z"
    }
  }
  ```

### Change Password

Change the password of the currently authenticated user.

- **URL**: `/users/change-password`
- **Method**: `PUT`
- **Auth Required**: Yes
- **Request Body**:
  ```json
  {
    "currentPassword": "securePassword123",
    "newPassword": "evenMoreSecure456"
  }
  ```
- **Success Response**: `200 OK`
  ```json
  {
    "success": true,
    "message": "Password updated successfully"
  }
  ```

### Add Payment Method

Add a new payment method for the currently authenticated user.

- **URL**: `/users/payment-methods`
- **Method**: `POST`
- **Auth Required**: Yes
- **Request Body**:
  ```json
  {
    "type": "credit_card",
    "cardNumber": "4111111111111111",
    "expiryDate": "12/25",
    "cardholderName": "John Doe",
    "isDefault": true
  }
  ```
- **Success Response**: `200 OK`
  ```json
  {
    "success": true,
    "data": [
      {
        "_id": "60d21b4667d0d8992e610c86",
        "type": "credit_card",
        "cardNumber": "1111",
        "expiryDate": "12/25",
        "cardholderName": "John Doe",
        "isDefault": true
      }
    ]
  }
  ```

### Remove Payment Method

Remove a payment method for the currently authenticated user.

- **URL**: `/users/payment-methods/:paymentMethodId`
- **Method**: `DELETE`
- **Auth Required**: Yes
- **URL Params**: `paymentMethodId=[string]`
- **Success Response**: `200 OK`
  ```json
  {
    "success": true,
    "data": []
  }
  ```

### Set Default Payment Method

Set a payment method as the default for the currently authenticated user.

- **URL**: `/users/payment-methods/:paymentMethodId/default`
- **Method**: `PUT`
- **Auth Required**: Yes
- **URL Params**: `paymentMethodId=[string]`
- **Success Response**: `200 OK`
  ```json
  {
    "success": true,
    "data": [
      {
        "_id": "60d21b4667d0d8992e610c86",
        "type": "credit_card",
        "cardNumber": "1111",
        "expiryDate": "12/25",
        "cardholderName": "John Doe",
        "isDefault": true
      },
      {
        "_id": "60d21b4667d0d8992e610c87",
        "type": "paypal",
        "isDefault": false
      }
    ]
  }
  ```

### Add Favorite Location

Add a new favorite location for the currently authenticated user.

- **URL**: `/users/favorite-locations`
- **Method**: `POST`
- **Auth Required**: Yes
- **Request Body**:
  ```json
  {
    "name": "Work",
    "address": "Stationsplein 10, Hasselt",
    "coordinates": {
      "latitude": 50.9307,
      "longitude": 5.3378
    },
    "type": "work"
  }
  ```
- **Success Response**: `200 OK`
  ```json
  {
    "success": true,
    "data": [
      {
        "_id": "60d21b4667d0d8992e610c87",
        "name": "Home",
        "address": "Koning Albertstraat 15, Hasselt",
        "coordinates": {
          "latitude": 50.9307,
          "longitude": 5.3378
        },
        "type": "home"
      },
      {
        "_id": "60d21b4667d0d8992e610c88",
        "name": "Work",
        "address": "Stationsplein 10, Hasselt",
        "coordinates": {
          "latitude": 50.9307,
          "longitude": 5.3378
        },
        "type": "work"
      }
    ]
  }
  ```

## Ride Endpoints

### Request Ride

Request a new ride.

- **URL**: `/rides`
- **Method**: `POST`
- **Auth Required**: Yes
- **Request Body**:
  ```json
  {
    "providerId": "60d21b4667d0d8992e610c85",
    "rideType": "immediate",
    "serviceType": "standard",
    "pickup": {
      "address": "Koning Albertstraat 15, Hasselt",
      "coordinates": {
        "latitude": 50.9307,
        "longitude": 5.3378
      },
      "notes": "I'm at the main entrance"
    },
    "destination": {
      "address": "Stationsplein 10, Hasselt",
      "coordinates": {
        "latitude": 50.9321,
        "longitude": 5.3420
      }
    },
    "paymentMethod": "credit_card",
    "passengerCount": 2
  }
  ```
- **Success Response**: `201 Created`
  ```json
  {
    "success": true,
    "data": {
      "_id": "60d21b4667d0d8992e610c89",
      "userId": "60d21b4667d0d8992e610c85",
      "providerId": "60d21b4667d0d8992e610c85",
      "status": "searching",
      "rideType": "immediate",
      "serviceType": "standard",
      "pickup": {
        "address": "Koning Albertstraat 15, Hasselt",
        "coordinates": {
          "latitude": 50.9307,
          "longitude": 5.3378
        },
        "notes": "I'm at the main entrance"
      },
      "destination": {
        "address": "Stationsplein 10, Hasselt",
        "coordinates": {
          "latitude": 50.9321,
          "longitude": 5.3420
        }
      },
      "requestTime": "2025-03-30T17:24:00.000Z",
      "paymentMethod": "credit_card",
      "paymentStatus": "pending",
      "passengerCount": 2,
      "estimatedDistance": 1.2,
      "estimatedDuration": 5,
      "estimatedPrice": 4.66,
      "currency": "EUR",
      "createdAt": "2025-03-30T17:24:00.000Z",
      "updatedAt": "2025-03-30T17:24:00.000Z"
    }
  }
  ```

### Get Ride by ID

Retrieve a specific ride by ID.

- **URL**: `/rides/:id`
- **Method**: `GET`
- **Auth Required**: Yes
- **URL Params**: `id=[string]`
- **Success Response**: `200 OK`
  ```json
  {
    "success": true,
    "data": {
      "_id": "60d21b4667d0d8992e610c89",
      "userId": "60d21b4667d0d8992e610c85",
      "providerId": {
        "_id": "60d21b4667d0d8992e610c85",
        "companyName": "Hasselt Taxi Service",
        "phone": "+32123456789",
        "email": "info@hasselttaxi.be"
      },
      "driverId": {
        "_id": "60d21b4667d0d8992e610c89",
        "firstName": "Pieter",
        "lastName": "Janssens",
        "phone": "+32123456790",
        "profilePicture": "https://example.com/profile.jpg"
      },
      "vehicleId": {
        "_id": "60d21b4667d0d8992e610c87",
        "make": "Mercedes",
        "model": "E-Class",
        "color": "Black",
        "licensePlate": "1-ABC-123"
      },
      "status": "in_progress",
      "rideType": "immediate",
      "serviceType": "standard",
      "pickup": {
        "address": "Koning Albertstraat 15, Hasselt",
        "coordinates": {
          "latitude": 50.9307,
          "longitude": 5.3378
        },
        "notes": "I'm at the main entrance"
      },
      "destination": {
        "address": "Stationsplein 10, Hasselt",
        "coordinates": {
          "latitude": 50.9321,
          "longitude": 5.3420
        }
      },
      "requestTime": "2025-03-30T17:24:00.000Z",
      "acceptTime": "2025-03-30T17:25:00.000Z",
      "pickupTime": "2025-03-30T17:30:00.000Z",
      "paymentMethod": "credit_card",
      "paymentStatus": "pending",
      "passengerCount": 2,
      "estimatedDistance": 1.2,
      "estimatedDuration": 5,
      "estimatedPrice": 4.66,
      "currency": "EUR",
      "currentLocation": {
        "latitude": 50.9315,
        "longitude": 5.3400,
        "updatedAt": "2025-03-30T17:32:00.000Z"
      },
      "createdAt": "2025-03-30T17:24:00.000Z",
      "updatedAt": "2025-03-30T17:32:00.000Z"
    }
  }
  ```

### Get User Rides

Retrieve all rides for the currently authenticated user.

- **URL**: `/rides/me`
- **Method**: `GET`
- **Auth Required**: Yes
- **Query Params**:
  - `status=[string]` (optional)
  - `limit=[number]` (optional, default: 10)
  - `page=[number]` (optional, default: 1)
- **Success Response**: `200 OK`
  ```json
  {
    "success": true,
    "count": 1,
    "total": 1,
    "pagination": {
      "page": 1,
      "limit": 10,
      "pages": 1
    },
    "data": [
      {
        "_id": "60d21b4667d0d8992e610c89",
        "providerId": {
          "_id": "60d21b4667d0d8992e610c85",
          "companyName": "Hasselt Taxi Service"
        },
        "driverId": {
          "_id": "60d21b4667d0d8992e610c89",
          "firstName": "Pieter",
          "lastName": "Janssens"
        },
        "vehicleId": {
          "_id": "60d21b4667d0d8992e610c87",
          "make": "Mercedes",
          "model": "E-Class",
          "color": "Black"
        },
        "status": "completed",
        "serviceType": "standard",
        "pickup": {
          "address": "Koning Albertstraat 15, Hasselt"
        },
        "destination": {
          "address": "Stationsplein 10, Hasselt"
        },
        "requestTime": "2025-03-30T17:24:00.000Z",
        "dropoffTime": "2025-03-30T17:35:00.000Z",
        "finalPrice": 4.66,
        "currency": "EUR"
      }
    ]
  }
  ```

### Cancel Ride

Cancel a ride.

- **URL**: `/rides/:id/cancel`
- **Method**: `PUT`
- **Auth Required**: Yes
- **URL Params**: `id=[string]`
- **Request Body**:
  ```json
  {
    "reason": "Changed my plans"
  }
  ```
- **Success Response**: `200 OK`
  ```json
  {
    "success": true,
    "data": {
      "_id": "60d21b4667d0d8992e610c89",
      "status": "cancelled",
      "cancelTime": "2025-03-30T17:26:00.000Z",
      "cancelReason": "Changed my plans",
      "cancelledBy": "user"
    }
  }
  ```

### Rate Ride

Rate a completed ride.

- **URL**: `/rides/:id/rate`
- **Method**: `POST`
- **Auth Required**: Yes
- **URL Params**: `id=[string]`
- **Request Body**:
  ```json
  {
    "score": 5,
    "comment": "Great service, very punctual and friendly driver"
  }
  ```
- **Success Response**: `200 OK`
  ```json
  {
    "success": true,
    "data": {
      "_id": "60d21b4667d0d8992e610c89",
      "rating": {
        "driver": {
          "score": 5,
          "comment": "Great service, very punctual and friendly driver",
          "createdAt": "2025-03-30T17:40:00.000Z"
        }
      }
    }
  }
  ```

## Payment Endpoints

### Process Payment

Process payment for a ride.

- **URL**: `/payments/rides/:rideId`
- **Method**: `POST`
- **Auth Required**: Yes
- **URL Params**: `rideId=[string]`
- **Request Body**:
  ```json
  {
    "paymentMethod": "credit_card",
    "paymentToken": "tok_visa"
  }
  ```
- **Success Response**: `200 OK`
  ```json
  {
    "success": true,
    "data": {
      "_id": "60d21b4667d0d8992e610c90",
      "rideId": "60d21b4667d0d8992e610c89",
      "userId": "60d21b4667d0d8992e610c85",
      "providerId": "60d21b4667d0d8992e610c85",
      "amount": 4.66,
      "currency": "EUR",
      "status": "completed",
      "paymentMethod": "credit_card",
      "paymentIntentId": "pi_1234567890",
      "platformFee": 0.7,
      "providerAmount": 3.96,
      "receiptUrl": "https://limburg-transport.example/receipts/pi_1234567890",
      "createdAt": "2025-03-30T17:36:00.000Z",
      "updatedAt": "2025-03-30T17:36:00.000Z"
    }
  }
  ```

### Get Payment by ID

Retrieve a specific payment by ID.

- **URL**: `/payments/:id`
- **Method**: `GET`
- **Auth Required**: Yes
- **URL Params**: `id=[string]`
- **Success Response**: `200 OK`
  ```json
  {
    "success": true,
    "data": {
      "_id": "60d21b4667d0d8992e610c90",
      "rideId": "60d21b4667d0d8992e610c89",
      "userId": "60d21b4667d0d8992e610c85",
      "providerId": "60d21b4667d0d8992e610c85",
      "amount": 4.66,
      "currency": "EUR",
      "status": "completed",
      "paymentMethod": "credit_card",
      "paymentIntentId": "pi_1234567890",
      "platformFee": 0.7,
      "providerAmount": 3.96,
      "receiptUrl": "https://limburg-transport.example/receipts/pi_1234567890",
      "createdAt": "2025-03-30T17:36:00.000Z",
      "updatedAt": "2025-03-30T17:36:00.000Z"
    }
  }
  ```

### Get User Payments

Retrieve all payments for the currently authenticated user.

- **URL**: `/payments/me`
- **Method**: `GET`
- **Auth Required**: Yes
- **Query Params**:
  - `status=[string]` (optional)
  - `limit=[number]` (optional, default: 10)
  - `page=[number]` (optional, default: 1)
- **Success Response**: `200 OK`
  ```json
  {
    "success": true,
    "count": 1,
    "total": 1,
    "pagination": {
      "page": 1,
      "limit": 10,
      "pages": 1
    },
    "data": [
      {
        "_id": "60d21b4667d0d8992e610c90",
        "rideId": {
          "_id": "60d21b4667d0d8992e610c89",
          "status": "completed",
          "serviceType": "standard",
          "pickup": {
            "address": "Koning Albertstraat 15, Hasselt"
          },
          "destination": {
            "address": "Stationsplein 10, Hasselt"
          }
        },
        "providerId": {
          "_id": "60d21b4667d0d8992e610c85",
          "companyName": "Hasselt Taxi Service"
        },
        "amount": 4.66,
        "currency": "EUR",
        "status": "completed",
        "paymentMethod": "credit_card",
        "createdAt": "2025-03-30T17:36:00.000Z"
      }
    ]
  }
  ```

### Request Refund

Request a refund for a payment.

- **URL**: `/payments/:paymentId/refund`
- **Method**: `POST`
- **Auth Required**: Yes
- **URL Params**: `paymentId=[string]`
- **Request Body**:
  ```json
  {
    "reason": "Service not as described"
  }
  ```
- **Success Response**: `200 OK`
  ```json
  {
    "success": true,
    "data": {
      "_id": "60d21b4667d0d8992e610c90",
      "status": "refunded",
      "refundAmount": 4.66,
      "refundReason": "Service not as described",
      "updatedAt": "2025-03-30T17:45:00.000Z"
    }
  }
  ```

### Generate Receipt

Generate a receipt for a payment.

- **URL**: `/payments/:paymentId/receipt`
- **Method**: `GET`
- **Auth Required**: Yes
- **URL Params**: `paymentId=[string]`
- **Success Response**: `200 OK`
  ```json
  {
    "success": true,
    "data": {
      "receiptNumber": "R-610c90",
      "date": "2025-03-30T17:36:00.000Z",
      "customer": {
        "name": "John Doe",
        "email": "john.doe@example.com"
      },
      "provider": {
        "name": "Hasselt Taxi Service",
        "address": {
          "street": "Koning Albertstraat 15",
          "city": "Hasselt",
          "state": "Limburg",
          "postalCode": "3500",
          "country": "Belgium"
        }
      },
      "ride": {
        "from": "Koning Albertstraat 15, Hasselt",
        "to": "Stationsplein 10, Hasselt",
        "date": "2025-03-30T17:24:00.000Z",
        "completedAt": "2025-03-30T17:35:00.000Z",
        "distance": 1.2,
        "serviceType": "standard"
      },
      "payment": {
        "amount": 4.66,
        "currency": "EUR",
        "method": "credit_card",
        "status": "completed",
        "platformFee": 0.7
      }
    }
  }
  ```

## Error Responses

### 400 Bad Request

```json
{
  "success": false,
  "error": "Invalid input data"
}
```

### 401 Unauthorized

```json
{
  "success": false,
  "error": "Not authorized to access this route"
}
```

### 403 Forbidden

```json
{
  "success": false,
  "error": "Not authorized to view this resource"
}
```

### 404 Not Found

```json
{
  "success": false,
  "error": "Resource not found"
}
```

### 500 Server Error

```json
{
  "success": false,
  "error": "Server Error",
  "stack": "Error stack trace (development mode only)"
}
```

## Running the API Locally

1. Install dependencies:
   ```
   cd /home/ubuntu/limburg_transport_app/backend
   npm install
   ```

2. Create a `.env` file with the following variables:
   ```
   NODE_ENV=development
   PORT=5000
   MONGODB_URI=mongodb://localhost:27017/limburg_transport
   JWT_SECRET=your_jwt_secret
   JWT_EXPIRES_IN=1d
   ```

3. Start the development server:
   ```
   npm run dev
   ```

4. The API will be available at `http://localhost:5000/api`
